<?php

namespace FluentMail\App\Http\Controllers;

use FluentMail\App\Models\Settings;
use FluentMail\App\Services\NotificationHelper;
use FluentMail\Includes\Request\Request;
use FluentMail\Includes\Support\Arr;

class SlackController extends Controller
{
    public function registerSite(Request $request)
    {
        $this->verify();

        $formData = $request->get('settings', []);

        $userEmail = sanitize_email(Arr::get($formData, 'user_email'));

        if (!is_email($userEmail)) {
            return $this->sendError([
                'message' => __('Please provide a valid email address.', 'fluent-smtp')
            ], 422);
        }

        $nonce = wp_create_nonce('fluent_smtp_slack_register_site');

        $payload = [
            'admin_email' => $userEmail,
            'smtp_url'    => admin_url('options-general.php?_slack_nonce=' . $nonce . '&page=fluent-mail#/'),
            'site_url'    => site_url(),
            'site_title'  => fluentMailSiteTitle(),
            'site_lang'   => get_bloginfo('language'),
        ];


        $activationData = NotificationHelper::registerSlackSite($payload);

        if (is_wp_error($activationData)) {
            return $this->sendError([
                'message' => $activationData->get_error_message(),
                'errors'  => $activationData->get_error_data(),
            ], 422);
        }

        NotificationHelper::updateChannelSettings('slack', [
            'status'       => 'pending',
            'token'        => Arr::get($activationData, 'site_token'),
            'redirect_url' => ''
        ]);

        return $this->sendSuccess([
            'message'      => __('Redirecting you to Slack...', 'fluent-smtp'),
            'redirect_url' => Arr::get($activationData, 'redirect_url')
        ]);
    }

    public function sendTestMessage(Request $request)
    {
        $this->verify();

        // Let's update the notification status
        $settings = (new Settings())->notificationSettings();

        if (Arr::get($settings, 'slack.status') != 'yes') {
            return $this->sendError([
                'message' => __('Slack notifications are not enabled.', 'fluent-smtp')
            ], 422);
        }

        $message = NotificationHelper::getTestMessage();

        $result = NotificationHelper::sendSlackMessage($message, Arr::get($settings, 'slack.webhook_url'));

        if (is_wp_error($result)) {
            return $this->sendError([
                'message' => $result->get_error_message(),
                'errors'  => $result->get_error_data(),
            ], 422);
        }

        return $this->sendSuccess([
            'message' => __('Test message sent.', 'fluent-smtp')
        ]);
    }

    public function disconnect()
    {
        $this->verify();

        NotificationHelper::updateChannelSettings('slack', [
            'status'      => 'no',
            'webhook_url' => '',
            'token'       => ''
        ]);

        return $this->sendSuccess([
            'message' => __('Slack has been disconnected.', 'fluent-smtp')
        ]);
    }

}
