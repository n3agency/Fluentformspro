<?php

namespace FluentCommunityPro\App\Hooks\Handlers;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Services\ModerationService;

class UserModerationHandler
{
    public function register()
    {
        if (!Helper::isFeatureEnabled('content_moderation')) {
            return;
        }

        add_filter('fluent_community/update_profile_data', [$this, 'maybeUpdateUserFlag'], 10, 4);
        add_filter('fluent_community/profile_view_data', [$this, 'addUserFlagToProfile'], 10, 3);
    }

    public function maybeUpdateUserFlag($updateData, $data, $xProfile, $currentUser = null)
    {
        if (!isset($data['is_flagged'])) {
            return $updateData;
        }

        if (!$currentUser || !$currentUser->isCommunityAdmin()) {
            return $updateData;
        }

        $isFlagged = Arr::get($data, 'is_flagged') === 'yes';

        $targetUser = $xProfile->user;

        if (!$targetUser || ($isFlagged && $targetUser->isCommunityModerator())) {
            return $updateData;
        }

        ModerationService::updateUserFlag($targetUser, $isFlagged);

        return $updateData;
    }

    public function addUserFlagToProfile($profile, $xprofile, $isAdmin = false)
    {
        if (!$isAdmin) {
            return $profile;
        }

        $profile['is_moderator'] = ModerationService::isModeratorUser($xprofile->user_id) ? 'yes' : 'no';

        if ($profile['is_moderator'] === 'no') {
            $profile['is_flagged'] = ModerationService::isUserFlagged($xprofile->user_id) ? 'yes' : 'no';
        }

        return $profile;
    }
}
