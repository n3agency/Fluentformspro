<?php

namespace FluentCommunityPro\App\Hooks\Handlers;

use FluentCommunity\App\Models\Notification;
use FluentCommunity\App\Models\NotificationSubscriber;
use FluentCommunity\App\Models\User;
use FluentCommunity\App\Models\Comment;
use FluentCommunity\App\Models\Feed;
use FluentCommunity\App\Functions\Utility;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Models\Moderation;
use FluentCommunityPro\App\Services\ModerationService;
use FluentCommunityPro\App\Services\ProHelper;

class ModerationHandler
{
    public function register()
    {
        if (!Helper::isFeatureEnabled('content_moderation')) {
            return;
        }

        add_action('fluent_community/content_moderation/created', [$this, 'handleNewReportEvent'], 10, 1);
        add_action('fluent_community/content_moderation/created', [$this, 'handleNewReportEmail'], 10, 1);
        add_action('fluent_community/content_moderation/created', [$this, 'maybeFlagContent'], 10, 2);
        add_action('fluent_community/content_moderation/created', [$this, 'handleReportStrike'], 20, 2);

        add_filter('fluent_community/feed/new_feed_data', [$this, 'maybeFlagFeed'], 10, 2);
        add_filter('fluent_community/comment/comment_data', [$this, 'maybeFlagComment'], 10, 2);

        add_filter('fluent_community/feed/update_feed_data', [$this, 'maybeFlagUpdatedFeed'], 10, 2);
        add_filter('fluent_community/comment/update_comment_data', [$this, 'maybeFlagUpdatedComment'], 10, 4);

        add_filter('fluent_community/feed/new_feed_response', [$this, 'maybeUpdateFlaggedFeedResponse'], 10, 2);
        add_filter('fluent_community/comment/new_comment_response', [$this, 'maybeUpdateFlaggedCommentResponse'], 10, 2);

        add_action('fluent_community/report/unpublished', [$this, 'handleRejectionStrike'], 10, 2);

        add_action('fluent_community/feed/deleted', [$this, 'deleteFeedReport'], 10, 1);
        add_action('fluent_community/comment_deleted', [$this, 'deleteCommentReport'], 10, 1);
        add_action('fluent_community/comment_report_added_async', [$this, 'handleCommentReportEmailAsync'], 10, 2);
        add_action('fluent_community/post_report_added_async', [$this, 'handlePostReportEmailAsync'], 10, 2);
    }

    public function maybeFlagFeed($data, $requestData)
    {
        if (Arr::isTrue($requestData, 'is_admin', false)) {
             return $data;
        }

        $flagged = ModerationService::isContentFlagged($data);

        if (!$flagged) {
            return $data;
        }

        $data['status'] = 'pending';
        $data['meta']['reports_count'] = 1;
        $data['meta']['auto_flagged'] = 'yes';
        $data['meta']['prevent_published'] = 'yes';
        $data['meta']['flagged_reason'] = $flagged['reason'];

        add_action('fluent_community/feed/new_feed_pending', function ($feed) use ($flagged) {
            $reportData = [
                'post_id'       => $feed->id,
                'content_type'  => 'post',
                'user_id'       => null,
                'parent_id'     => null,
                'reports_count' => 1,
                'reason'        => $flagged['reason'],
                'status'        => 'flagged',
                'explanation'   => $flagged['explanation'],
                'meta'          => [
                    'flagged_by' => 'auto'
                ]
            ];

            $report = Moderation::create($reportData);
            do_action('fluent_community/content_moderation/created', $report, $feed);
        }, 10, 1);

        return $data;
    }

    public function maybeUpdateFlaggedFeedResponse($response, $feed)
    {
        $meta = $feed->meta ?: [];

        if (Arr::get($meta, 'auto_flagged') !== 'yes') {
            return $response;
        }

        $reason = Arr::get($meta, 'flagged_reason', '');

        $genericReviewMessage = __('Your post has been sent for review as per community guidelines.', 'fluent-community-pro');

        $messages = [
            'profanity'                 => __('Your post contains a restricted word and has been sent for review.', 'fluent-community-pro'),
            'first_post_approval'       => __('Your first post requires approval from a moderator before it becomes visible.', 'fluent-community-pro'),
            'flag_all_new_posts'        => $genericReviewMessage,
            'flag_all_new_posts_spaces' => __('Your post has been sent for review as per space guidelines.', 'fluent-community-pro'),
            'user_flagged'              => $genericReviewMessage,
        ];

        if (!empty($messages[$reason])) {
            $response['message'] = $messages[$reason];
        }

        return $response;
    }

    public function maybeFlagComment($data)
    {
        if (Arr::isTrue($data, 'is_admin', false)) {
            return $data;
        }

        $flagged = ModerationService::isCommentFlagged($data);

        if (!$flagged) {
            return $data;
        }

        $data['status'] = 'pending';
        $data['meta']['reports_count'] = 1;
        $data['meta']['prevent_published'] = 'yes';
        $data['meta']['auto_flagged'] = 'yes';
        $data['meta']['flagged_reason'] = $flagged['reason'];

        add_action('fluent_community/comment/new_comment_pending', function ($comment, $feed) use ($flagged) {
            $reportData = [
                'post_id'       => $feed->id,
                'content_type'  => 'comment',
                'user_id'       => null,
                'parent_id'     => $comment->id,
                'reports_count' => 1,
                'reason'        => $flagged['reason'],
                'status'        => 'flagged',
                'explanation'   => $flagged['explanation'],
                'meta'          => [
                    'flagged_by' => 'auto'
                ]
            ];

            $report = Moderation::create($reportData);
            do_action('fluent_community/content_moderation/created', $report, $comment);

        }, 10, 2);

        return $data;
    }

    public function maybeUpdateFlaggedCommentResponse($response, $comment)
    {
        $meta = $comment->meta ?: [];

        if (Arr::get($meta, 'auto_flagged') !== 'yes') {
            return $response;
        }

        $reason = Arr::get($meta, 'flagged_reason', '');

        $messages = [
            'profanity'              => __('Your comment contains a restricted word and has been sent for review.', 'fluent-community-pro'),
            'first_comment_approval' => __('Your first comment requires approval from a moderator before it becomes visible.', 'fluent-community-pro'),
            'user_flagged'           => __('Your comment has been sent for review as per community guidelines.', 'fluent-community-pro'),
        ];

        if (!empty($messages[$reason])) {
            $response['message'] = $messages[$reason];
        }

        return $response;
    }

    public function deleteFeedReport($postId)
    {
        Moderation::where('post_id', $postId)
            ->where('content_type', 'post')
            ->delete();
    }

    public function deleteCommentReport($commentId)
    {
        Moderation::where('parent_id', $commentId)
            ->where('content_type', 'comment')
            ->delete();
    }

    public function maybeFlagContent($report, $content)
    {
        if (!$report || !$report->user_id || !$content) {
            return;
        }

        $moderationConfig = Helper::getModerationConfig();

        $isModerationEnabled = Arr::get($moderationConfig, 'is_enabled', 'no') == 'yes';

        $threshold = Arr::get($moderationConfig, 'flag_after_threshold', 0);

        if (!$isModerationEnabled || $threshold <= 0 || $content->status != 'published') {
            return;
        }

        if ($report->reports_count < $threshold) {
            return;
        }

        // Auto-hiding flagged content is housekeeping, not activity.
        $content->timestamps = false;
        $content->status = 'pending';
        $content->save();

        $report->status = 'flagged';
        $report->save();

        if ($report->content_type == 'comment' && $post = Feed::withoutGlobalScopes()->find($report->post_id)) {
            $post->comments_count--;
            // A flagged comment changes the parent's counter, which is housekeeping, not activity.
            $post->timestamps = false;
            $post->save();
        }

        do_action('fluent_community/content_flagged', $report, $content);
    }

    public function handleReportStrike($report, $content)
    {
        if (!$report->user_id || Arr::get($report->meta ?: [], 'flagged_by') === 'auto') {
            return;
        }

        ModerationService::recordReportStrike($content, (int)$report->user_id);
    }

    public function handleRejectionStrike($report, $content = null)
    {
        if (!Helper::isModerator()) {
            return;
        }

        if (!$content) {
            $content = $report->content_type === 'comment'
                ? Comment::find($report->parent_id)
                : Feed::find($report->post_id);
        }

        if ($content) {
            ModerationService::recordRejectionStrike($content);
        }
    }

    public function handleNewReportEvent($report)
    {
        $post = $report->post;
        if (!$post) {
            return;
        }

        $userIds = $this->getNotificationUserIds($post);

        if ($report->content_type == 'comment') {
            return $this->handleCommentReport($report, $userIds);
        }

        return $this->handlePostReport($report, $userIds);
    }

    public function handleNewReportEmail($report)
    {
        $contentType = $report->content_type;

        as_schedule_single_action(
            time(),
            'fluent_community/' . $contentType . '_report_added_async',
            [$report->id, 0],
            'fluent-community'
        );
    }

    protected function handleCommentReport($report, $userIds)
    {
        $post = $report->post;
        $commentTitle = $report->comment->getHumanExcerpt(60);

        $exist = Notification::where('feed_id', $report->comment->id)
            ->where('action', 'comment_report_added')
            ->first();

        $notificationContent = \sprintf(
        /* translators: %1$s is the comment title*/
            __('A comment has been automatically flagged for review: %1$s', 'fluent-community-pro'),
            '<span class="fcom_nft">' . $commentTitle . '</span>'
        );

        if ($report->user_id) {
            $totalUsers = Moderation::where('post_id', $post->id)
                ->where('content_type', 'comment')
                ->where('parent_id', $report->comment->id)
                ->where('user_id', '!=', $report->user_id)
                ->distinct('user_id')
                ->count('user_id');

            $reporter = '<b class="fcom_nudn">' . esc_html($report->reporter->display_name) . '</b>';

            if ($totalUsers) {
                $reporter .= sprintf(
                /* translators: %s is the number of other people */
                    __(' and %s other people', 'fluent-community-pro'),
                    '<b class="fcom_nrc">' . $totalUsers . '</b>'
                );
            }

            $notificationContent = \sprintf(
            /* translators: %1$s is the user name, %2$s is the comment title*/
                __('%1$s flagged a comment for your review: %2$s', 'fluent-community-pro'),
                $reporter,
                '<span class="fcom_nft">' . $commentTitle . '</span>'
            );
        }

        if ($exist) {
            $exist->content = $notificationContent;
            $exist->updated_at = current_time('mysql');
            $exist->src_user_id = $report->user_id;
            $exist->object_id = $report->id;
            $exist->save();

            NotificationSubscriber::where('object_id', $exist->id)
                ->update([
                    'is_read'    => 0,
                    'updated_at' => current_time('mysql')
                ]);
            return;
        }

        $notification = [
            'feed_id'         => $report->comment->id,
            'object_id'       => $report->id,
            'src_user_id'     => $report->user_id,
            'src_object_type' => 'report',
            'action'          => 'comment_report_added',
            'content'         => $notificationContent,
            'route'           => $post->getJsRoute(),
        ];

        $notification = Notification::create($notification);

        $notification->subscribe($userIds);
    }

    protected function handlePostReport($report, $userIds)
    {
        $post = $report->post;
        $postTitle = $post->getHumanExcerpt(60);

        $exist = Notification::where('feed_id', $post->id)
            ->where('action', 'post_report_added')
            ->first();

        $notificationContent = \sprintf(
        /* translators: %1$s is the feed title */
            __('A post has been automatically flagged for review: %1$s', 'fluent-community-pro'),
            '<span class="fcom_nft">' . $postTitle . '</span>'
        );

        if ($report->user_id) {
            $totalUsers = Moderation::where('post_id', $post->id)
                ->where('content_type', 'post')
                ->where('user_id', '!=', $report->user_id)
                ->distinct('user_id')
                ->count('user_id');

            $reporter = '<b class="fcom_nudn">' . esc_html($report->reporter->display_name) . '</b>';

            if ($totalUsers) {
                $reporter .= sprintf(
                /* translators: %s is the number of other people */
                    __(' and %s other people', 'fluent-community-pro'),
                    '<b class="fcom_nrc">' . $totalUsers . '</b>'
                );
            }

            $notificationContent = \sprintf(
            /* translators: %1$s is the user name, %2$s is the feed title */
                __('%1$s flagged a post %2$s for your review', 'fluent-community-pro'),
                $reporter,
                '<span class="fcom_nft">' . $postTitle . '</span>'
            );

            if ($post->space_id) {
                $notificationContent = \sprintf(
                /* translators: %1$s is the user name, %2$s is the feed title  and %3$s space title*/
                    __('%1$s flagged a post %2$s for your review in %3$s', 'fluent-community-pro'),
                    $reporter,
                    '<span class="fcom_nft">' . $postTitle . '</span>',
                    '<span class="fcom_nst">' . esc_html($post->space->title) . '</span>'
                );
            }
        }

        if ($exist) {
            $exist->content = $notificationContent;
            $exist->updated_at = current_time('mysql');
            $exist->src_user_id = $report->user_id;
            $exist->object_id = $report->id;
            $exist->save();

            NotificationSubscriber::where('object_id', $exist->id)
                ->update([
                    'is_read'    => 0,
                    'updated_at' => current_time('mysql')
                ]);
            return;
        }

        $notification = [
            'feed_id'         => $post->id,
            'object_id'       => $report->id,
            'src_user_id'     => $report->user_id,
            'src_object_type' => 'report',
            'action'          => 'post_report_added',
            'content'         => $notificationContent,
            'route'           => $post->getJsRoute(),
        ];

        $notification = Notification::create($notification);

        $notification->subscribe($userIds);
    }

    public function maybeFlagUpdatedFeed($data, $requestData)
    {
        if (Arr::isTrue($requestData, 'is_admin', false)) {
            return $data;
        }

        $moderationConfig = Helper::getModerationConfig();

        $profiency = Arr::get($moderationConfig, 'profanity_filter', '');

        $content = Arr::get($data, 'title') . ' ' . Arr::get($data, 'message');

        $flagged = ModerationService::getUserFlaggedReason(get_current_user_id());

        if (!$flagged) {
            $flagged = ModerationService::getProfanityReason($profiency, $content);
        }

        if (!$flagged) {
            return $data;
        }

        $data['status'] = 'pending';
        $data['meta']['reports_count'] = 1;
        $data['meta']['auto_flagged'] = 'yes';

        $reportData = [
            'post_id'       => null,
            'content_type'  => 'post',
            'user_id'       => null,
            'parent_id'     => null,
            'reports_count' => 1,
            'reason'        => $flagged['reason'],
            'status'        => 'flagged',
            'explanation'   => $flagged['explanation'],
            'meta'          => [
                'flagged_by' => 'auto'
            ]
        ];

        add_action('fluent_community/feed/updated', function ($feed) use ($reportData) {
            $reportData['post_id'] = $feed->id;

            $report = Moderation::where('post_id', $feed->id)
                ->where('content_type', 'post')
                ->whereNull('parent_id')
                ->whereNull('user_id')
                ->first();

            if ($report) {
                $report->fill([
                    'reason'      => $reportData['reason'],
                    'explanation' => $reportData['explanation'],
                    'status'      => 'flagged',
                ])->save();
            } else {
                $report = Moderation::create($reportData);
            }

            do_action('fluent_community/content_moderation/created', $report, $feed);
        }, 10, 1);

        return $data;
    }

    public function maybeFlagUpdatedComment($data, $feed, $requestData, $comment)
    {
        if (Arr::isTrue($requestData, 'is_admin', false)) {
            return $data;
        }

        $moderationConfig = Helper::getModerationConfig();

        $profiency = Arr::get($moderationConfig, 'profanity_filter', '');

        $content = Arr::get($data, 'message');

        $flagged = ModerationService::getUserFlaggedReason(get_current_user_id());

        if (!$flagged) {
            $flagged = ModerationService::getProfanityReason($profiency, $content);
        }

        if (!$flagged) {
            return $data;
        }

        $reportData = [
            'post_id'       => $feed->id,
            'content_type'  => 'comment',
            'user_id'       => null,
            'parent_id'     => $comment->id,
            'reports_count' => 1,
            'reason'        => $flagged['reason'],
            'status'        => 'flagged',
            'explanation'   => $flagged['explanation'],
            'meta'          => [
                'flagged_by' => 'auto'
            ]
        ];

        add_action('fluent_community/comment_updated', function ($comment) use ($reportData) {
            $report = Moderation::where('post_id', $reportData['post_id'])
                ->where('content_type', 'comment')
                ->where('parent_id', $reportData['parent_id'])
                ->whereNull('user_id')
                ->first();

            if ($report) {
                $report->fill([
                    'reason'      => $reportData['reason'],
                    'explanation' => $reportData['explanation'],
                    'status'      => 'flagged',
                ])->save();
            } else {
                $report = Moderation::create($reportData);
            }

            do_action('fluent_community/content_moderation/created', $report, $comment);
        }, 10, 1);

        $data['status'] = 'pending';
        $data['meta']['reports_count'] = 1;
        $data['meta']['auto_flagged'] = 'yes';

        return $data;
    }

    public function handleCommentReportEmailAsync($reportId, $lastUserId)
    {
        $report = Moderation::find($reportId);
        if (!$report) {
            return;
        }

        $comment = Comment::find($report->parent_id);
        if (!$comment) {
            return;
        }

        $post = $comment->post;
        if (!$post) {
            return;
        }

        $userIds = $this->getNotificationUserIds($post);

        $users = User::query()->whereIn('ID', $userIds)
            ->whereHas('xprofile', function ($query) {
                return $query->where('status', 'active');
            })
            ->when($lastUserId, function ($q) use ($lastUserId) {
                $q->where('ID', '>', $lastUserId);
            })
            ->orderBy('ID', 'ASC')
            ->get();

        if ($users->isEmpty()) {
            return;
        }

        $emailSubject = \sprintf(
        /* translators: %s is the comment excerpt (max 30 chars) */
            __('Comment flagged for review: %s', 'fluent-community-pro'),
            $comment->getHumanExcerpt(30)
        );

        $buttonText = __('Review the comment', 'fluent-community-pro');

        $emailBody = $comment->getCommentHtml(true, $buttonText);

        $postPermalink = $post->getPermalink() . '?comment_id=' . $comment->id;

        ProHelper::sendThrottledEmails(
            $users,
            $emailSubject,
            $emailBody,
            $postPermalink,
            function ($lastUserId) use ($reportId) {
                as_schedule_single_action(
                    time(),
                    'fluent_community/comment_report_added_async',
                    [$reportId, $lastUserId],
                    'fluent-community'
                );
            },
            $report->user_id
        );

        return true;
    }

    public function handlePostReportEmailAsync($reportId, $lastUserId)
    {
        $report = Moderation::find($reportId);
        if (!$report) {
            return;
        }

        $post = $report->post;
        if (!$post) {
            return;
        }

        $userIds = $this->getNotificationUserIds($post);

        $users = User::query()->whereIn('ID', $userIds)
            ->whereHas('xprofile', function ($query) {
                return $query->where('status', 'active');
            })
            ->when($lastUserId, function ($q) use ($lastUserId) {
                $q->where('ID', '>', $lastUserId);
            })
            ->orderBy('ID', 'ASC')
            ->get();

        if ($users->isEmpty()) {
            return;
        }

        $emailSubject = \sprintf(
        /* translators: %s is the post excerpt (max 30 chars) */
            __('Post flagged for review: %s', 'fluent-community-pro'),
            $post->getHumanExcerpt(30)
        );

        $buttonText = __('Review the post', 'fluent-community-pro');

        $emailBody = $post->getFeedHtml(true, $buttonText);

        $postPermalink = $post->getPermalink();

        ProHelper::sendThrottledEmails(
            $users,
            $emailSubject,
            $emailBody,
            $postPermalink,
            function ($lastUserId) use ($reportId) {
                as_schedule_single_action(
                    time(),
                    'fluent_community/post_report_added_async',
                    [$reportId, $lastUserId],
                    'fluent-community'
                );
            },
            $report->user_id
        );
    }

    protected function getNotificationUserIds($post)
    {
        $userIds = Utility::getFromCache('moderator_user_ids', function () {
            return User::whereHas('community_role', function ($q) {
                    $q->where(function ($q) {
                        $q->where('value', 'like', '%"admin"%')
                            ->orWhere('value', 'like', '%"moderator"%');
                    });
                })
                ->whereHas('xprofile', function ($q) {
                    $q->where('status', 'active');
                })
                ->with('community_role')
                ->get()
                ->filter(function ($manager) {
                    return array_intersect(['admin', 'moderator'], $manager->community_role->value);
                })
                ->pluck('ID')
                ->toArray();
        }, HOUR_IN_SECONDS);

        if ($post->space_id) {
            $spaceAdminIds = $post->space->admins->pluck('ID')->toArray();
            $userIds = array_unique(array_merge($spaceAdminIds, $userIds));
        }

        return $userIds;
    }
}
