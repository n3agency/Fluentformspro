<?php

namespace FluentCommunityPro\App\Hooks\Handlers;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;

class PostVisibilityHandler
{
    public function register()
    {
        add_filter('fluent_community/feed/filterable_statuses', [$this, 'filterableStatuses']);

        // Shared by create and update: permit the "unlisted" status when requested.
        add_filter('fluent_community/feed/save_status', [$this, 'resolveSaveStatus'], 10, 3);

        add_filter('fluent_community/feed/new_feed_response', [$this, 'filterNewFeedResponse'], 10, 2);
    }

    public function filterableStatuses($statuses)
    {
        return array_values(array_unique(array_merge(
            (array)$statuses,
            ['published', 'unlisted', 'pending', 'scheduled']
        )));
    }

    public function resolveSaveStatus($status, $requestData, $existingFeed = null)
    {
        // Only community moderators/admins may mark a post unlisted.
        if (Arr::get($requestData, 'status') === 'unlisted' && Helper::isModerator()) {
            return 'unlisted';
        }

        return $status;
    }

    public function filterNewFeedResponse($response, $feed)
    {
        if (isset($feed->status) && $feed->status === 'unlisted') {
            $response['message'] = __('Your post has been published as unlisted. Only people with the link can see it.', 'fluent-community-pro');
        }

        return $response;
    }
}
