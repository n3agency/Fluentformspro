<?php

namespace FluentCommunityPro\App\Hooks\Handlers;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Services\ProfileFieldsService;

class CustomProfileFieldsHandler
{
    public function register()
    {
        if (!Helper::isFeatureEnabled('custom_profile_fields')) {
            return;
        }

        add_filter('fluent_community/portal_vars', [$this, 'addPortalVars'], 10, 1);
        add_filter('fluent_community/update_profile_data', [$this, 'updateCustomFieldData'], 10, 3);
        add_filter('fluent_community/profile_view_data', [$this, 'extendProfileViewData'], 10, 2);
    }

    public function addPortalVars($vars)
    {
        $vars['customProfileFieldTypes'] = ProfileFieldsService::getFieldTypes();
        
        return $vars;
    }
    
    public function updateCustomFieldData($updateData, $data, $xProfile)
    {
        $customFields = (array) Arr::get($data, 'custom_fields', []);
        if (empty($customFields)) {
            return $updateData;
        }

        $currentUserId = get_current_user_id();
        if (!$currentUserId) {
            return $updateData;
        }

        $isOwn = $xProfile->user_id == $currentUserId;
        $isAdmin = Helper::isSiteAdmin($currentUserId);

        $accessibleFields = ProfileFieldsService::getAccessibleFields($isOwn, $isAdmin);
        if (empty($accessibleFields)) {
            return $updateData;
        }

        $customFieldsData = ProfileFieldsService::sanitizeAndValidateValues($customFields, $accessibleFields);

        $existing = $xProfile->custom_fields;

        $updateData['custom_fields'] = array_merge((array) $existing, $customFieldsData);

        return $updateData;
    }

    public function extendProfileViewData($profileData, $xprofile)
    {
        $currentUserId = get_current_user_id();
        $isOwn = $currentUserId && $xprofile->user_id == $currentUserId;
        $isAdmin = $currentUserId && Helper::isSiteAdmin($currentUserId);

        $visibleFields = ProfileFieldsService::getAccessibleFields($isOwn, $isAdmin);
        if (empty($visibleFields)) {
            return $profileData;
        }

        $allValues = (array) $xprofile->custom_fields;

        // Group fields by their group slug
        $fieldsByGroup = [];
        foreach ($visibleFields as $field) {
            $groupSlug = Arr::get($field, 'group', '_additional_info');
            $slug = Arr::get($field, 'slug');

            if ($slug && array_key_exists($slug, $allValues)) {
                $field['value'] = $allValues[$slug];
            }

            $fieldsByGroup[$groupSlug][] = $field;
        }

        // Build groups with nested fields
        $groupedFields = [];
        foreach (ProfileFieldsService::getGroups() as $group) {
            $groupSlug = Arr::get($group, 'slug');
            if (!empty($fieldsByGroup[$groupSlug])) {
                $group['fields'] = $fieldsByGroup[$groupSlug];
                $groupedFields[] = $group;
            }
        }

        $profileData['custom_field_groups'] = $groupedFields;

        return $profileData;
    }
}
