<?php

/**
 * @var $app FluentCommunity\Framework\Foundation\Application
 */

// Init the integrations
(new \FluentCommunityPro\App\Services\Integrations\Integrations())->register();

// Independent modules
(new \FluentCommunityPro\App\Hooks\Handlers\ShortCodeHandler())->register();

// Unlisted post visibility
(new \FluentCommunityPro\App\Hooks\Handlers\PostVisibilityHandler())->register();

// Pro action
(new \FluentCommunityPro\App\Hooks\Handlers\ProActionHanders())->register();

// Sequential lesson lock
(new \FluentCommunityPro\App\Hooks\Handlers\SequentialLessonLockHandler())->register();

// Access Management CRM
(new \FluentCommunityPro\App\Hooks\Handlers\AccessManagementCrmHandler())->register();

// Report Content
(new \FluentCommunityPro\App\Hooks\Handlers\ModerationHandler())->register();

// Per-User Moderation Flag
(new \FluentCommunityPro\App\Hooks\Handlers\UserModerationHandler())->register();

// Schedule Post
(new \FluentCommunityPro\App\Hooks\Handlers\SchedulePostHandler())->register();

// Followers
(new \FluentCommunityPro\App\Hooks\Handlers\FollowHandler())->register();

// Course Email Notification
(new \FluentCommunityPro\App\Hooks\Handlers\CourseEmailNotificationHandler())->register();

// Custom Profile Fields
(new \FluentCommunityPro\App\Hooks\Handlers\CustomProfileFieldsHandler())->register();