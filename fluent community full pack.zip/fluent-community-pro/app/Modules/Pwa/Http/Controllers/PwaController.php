<?php

namespace FluentCommunityPro\App\Modules\Pwa\Http\Controllers;

use FluentCommunity\App\Http\Controllers\Controller;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Modules\Pwa\PwaHelper;

class PwaController extends Controller
{
    public function getSettings(Request $request)
    {
        return $this->sendSuccess([
            'settings'      => PwaHelper::getSettings(),
            'default_icon'  => PwaHelper::getDefaultIcon()
        ]);
    }

    public function saveSettings(Request $request)
    {
        $data = $request->get('settings', []);

        $appName = sanitize_text_field(Arr::get($data, 'app_name', ''));
        $shortName = sanitize_text_field(Arr::get($data, 'short_name', ''));

        $this->validate(array_merge($data, ['app_name' => $appName]), [
            'app_name' => 'required|string'
        ]);

        if (mb_strlen($appName) > PwaHelper::APP_NAME_MAX_LENGTH) {
            return $this->sendError([
                'message' => sprintf(
                    /* translators: %d is the maximum number of characters. */
                    __('App Name should not exceed %d characters.', 'fluent-community-pro'),
                    PwaHelper::APP_NAME_MAX_LENGTH
                )
            ], 422);
        }

        if (mb_strlen($shortName) > PwaHelper::SHORT_NAME_MAX_LENGTH) {
            return $this->sendError([
                'message' => sprintf(
                    /* translators: %d is the maximum number of characters. */
                    __('Short Name should not exceed %d characters.', 'fluent-community-pro'),
                    PwaHelper::SHORT_NAME_MAX_LENGTH
                )
            ], 422);
        }

        $iconSource = Arr::get($data, 'icon_source', 'default');

        if (!in_array($iconSource, ['default', 'custom'], true)) {
            return $this->sendError([
                'message' => __('Unsupported app icon source.', 'fluent-community-pro')
            ], 422);
        }

        $installPosition = Arr::get($data, 'install_position', 'bottom');

        if (!in_array($installPosition, ['top', 'bottom'], true)) {
            return $this->sendError([
                'message' => __('Unsupported install button position.', 'fluent-community-pro')
            ], 422);
        }

        $backgroundColor = sanitize_hex_color((string)Arr::get($data, 'background_color', ''));

        $customIcon = sanitize_url((string)Arr::get($data, 'custom_icon', ''));

        $iconSizes = '';

        if ($customIcon && $iconSource === 'custom') {
            // Uploads are stored as draft media and the cleanup cron deletes them
            // after two hours, so the chosen icon has to be marked active.
            $media = Helper::getMediaFromUrl($customIcon);

            $dimensions = PwaHelper::getIconDimensions($customIcon, $media);

            if ($dimensions) {
                $isValidIcon = self::validateIconDimensions($dimensions);

                if (is_wp_error($isValidIcon)) {
                    return $this->sendError([
                        'message' => $isValidIcon->get_error_message()
                    ], 422);
                }

                $iconSizes = $dimensions[0] . 'x' . $dimensions[1];
            }

            if ($media && !$media->is_active) {
                $media->update([
                    'is_active'     => true,
                    'user_id'       => get_current_user_id(),
                    'object_source' => 'general'
                ]);
                $customIcon = $media->public_url;
            }
        }

        if ($iconSource === 'custom' && !$customIcon) {
            return $this->sendError([
                'message' => __('An app icon is required when a custom icon is selected.', 'fluent-community-pro')
            ], 422);
        }

        $settings = [
            'app_name'            => $appName,
            'short_name'          => $shortName,
            'icon_source'         => $iconSource,
            'custom_icon'         => $customIcon,
            'icon_sizes'          => $iconSizes,
            'background_color'    => $backgroundColor ? $backgroundColor : '',
            'install_entry'       => Arr::get($data, 'install_entry') === 'yes' ? 'yes' : 'no',
            'install_position'    => $installPosition,
            'install_dismissible' => Arr::get($data, 'install_dismissible') === 'yes' ? 'yes' : 'no'
        ];

        PwaHelper::updateSettings($settings);

        return $this->sendSuccess([
            'message'  => __('PWA settings have been saved.', 'fluent-community-pro'),
            'settings' => $settings
        ]);
    }

    /**
     * Browsers refuse an icon that is not square or is too small, and they do it
     * silently — beforeinstallprompt simply never fires and the install entry
     * never appears. Oversized icons are handled by the uploader's max_width,
     * so only the two failures that cannot be auto-corrected are rejected here.
     *
     * @param array $dimensions [width, height]
     * @return true|\WP_Error
     */
    protected static function validateIconDimensions($dimensions)
    {
        list($width, $height) = $dimensions;

        if ($width !== $height) {
            return new \WP_Error('pwa_icon_not_square', sprintf(
                /* translators: %1$d is the uploaded width in pixels, %2$d the height. */
                __('The app icon must be square. This one is %1$dx%2$d pixels.', 'fluent-community-pro'),
                $width,
                $height
            ));
        }

        if ($width < PwaHelper::MIN_ICON_SIZE) {
            return new \WP_Error('pwa_icon_too_small', sprintf(
                /* translators: %1$d is the required minimum in pixels, %2$d the uploaded width, %3$d the uploaded height. */
                __('The app icon must be at least %1$dx%1$d pixels. This one is %2$dx%3$d pixels.', 'fluent-community-pro'),
                PwaHelper::MIN_ICON_SIZE,
                $width,
                $height
            ));
        }

        return true;
    }
}
