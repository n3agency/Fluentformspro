<?php

namespace FluentCommunityPro\App\Modules\Pwa;

use FluentCommunity\App\Functions\Utility;
use FluentCommunity\App\Services\CustomSanitizer;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;

class PwaHelper
{
    const SHORT_NAME_MAX_LENGTH = 12;

    const APP_NAME_MAX_LENGTH = 60;

    const MIN_ICON_SIZE = 192;

    const MAX_ICON_SIZE = 512;

    protected static $cachedSettings = null;

    /**
     * Read up to eight times per portal render. Utility::getFromCache() only
     * stores truthy values, so an unsaved config is an empty array and every
     * one of those calls would hit fcom_meta again.
     */
    public static function getSettings()
    {
        if (self::$cachedSettings !== null) {
            return self::$cachedSettings;
        }

        $settings = Utility::getOption('fluent_community_pwa_settings', []);

        if (!is_array($settings)) {
            $settings = [];
        }

        self::$cachedSettings = wp_parse_args($settings, self::getDefaultSettings());

        return self::$cachedSettings;
    }

    public static function getDefaultSettings()
    {
        return [
            'app_name'            => '',
            'short_name'          => '',
            'icon_source'         => 'default',
            'custom_icon'         => '',
            'icon_sizes'          => '',
            'background_color'    => '',
            'install_entry'       => 'yes',
            'install_position'    => 'bottom',
            'install_dismissible' => 'no'
        ];
    }

    public static function getInstallPosition()
    {
        $position = Arr::get(self::getSettings(), 'install_position');

        return $position === 'top' ? 'top' : 'bottom';
    }

    public static function isInstallEntryEnabled()
    {
        return Arr::get(self::getSettings(), 'install_entry') === 'yes';
    }

    public static function isInstallDismissible()
    {
        return Arr::get(self::getSettings(), 'install_dismissible') === 'yes';
    }

    public static function updateSettings($settings)
    {
        Utility::updateOption('fluent_community_pwa_settings', $settings);

        self::$cachedSettings = null;

        return $settings;
    }

    public static function getAppName()
    {
        $settings = self::getSettings();
        $appName = Arr::get($settings, 'app_name', '');

        if (!$appName) {
            $appName = Arr::get(Helper::generalSettings(), 'site_title', get_bloginfo('name'));
        }

        return $appName;
    }

    public static function getShortName()
    {
        $settings = self::getSettings();
        $shortName = Arr::get($settings, 'short_name', '');

        if (!$shortName) {
            $shortName = mb_substr(self::getAppName(), 0, self::SHORT_NAME_MAX_LENGTH);
        }

        return $shortName;
    }

    public static function getDescription()
    {
        $description = get_bloginfo('description');

        /**
         * Filter the PWA manifest description.
         *
         * @param string $description
         */
        return (string)apply_filters('fluent_community/pwa/description', $description);
    }

    /**
     * Screen orientation lock. Defaults to portrait because the portal is a
     * feed-first phone layout; fullscreen video releases the lock on its own,
     * so lesson playback is unaffected. Sites that need rotation can return
     * 'any' from the filter below.
     *
     * @return string
     */
    public static function getOrientation()
    {
        /**
         * Filter the PWA manifest orientation lock.
         *
         * @param string $orientation
         */
        $orientation = (string)apply_filters('fluent_community/pwa/orientation', 'portrait');

        $allowed = ['any', 'natural', 'portrait', 'landscape', 'portrait-primary',
            'portrait-secondary', 'landscape-primary', 'landscape-secondary'];

        return in_array($orientation, $allowed, true) ? $orientation : 'portrait';
    }

    /**
     * Manifest icon purpose. Defaults to 'any'; a mask-safe icon can opt into
     * 'any maskable' via the filter. Unknown tokens are dropped.
     *
     * @return string
     */
    public static function getIconPurpose()
    {
        // @param string Space-separated list of any|maskable|monochrome.
        $purpose = (string)apply_filters('fluent_community/pwa/icon_purpose', 'any');

        $allowed = ['any', 'maskable', 'monochrome'];
        $tokens = [];

        // Keep only valid tokens, in order, once each — an unknown one silently kills the install offer.
        foreach (preg_split('/\s+/', trim($purpose)) as $token) {
            if (in_array($token, $allowed, true) && !in_array($token, $tokens, true)) {
                $tokens[] = $token;
            }
        }

        return $tokens ? implode(' ', $tokens) : 'any';
    }

    public static function getIconUrl()
    {
        $settings = self::getSettings();

        if (Arr::get($settings, 'icon_source') === 'custom' && Arr::get($settings, 'custom_icon')) {
            $iconUrl = Arr::get($settings, 'custom_icon');
        } else {
            $iconUrl = self::getDefaultIconUrl();
        }

        if (!$iconUrl) {
            return '';
        }

        // Stored urls can carry a stale scheme. An http:// icon on an https portal
        // is blocked as mixed content and fails Chrome's installability checks.
        return set_url_scheme($iconUrl);
    }

    /**
     * The icon the default source would give, regardless of what is saved. The
     * site icon is preferred over the community logo because WordPress forces it
     * square on upload, and a logo is usually a wide wordmark — which browsers
     * refuse, taking the install offer with it.
     *
     * @return string
     */
    public static function getDefaultIconUrl()
    {
        $iconUrl = get_site_icon_url(512);

        if (!$iconUrl) {
            $iconUrl = Arr::get(Helper::generalSettings(), 'logo', '');
        }

        return $iconUrl;
    }

    /**
     * What the default source resolves to, for the settings screen. Those
     * sources live outside these settings — an admin can clear the site icon or
     * the logo at any time — so the drawer asks on every open rather than
     * trusting what was validated at save. Deliberately independent of the saved
     * icon_source, so switching the radio previews the right thing before saving.
     *
     * @return array
     */
    public static function getDefaultIcon()
    {
        $iconUrl = self::getDefaultIconUrl();

        if ($iconUrl) {
            $iconUrl = set_url_scheme($iconUrl);
        }

        if (!$iconUrl) {
            return ['url' => '', 'sizes' => '', 'is_square' => null];
        }

        $dimensions = self::getIconDimensions($iconUrl);

        return [
            'url'   => $iconUrl,
            'sizes' => $dimensions ? $dimensions[0] . 'x' . $dimensions[1] : '',
            'is_square' => $dimensions ? $dimensions[0] === $dimensions[1] : null
        ];
    }

    public static function getButtonText()
    {
        /**
         * Filter the portal install entry button text.
         *
         * @param string $buttonText
         */
        return (string)apply_filters('fluent_community/pwa/install_button_text', __('Install App', 'fluent-community-pro'));
    }

    /**
     * Markup for the install button glyph. The shipped default is trusted and
     * passed through untouched — running it through sanitizeSvg() would strip
     * stroke-linecap / stroke-linejoin / aria-hidden, which are not in its
     * allowlist, and that sanitizer also short-circuits for unfiltered_html
     * users, so admins and members would end up seeing different icons.
     * Anything a filter returns is untrusted and does get sanitized.
     *
     * @return string
     */
    public static function getButtonIcon()
    {
        $default = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><path d="M12 7v7"/><path d="m9 11 3 3 3-3"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>';

        /**
         * Filter the portal install entry button icon markup.
         *
         * @param string $icon Inline svg. Use stroke="currentColor" so the glyph
         *                     follows the portal color mode.
         */
        $icon = (string)apply_filters('fluent_community/pwa/install_button_icon', $default);

        if ($icon === $default) {
            return $default;
        }

        return CustomSanitizer::sanitizeSvg($icon);
    }

    /**
     * The app title bar / browser chrome color. Follows the portal top bar
     * background per color mode so the app window blends into the portal header
     * rather than picking up the brand button color.
     *
     * @param string $mode light|dark
     * @return string
     */
    public static function getThemeColor($mode = 'light')
    {
        $fallback = $mode === 'dark' ? '#2B2E33' : '#ffffff';
        $color = self::getSchemaColor($mode, 'fcom_top_menu', 'primary_bg', $fallback);

        /**
         * Filter the PWA theme (title bar) color for a color mode.
         *
         * @param string $color
         * @param string $mode light|dark
         */
        return (string)apply_filters('fluent_community/pwa/theme_color', $color, $mode);
    }

    /**
     * The splash screen background. Admin configurable — the manifest holds a
     * single static value, so an explicit choice applies to every color mode.
     *
     * @param string $mode light|dark
     * @return string
     */
    public static function getBackgroundColor($mode = 'light')
    {
        $settings = self::getSettings();
        $color = Arr::get($settings, 'background_color', '');

        if (!$color) {
            $fallback = $mode === 'dark' ? '#2B2E33' : '#ffffff';
            $color = self::getSchemaColor($mode, 'body', 'primary_bg', $fallback);
        }

        /**
         * Filter the PWA splash screen background color for a color mode.
         *
         * @param string $color
         * @param string $mode light|dark
         */
        return (string)apply_filters('fluent_community/pwa/background_color', $color, $mode);
    }

    protected static function getSchemaColor($mode, $selector, $property, $fallback)
    {
        $schemas = Utility::getColorSchemas();
        $colorConfig = Utility::getColorConfig('view');

        if ($mode === 'dark') {
            $skinName = Arr::get($colorConfig, 'dark_schema', 'default');
            $path = "darkSkins.$skinName.selectors.$selector.$property";
        } else {
            $skinName = Arr::get($colorConfig, 'light_schema', 'default');
            $path = "lightSkins.$skinName.selectors.$selector.$property";
        }

        $color = Arr::get($schemas, $path, '');

        return $color ? $color : $fallback;
    }

    public static function buildManifest()
    {
        // Helper::baseUrl('') stays a plain path for hash-routed portals too —
        // a #/ fragment would make the manifest scope invalid.
        $portalUrl = Helper::baseUrl('');
        $iconUrl = esc_url_raw(self::getIconUrl());

        $manifest = [
            'id'               => esc_url_raw(home_url('/fluent-community-app')),
            'name'             => self::getAppName(),
            'short_name'       => self::getShortName(),
            'lang'             => get_bloginfo('language'),
            'dir'              => Helper::isRtl() ? 'rtl' : 'ltr',
            'start_url'        => esc_url_raw($portalUrl),
            // Scope the whole site so template pages stay in the installed app. Filterable.
            'scope'            => esc_url_raw(apply_filters('fluent_community/pwa/manifest_scope', home_url('/'))),
            'display'          => 'standalone',
            'orientation'      => self::getOrientation(),
            // Static install-time values; the runtime title bar color follows the
            // portal color mode through the theme-color meta tag.
            'theme_color'      => self::getThemeColor('light'),
            'background_color' => self::getBackgroundColor('light')
        ];

        $description = self::getDescription();

        if ($description) {
            $manifest['description'] = $description;
        }

        if ($iconUrl) {
            $manifest['icons'] = [
                [
                    'src'     => $iconUrl,
                    'sizes'   => self::getIconSizes($iconUrl),
                    'type'    => self::getIconMimeType($iconUrl),
                    'purpose' => self::getIconPurpose()
                ]
            ];
        }

        return $manifest;
    }

    /**
     * Pixel dimensions of an uploaded icon as [width, height], or an empty array
     * when they cannot be determined. The media row's own meta is preferred: it
     * is recorded at upload time, before the cloud storage driver moves the file
     * off local disk, so it is the only source that works on S3 / R2 / Bunny.
     *
     * @param string $iconUrl
     * @param \FluentCommunity\App\Models\Media|null $media
     * @return array
     */
    public static function getIconDimensions($iconUrl, $media = null)
    {
        if ($media) {
            $width = (int)Arr::get($media->settings, 'width');
            $height = (int)Arr::get($media->settings, 'height');

            if ($width && $height) {
                return [$width, $height];
            }
        }

        $iconPath = self::getLocalIconPath($iconUrl);

        if (!$iconPath) {
            return [];
        }

        $dimensions = wp_getimagesize($iconPath);

        if (empty($dimensions[0]) || empty($dimensions[1])) {
            return [];
        }

        return [(int)$dimensions[0], (int)$dimensions[1]];
    }

    /**
     * Real pixel dimensions of the icon. Browsers verify the declared size
     * against the decoded image, so a guess here can fail installability.
     *
     * @param string $iconUrl
     * @return string
     */
    public static function getIconSizes($iconUrl)
    {
        static $cache = [];

        if (isset($cache[$iconUrl])) {
            return $cache[$iconUrl];
        }

        $settings = self::getSettings();
        $storedSizes = Arr::get($settings, 'icon_sizes', '');

        // Measured once at save time. Remote icons cannot be measured at render
        // time at all, and this also keeps wp_getimagesize() off every request.
        if ($storedSizes && Arr::get($settings, 'custom_icon') === $iconUrl) {
            $cache[$iconUrl] = $storedSizes;
            return $storedSizes;
        }

        $sizes = '512x512';
        $dimensions = self::getIconDimensions($iconUrl);

        if ($dimensions) {
            $sizes = $dimensions[0] . 'x' . $dimensions[1];
        }

        $cache[$iconUrl] = $sizes;

        return $sizes;
    }

    protected static function getLocalIconPath($iconUrl)
    {
        $iconUrl = strtok($iconUrl, '?');
        $uploadDir = wp_upload_dir();

        $baseUrl = set_url_scheme(Arr::get($uploadDir, 'baseurl', ''));
        $baseDir = Arr::get($uploadDir, 'basedir', '');

        $baseUrl = $baseUrl ? trailingslashit($baseUrl) : '';

        if (!$baseUrl || !$baseDir || strpos(set_url_scheme($iconUrl), $baseUrl) !== 0) {
            return '';
        }

        $relativePath = ltrim(substr(set_url_scheme($iconUrl), strlen($baseUrl)), '/');

        if (!$relativePath || strpos($relativePath, '..') !== false) {
            return '';
        }

        $iconPath = trailingslashit($baseDir) . $relativePath;

        if (!file_exists($iconPath)) {
            return '';
        }

        $realPath = realpath($iconPath);
        $realBase = realpath($baseDir);

        if (!$realPath || !$realBase || strpos($realPath, trailingslashit($realBase)) !== 0) {
            return '';
        }

        return $realPath;
    }

    public static function getIconMimeType($iconUrl)
    {
        $extension = strtolower(pathinfo(wp_parse_url($iconUrl, PHP_URL_PATH), PATHINFO_EXTENSION));

        $mimeMap = [
            'png'  => 'image/png',
            'jpg'  => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'gif'  => 'image/gif',
            'webp' => 'image/webp',
            'svg'  => 'image/svg+xml',
            'ico'  => 'image/x-icon'
        ];

        return isset($mimeMap[$extension]) ? $mimeMap[$extension] : 'image/png';
    }
}
