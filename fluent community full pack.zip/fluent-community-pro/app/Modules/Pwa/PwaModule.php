<?php

namespace FluentCommunityPro\App\Modules\Pwa;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Foundation\Application;
use FluentCommunity\Framework\Support\Arr;

class PwaModule
{
    protected static $positionHooks = [
        'top'    => 'fluent_community/before_sidebar_wrap',
        'bottom' => 'fluent_community/after_sidebar_wrap'
    ];

    protected static $headPrinted = false;

    public function register(Application $app, $features)
    {
        /*
         * register the routes
         */
        $app->router->group(function ($router) {
            require_once __DIR__ . '/Http/pwa_api.php';
        });

        if (!isset($features['pwa_module']) || $features['pwa_module'] !== 'yes') {
            return;
        }

        add_filter('query_vars', [$this, 'registerQueryVar']);
        add_action('template_redirect', [$this, 'maybeServeManifest'], 0);
        add_action('fluent_community/portal_head', [$this, 'printHeadTags']);
        add_action('fluent_community/template_header', [$this, 'printHeadTags']);
        add_action('fluent_community/headless/head', [$this, 'printHeadTags']);
        add_filter('fluent_community/general_portal_vars', [$this, 'pushPortalVars']);
        add_filter('fluent_community/render_default_touch_icon', '__return_false');

        // Both ends of the sidebar are hooked so the settings read stays out of
        // the boot path; each callback knows which position it belongs to.
        foreach (self::$positionHooks as $position => $hook) {
            add_action($hook, function () use ($position) {
                $this->renderInstallRow($position);
            });
        }
    }

    public function registerQueryVar($vars)
    {
        $vars[] = 'fcom_pwa';
        return $vars;
    }

    public function maybeServeManifest()
    {
        // Query-var based serving (no rewrite rules): a path-like .webmanifest url
        // gets intercepted by static-file server rules on some hosts before php runs.
        if (get_query_var('fcom_pwa') !== 'manifest') {
            return;
        }

        // fcom_pwa is a public query var, so without this the manifest would
        // answer on every front end url — turning any 404 into a soft 200 and
        // shadowing other template_redirect handlers, since this runs at 0.
        if (!$this->isPortalRequest() || !$this->isReadRequest()) {
            return;
        }

        $this->serveManifest();
    }

    protected function isReadRequest()
    {
        $method = isset($_SERVER['REQUEST_METHOD']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'])) : 'GET';

        // HEAD is a GET without a body, and monitoring and cdn prefetches use it.
        return in_array(strtoupper($method), ['GET', 'HEAD'], true);
    }

    protected function isPortalRequest()
    {
        return self::getPortalRoute() === '';
    }

    /**
     * The portal route the request resolved to, relative to the portal base.
     * Empty string for the portal home, null when the request is not under the
     * portal at all.
     *
     * @return string|null
     */
    protected static function getPortalRoute()
    {
        global $wp;

        $requestPath = isset($wp->request) ? $wp->request : '';
        $requestPath = trim((string)$requestPath, '/');

        // getPortalSlug() is relative to home_url(), which is the frame
        // $wp->request is already expressed in. Parsing baseUrl() instead would
        // carry the wp directory on a subdirectory install, and $wp->request
        // never has it, so nothing would ever match there.
        $portalSlug = trim((string)Helper::getPortalSlug(), '/');

        if ($portalSlug === '') {
            return $requestPath;
        }

        if ($requestPath === $portalSlug) {
            return '';
        }

        // Segment boundary, otherwise a slug of 'hub' would also claim 'hubspot'.
        if (strpos($requestPath, $portalSlug . '/') === 0) {
            return trim(substr($requestPath, strlen($portalSlug) + 1), '/');
        }

        return null;
    }

    /**
     * The settings screens run on the portal shell and reuse its sidebar — the
     * admin app teleports its own menu into #fcom_menu_sidebar, which sits in
     * the same view as the install row. The row is outside #fcom_sidebar_wrap,
     * so it survives that swap and would render beside the settings menu.
     *
     * @return bool
     */
    protected static function isSettingsRoute()
    {
        $route = self::getPortalRoute();

        if ($route === null) {
            return false;
        }

        return $route === 'admin' || strpos($route, 'admin/') === 0;
    }

    public function printHeadTags()
    {
        if (self::$headPrinted) {
            return;
        }

        self::$headPrinted = true;

        // iOS ignores the manifest icons, so the apple-touch-icon tag is the only
        // home screen icon source. Its size is declared so it wins over the site icon.
        $iconUrl = PwaHelper::getIconUrl();
        ?>
        <link rel="manifest" href="<?php echo esc_url($this->getManifestUrl()); ?>">
        <?php if ($iconUrl): ?>
        <link rel="apple-touch-icon" sizes="<?php echo esc_attr(PwaHelper::getIconSizes($iconUrl)); ?>" href="<?php echo esc_url($iconUrl); ?>">
        <?php endif; ?>
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-title" content="<?php echo esc_attr(PwaHelper::getShortName()); ?>">
        <?php
        if (PwaHelper::isInstallEntryEnabled()) {
            $this->printInstallRowStyles();
        }
    }

    public function pushPortalVars($vars)
    {
        $installEntry = PwaHelper::isInstallEntryEnabled();

        $vars['pwa'] = [
            'install_entry'       => $installEntry ? 'yes' : 'no',
            'install_dismissible' => PwaHelper::isInstallDismissible() ? 'yes' : 'no',
            'theme_color'         => PwaHelper::getThemeColor('light'),
            'theme_color_dark'    => PwaHelper::getThemeColor('dark'),
        ];

        if ($installEntry) {
            $vars['pwa']['install_icon'] = esc_url(PwaHelper::getIconUrl());
            $vars['pwa']['install_instructions'] = self::getInstallInstructions();
        }

        return $vars;
    }

    /**
     * Steps for browsers without a programmatic install. The glyphs are inlined
     * into the sentence so a member can match what they read against what they
     * see in the browser chrome, rather than hunting for a named button.
     *
     * @return array
     */
    protected static function getInstallInstructions()
    {
        $stepTags = ['strong' => [], 'em' => []];
        $close    = __('Close', 'fluent-community-pro');
        $title    = __('Install the app', 'fluent-community-pro');

        // The app being installed is identified by the card below the title
        // rather than by the title itself, so a long community name cannot
        // push the heading onto three lines on a narrow phone.
        $app = [
            'icon' => esc_url(PwaHelper::getIconUrl()),
            'name' => PwaHelper::getAppName(),
            'host' => wp_parse_url(home_url(), PHP_URL_HOST)
        ];

        // Static local markup, so it is appended to the already-sanitized
        // sentence instead of widening the kses allowlist for every step.
        $shareGlyph = '<svg class="fcom_pwa_instruct_glyph" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="' . esc_attr__('Share', 'fluent-community-pro') . '"><path d="M12 3v12"/><path d="m8 7 4-4 4 4"/><path d="M4 13v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-6"/></svg>';
        $menuGlyph  = '<svg class="fcom_pwa_instruct_glyph" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" role="img" aria-label="' . esc_attr__('Menu', 'fluent-community-pro') . '"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>';
        $homeChip   = '<span class="fcom_pwa_instruct_chip">' . esc_html__('Add to Home Screen', 'fluent-community-pro') . '</span>';

        $iconUrl = PwaHelper::getIconUrl();
        $appIcon = $iconUrl ? '<img class="fcom_pwa_instruct_appicon" src="' . esc_url($iconUrl) . '" alt="" />' : '';

        // The icon step is dropped rather than rendered empty when no icon
        // resolves, since there is nothing for the member to look for.
        $iconStep = $appIcon ? sprintf(
            /* translators: %s is the app icon image. */
            wp_kses(__('Look for the %s icon on your home screen', 'fluent-community-pro'), $stepTags),
            $appIcon
        ) : '';

        $androidSteps = [
            sprintf(
                /* translators: %s is the browser menu icon. */
                wp_kses(__('Open the browser <strong>menu</strong> %s', 'fluent-community-pro'), $stepTags),
                $menuGlyph
            ),
            sprintf(
                /* translators: %s is the "Add to Home Screen" menu item. */
                wp_kses(__('Tap <strong>Install</strong> or %s', 'fluent-community-pro'), $stepTags),
                $homeChip
            ),
        ];

        $iosSteps = [
            sprintf(
                /* translators: %s is the browser Share icon. */
                wp_kses(__('Press %s in the browser menu', 'fluent-community-pro'), $stepTags),
                $shareGlyph
            ),
            sprintf(
                /* translators: %s is the "Add to Home Screen" menu item. */
                wp_kses(__('Scroll down and tap %s', 'fluent-community-pro'), $stepTags),
                $homeChip
            ),
        ];

        if ($iconStep) {
            $androidSteps[] = $iconStep;
            $iosSteps[] = $iconStep;
        }

        return [
            'android' => [
                'title'       => $title,
                'app'         => $app,
                'steps'       => $androidSteps,
                'close_label' => $close,
            ],
            'ios' => [
                'title'       => $title,
                'app'         => $app,
                'steps'       => $iosSteps,
                'close_label' => $close,
            ],
        ];
    }

    public function renderInstallRow($position)
    {
        if (!self::$headPrinted || self::isSettingsRoute() || PwaHelper::getInstallPosition() !== $position) {
            return;
        }

        if (!PwaHelper::isInstallEntryEnabled()) {
            return;
        }

        $buttonText = PwaHelper::getButtonText();
        ?>
        <div class="fcom_pwa_install_row <?php echo esc_attr('fcom_pwa_install_' . $position); ?>">
            <button type="button" class="fcom_pwa_install_btn">
                <?php echo PwaHelper::getButtonIcon(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- svg markup, sanitized in getButtonIcon() ?>
                <span><?php echo esc_html($buttonText); ?></span>
            </button>
            <?php if (PwaHelper::isInstallDismissible()): ?>
                <button type="button" class="fcom_pwa_install_dismiss" aria-label="<?php echo esc_attr__('Hide Install App', 'fluent-community-pro'); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
            <?php endif; ?>
        </div>
        <?php
    }

    protected function printInstallRowStyles()
    {
        ?>
        <style>
            .fcom_pwa_install_row {
                display: none;
            }

            @media (max-width: 768px) {
                .fcom_pwa_install_row.fcom_pwa_available {
                    display: flex;
                    align-items: center;
                    margin: 12px 24px 8px 16px;
                    border: 1px solid var(--fcom-primary-border, #e4e7eb);
                    border-radius: 8px;
                    background: var(--fcom-secondary-bg, transparent);
                }

                .space_contents:has(.fcom_pwa_install_row.fcom_pwa_install_top.fcom_pwa_available) {
                    justify-content: flex-start;
                }

                .fcom_pwa_install_row.fcom_pwa_install_bottom.fcom_pwa_available {
                    margin-top: auto;
                }

                .fcom_pwa_install_row.fcom_pwa_install_bottom.fcom_pwa_available ~ .fcom_side_footer {
                    margin-top: 0;
                }

                .fcom_pwa_install_row .fcom_pwa_install_btn {
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    flex: 1 1 auto;
                    min-width: 0;
                    padding: 8px 8px 8px 10px;
                    border: 0;
                    border-radius: 8px;
                    background: none;
                    color: var(--fcom-primary-text, inherit);
                    font-size: 14px;
                    font-weight: 500;
                    text-align: left;
                    cursor: pointer;
                }

                .fcom_pwa_install_row .fcom_pwa_install_dismiss {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    flex: 0 0 auto;
                    padding: 8px 10px;
                    border: 0;
                    border-radius: 8px;
                    background: none;
                    color: var(--fcom-secondary-text, inherit);
                    opacity: 0.6;
                    cursor: pointer;
                }

                .fcom_pwa_install_row .fcom_pwa_install_btn:hover {
                    background: var(--fcom-menu-bg-hover, rgba(0, 0, 0, 0.04));
                }

                .fcom_pwa_install_row .fcom_pwa_install_dismiss:hover {
                    opacity: 1;
                }

                .fcom_pwa_install_row .fcom_pwa_install_btn:focus-visible,
                .fcom_pwa_install_row .fcom_pwa_install_dismiss:focus-visible {
                    outline: 2px solid currentColor;
                    outline-offset: 2px;
                }
            }

            .fcom_pwa_instruct_overlay {
                position: fixed;
                inset: 0;
                z-index: 100000;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 16px;
                background: rgba(0, 0, 0, 0.5);
            }

            .fcom_pwa_instruct_modal {
                width: 100%;
                max-width: 400px;
                overflow: hidden;
                border: 1px solid var(--fcom-primary-border, #e3e8ee);
                border-radius: 8px;
                background: var(--fcom-primary-bg, #fff);
                color: var(--fcom-primary-text, #19283a);
                box-shadow: 0 20px 48px -12px rgba(0, 0, 0, 0.35);
                animation: fcom_pwa_instruct_pop 0.18s ease-out;
            }

            @keyframes fcom_pwa_instruct_pop {
                from { opacity: 0; transform: translateY(8px) scale(0.98); }
                to { opacity: 1; transform: none; }
            }

            .fcom_pwa_instruct_header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 12px;
                padding: 18px 20px 0;
            }

            .fcom_pwa_instruct_heading {
                min-width: 0;
            }

            .fcom_pwa_instruct_header h3 {
                margin: 0;
                font-size: 18px;
                font-weight: 600;
                line-height: 24px;
            }

            .fcom_pwa_instruct_app {
                display: flex;
                align-items: center;
                gap: 14px;
                margin: 16px 20px 4px;
                padding: 12px 14px;
                border: 1px solid var(--fcom-primary-border, #e3e8ee);
                border-radius: 12px;
            }

            .fcom_pwa_instruct_icon {
                flex: 0 0 auto;
                width: 44px;
                height: 44px;
                border-radius: 10px;
                object-fit: cover;
            }

            .fcom_pwa_instruct_app_meta {
                min-width: 0;
            }

            .fcom_pwa_instruct_app_name {
                display: block;
                font-size: 16px;
                font-weight: 600;
                line-height: 1.4;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }

            .fcom_pwa_instruct_app_host {
                display: block;
                font-size: 14px;
                line-height: 1.4;
                color: var(--fcom-secondary-text, #6b7280);
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }

            .fcom_pwa_instruct_close {
                display: flex;
                align-items: center;
                justify-content: center;
                flex: 0 0 auto;
                width: 32px;
                height: 32px;
                margin-right: -6px;
                padding: 0;
                border: 0;
                border-radius: 8px;
                background: none;
                font-size: 18px;
                line-height: 1;
                cursor: pointer;
                color: var(--fcom-secondary-text, #6b7280);
                transition: background 0.15s ease, color 0.15s ease;
            }

            .fcom_pwa_instruct_close:hover {
                background: var(--fcom-active-bg, #f0f3f5);
                color: var(--fcom-primary-text, #19283a);
            }

            .fcom_pwa_instruct_steps {
                display: flex;
                flex-direction: column;
                gap: 16px;
                padding: 18px 20px 22px;
            }

            .fcom_pwa_instruct_step {
                display: flex;
                align-items: flex-start;
                gap: 8px;
            }

            /* Plain numeral rather than a filled badge, so the eye lands on the
               glyph in the step text instead of on the counter. */
            .fcom_pwa_instruct_num {
                flex: 0 0 auto;
                min-width: 14px;
                font-size: 15px;
                font-weight: 700;
                line-height: 1.5;
            }

            .fcom_pwa_instruct_num::after {
                content: '.';
            }

            .fcom_pwa_instruct_text {
                font-size: 15px;
                line-height: 1.5;
            }

            .fcom_pwa_instruct_text strong {
                font-weight: 600;
            }

            /* Glyphs sit inside a sentence, so they follow the text baseline
               rather than the line box. */
            .fcom_pwa_instruct_glyph {
                margin: 0 2px;
                vertical-align: -3px;
                color: var(--fcom-text-link, #2563eb);
            }

            .fcom_pwa_instruct_chip {
                display: inline;
                padding: 1px 8px;
                border: 1px solid var(--fcom-primary-border, #e3e8ee);
                border-radius: 6px;
                background: var(--fcom-active-bg, #f0f3f5);
                font-size: 14px;
                font-weight: 500;
                white-space: nowrap;
            }

            .fcom_pwa_instruct_appicon {
                width: 24px;
                height: 24px;
                margin: 0 2px;
                border-radius: 6px;
                object-fit: cover;
                vertical-align: -7px;
            }
        </style>
        <?php
    }

    protected function getManifestUrl()
    {
        // Helper::baseUrl($path) appends a #/ prefix for hash-routed portals which
        // would break real asset URLs, so the query arg goes on the bare base.
        return add_query_arg('fcom_pwa', 'manifest', Helper::baseUrl(''));
    }

    protected function serveManifest()
    {
        // The main query may have resolved to a 404 (e.g. root-mounted portals);
        // a manifest served with a 404 status is discarded by browsers.
        status_header(200);
        do_action('litespeed_control_set_nocache', 'fluentcommunity pwa manifest'); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
        nocache_headers();
        header('Content-Type: application/manifest+json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        echo wp_json_encode(PwaHelper::buildManifest(), JSON_UNESCAPED_SLASHES); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit;
    }
}
