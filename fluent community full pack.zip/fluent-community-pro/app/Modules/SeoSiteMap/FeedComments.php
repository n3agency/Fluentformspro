<?php

namespace FluentCommunityPro\App\Modules\SeoSiteMap;

use FluentCommunity\App\Models\Comment;
use FluentCommunity\App\Services\ProfileHelper;

/**
 * The comments an anonymous post page describes, loaded once per request.
 *
 * The JSON-LD (head) and the pre-rendered body (later in the same request) both
 * want the same thread, so it is queried once and bounded once: a popular post can
 * carry thousands of comments, and neither a crawler nor a first paint needs them
 * all. The SPA fetches the full thread itself through feeds/{id}/comments.
 *
 * Oldest first, which is the order the REST endpoint uses and the order a reader
 * would follow the thread in.
 */
class FeedComments
{
    /** @var array<int, \FluentCommunity\Framework\Database\Orm\Collection> */
    protected static $loaded = [];

    public static function forFeed($feedId)
    {
        $feedId = (int) $feedId;

        if (!isset(self::$loaded[$feedId])) {
            self::$loaded[$feedId] = self::load($feedId);
        }

        return self::$loaded[$feedId];
    }

    public static function limit()
    {
        return max(0, (int) apply_filters('fluent_community/seo/comment_limit', 100));
    }

    public static function reset()
    {
        self::$loaded = [];
    }

    protected static function load($feedId)
    {
        return Comment::where('post_id', $feedId)
            ->where('status', 'published')
            ->orderBy('created_at', 'asc')
            ->with([
                'xprofile' => function ($q) {
                    $q->select(ProfileHelper::getXProfilePublicFields());
                },
            ])
            ->limit(self::limit())
            ->get();
    }
}
