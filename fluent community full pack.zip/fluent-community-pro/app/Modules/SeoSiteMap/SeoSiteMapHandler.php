<?php

namespace FluentCommunityPro\App\Modules\SeoSiteMap;

use FluentCommunity\App\Models\BaseSpace;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;

class SeoSiteMapHandler
{
    /** @var SpacePreRenderer|null */
    protected $spacePreRenderer = null;

    public function register()
    {
        add_action('fluent_community/portal_head_meta', [$this, 'addSeoIndexTag'], 10, 1);

        add_action('fluent_community/rendering_path_ssr_site-maps', [$this, 'renderSiteMaps'], 10, 1);

        add_action('init', function () {
            $enableSitemap = apply_filters_deprecated('fluent_communuty/add_sitemap_provider', [true], '2.8.1', 'fluent_community/add_sitemap_provider');
            if (apply_filters('fluent_community/add_sitemap_provider', $enableSitemap)) {
                wp_register_sitemap_provider('fluentcommunity', new CommunitySiteMapProvider());
            }
        });


        (new FeedPreRenderer())->register();
        $this->spacePreRenderer()->register();
        (new CoursePreRenderer())->register();

        add_filter('fluent_community/portal_page_meta', [$this, 'filterPageMeta'], 10, 3);

        add_filter('fluent_community/feed_view_json_ld', [$this, 'pushJsonLdData'], 10, 3);
        add_filter('fluent_community/course_view_json_ld', [$this, 'pushJsonLdDataForCourse'], 10, 3);
        add_filter('fluent_community/lesson_view_json_ld', [$this, 'pushJsonLdDataForLesson'], 10, 4);
    }

    public function renderSiteMaps($paths = [])
    {
        if (!$this->isPublicCommunity() || count($paths) < 2) {
            $rendered = new \WP_Sitemaps_Renderer();
            status_header(200);
            echo $rendered->render_index([[
                'loc' => Helper::baseUrl('/')
            ]]);
            die();
        }

        $requestedMap = $paths[1];
        if ($requestedMap == 'style.xsl' || $requestedMap == 'style-index.xsl') {
            $this->renderStyleSheet($requestedMap);
            die();
        }

        // remove the xml extension
        $requestedMap = str_replace('.xml', '', $requestedMap);

        // explode with -
        $requestedMap = explode('-', $requestedMap);

        $pageNum = Arr::get($requestedMap, 1, 1);
        $objectType = Arr::get($requestedMap, 0);
        $validObjectTypes = [
            'index',
            'feeds',
            'spaces',
            'courses',
            'lessons',
            'pages'
        ];

        if (!in_array($objectType, $validObjectTypes)) {
            return;
        }

        $lists = [];
        $sitemapQuery = new SitemapQuery(1000, $pageNum);

        if ($objectType == 'index') {
            $lists = $this->getIndexLinkList();
        } else if ($objectType == 'feeds') {
            $lists = $sitemapQuery->getFeeds();
        } else if ($objectType == 'spaces') {
            $lists = $sitemapQuery->getSpaces();
        } else if ($objectType == 'courses') {
            $lists = $sitemapQuery->getCourses();
        } else if ($objectType == 'lessons') {
            $lists = $sitemapQuery->getLessons();
        } else if ($objectType == 'pages') {
            $lists = $sitemapQuery->getPages();
        }

        $isRootMap = Helper::getPortalSlug(false) === '';

        add_filter('wp_sitemaps_stylesheet_url', function ($url) use ($isRootMap) {
            if ($isRootMap) {
                return $url;
            }
            return Helper::baseUrl('site-maps/style.xsl');
        });

        add_filter('wp_sitemaps_stylesheet_index_url', function ($url) use ($isRootMap) {
            if ($isRootMap) {
                return $url;
            }
            return Helper::baseUrl('site-maps/style-index.xsl');
        });

        $rendered = new \WP_Sitemaps_Renderer();

        status_header(200);

        if ($objectType == 'index') {
            echo $rendered->render_index($lists);
        } else {
            $rendered->render_sitemap($lists);
        }

        die();
    }

    public function getIndexLinkList()
    {
        $cacheKey = 'fcom_sitemap_index_links';
        $cached = get_transient($cacheKey);
        if (is_array($cached)) {
            return $cached;
        }

        $sitemapQuery = new SitemapQuery(1000);
        $feedsPageCount = $sitemapQuery->getMaxPageNums('feeds');
        $spacePageCount = $sitemapQuery->getMaxPageNums('spaces');
        $lessonsPageCount = $sitemapQuery->getMaxPageNums('lessons');
        $coursesPageCount = $sitemapQuery->getMaxPageNums('courses');
        $spacePagesCount = $sitemapQuery->getMaxPageNums('pages');

        $allLinks = [];

        if ($feedsPageCount > 0) {
            for ($i = 1; $i <= $feedsPageCount; $i++) {
                $allLinks[] = [
                    'loc' => Helper::baseUrl('site-maps/feeds-' . $i . '.xml')
                ];
            }
        }

        if ($spacePageCount > 0) {
            for ($i = 1; $i <= $spacePageCount; $i++) {
                $allLinks[] = [
                    'loc' => Helper::baseUrl('site-maps/spaces-' . $i . '.xml')
                ];
            }
        }

        if ($coursesPageCount > 0) {
            for ($i = 1; $i <= $coursesPageCount; $i++) {
                $allLinks[] = [
                    'loc' => Helper::baseUrl('site-maps/courses-' . $i . '.xml')
                ];
            }
        }

        if ($lessonsPageCount > 0) {
            for ($i = 1; $i <= $lessonsPageCount; $i++) {
                $allLinks[] = [
                    'loc' => Helper::baseUrl('site-maps/lessons-' . $i . '.xml')
                ];
            }
        }

        if ($spacePagesCount > 0) {
            for ($i = 1; $i <= $spacePagesCount; $i++) {
                $allLinks[] = [
                    'loc' => Helper::baseUrl('site-maps/pages-' . $i . '.xml')
                ];
            }
        }

        set_transient($cacheKey, $allLinks, HOUR_IN_SECONDS);

        return $allLinks;
    }

    public function addSeoIndexTag($routeName)
    {
        if (!$this->isPublicCommunity()) {
            echo '<meta name="robots" content="noindex, nofollow">';
            return;
        }

        // let's add no index for profiles
        if (in_array($routeName, ['user_profile', 'admin'])) {
            echo '<meta name="robots" content="noindex, nofollow">';
            return;
        }
    }

    /**
     * Page two onward of a space listing is its own page, so it gets its own canonical.
     *
     * The free plugin canonicalises every tab of a space to `space/{slug}/home`,
     * which is right for the SPA (it ignores `?page=`) and wrong once SpacePreRenderer
     * paints page N there: Google's pagination guidance is explicit that the first
     * page must not be the canonical of the others, and pairing that with `noindex`
     * (the previous approach) is the mixed signal that lets a noindex bleed onto the
     * canonical target - and a long-lived noindex is treated as nofollow, which cuts
     * the very crawl path the pagination exists to open. So: self-canonical, indexable.
     *
     * Only when the page is actually painted. A page the pre-renderer would refuse
     * (a private space, an out-of-range or junk `page`) still shows page one, and
     * keeps page one's canonical.
     */
    public function filterPageMeta($data, $path, $context = [])
    {
        if (Arr::get($context, 'route') !== 'community_view' || empty($data['canonical_url'])) {
            return $data;
        }

        $page = $this->spacePreRenderer()->paintedPage(Arr::get($context, 'model'), $path);

        if ($page > 1) {
            $data['canonical_url'] = add_query_arg('page', $page, $data['canonical_url']);
        }

        return $data;
    }

    /**
     * One instance for the request: the canonical decision and the body paint have
     * to agree, and sharing the renderer is what lets them share its feed query.
     */
    protected function spacePreRenderer()
    {
        if (!$this->spacePreRenderer) {
            $this->spacePreRenderer = new SpacePreRenderer();
        }

        return $this->spacePreRenderer;
    }

    private function isPublicCommunity()
    {
        $settings = Helper::generalSettings();
        $accessLevel = Arr::get($settings, 'access.acess_level');
        return $accessLevel === 'public';
    }

    private function renderStyleSheet($requestMap = '')
    {
        header('Content-Type: application/xml; charset=UTF-8');

        status_header(200);

        if ($requestMap == 'style-index.xsl') {
            echo $this->getIndexSitemapStylesheet();
        } else {
            echo $this->getSitemapStylesheet();
        }

        exit;
    }

    private function getSitemapStylesheet()
    {
        $css = (new \WP_Sitemaps_Stylesheet())->get_stylesheet_css();
        $title = esc_xml('FluentCommunity XML Sitemap');
        $description = esc_xml('This XML Sitemap is generated by FluentCommunity to make your community feeds, spaces, courses, lessons more visible for search engines.');
        $learn_more = \sprintf(
            '<a href="%s">%s</a>',
            esc_url('https://www.fluentcommunity.co/docs/generating-a-sitemap'),
            esc_xml('Learn more about FluentCommunity Sitemaps.')
        );

        $allIndex = \sprintf(
            '<a href="%s">%s</a>',
            esc_url(Helper::baseUrl('site-maps/index.xml')),
            esc_xml('View all the Community Sitemaps.')
        );

        $text = \sprintf(
            esc_xml('Number of URLs in this XML Sitemap: %s.'),
            '<xsl:value-of select="count( sitemap:urlset/sitemap:url )" />'
        );

        $lang = get_language_attributes('html');
        $url = esc_xml('URL');
        $lastmod = esc_xml('Last Modified');
        $changefreq = esc_xml('Change Frequency');
        $priority = esc_xml('Priority');

        $xsl_content = <<<XSL
<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet
		version="1.0"
		xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
		xmlns:sitemap="http://www.sitemaps.org/schemas/sitemap/0.9"
		exclude-result-prefixes="sitemap"
		>

	<xsl:output method="html" encoding="UTF-8" indent="yes" />

	<!--
	  Set variables for whether lastmod, changefreq or priority occur for any url in the sitemap.
	  We do this up front because it can be expensive in a large sitemap.
	  -->
	<xsl:variable name="has-lastmod"    select="count( /sitemap:urlset/sitemap:url/sitemap:lastmod )"    />
	<xsl:variable name="has-changefreq" select="count( /sitemap:urlset/sitemap:url/sitemap:changefreq )" />
	<xsl:variable name="has-priority"   select="count( /sitemap:urlset/sitemap:url/sitemap:priority )"   />

	<xsl:template match="/">
		<html {$lang}>
			<head>
				<title>{$title}</title>
				<style>
					{$css}
				</style>
			</head>
			<body>
				<div id="sitemap">
					<div id="sitemap__header">
						<h1>{$title}</h1>
						<p>{$description}</p>
						<p>{$learn_more}</p>
						<p>{$allIndex}</p>
					</div>
					<div id="sitemap__content">
						<p class="text">{$text}</p>
						<table id="sitemap__table">
							<thead>
								<tr>
									<th class="loc">{$url}</th>
									<xsl:if test="\$has-lastmod">
										<th class="lastmod">{$lastmod}</th>
									</xsl:if>
									<xsl:if test="\$has-changefreq">
										<th class="changefreq">{$changefreq}</th>
									</xsl:if>
									<xsl:if test="\$has-priority">
										<th class="priority">{$priority}</th>
									</xsl:if>
								</tr>
							</thead>
							<tbody>
								<xsl:for-each select="sitemap:urlset/sitemap:url">
									<tr>
										<td class="loc"><a href="{sitemap:loc}"><xsl:value-of select="sitemap:loc" /></a></td>
										<xsl:if test="\$has-lastmod">
											<td class="lastmod"><xsl:value-of select="sitemap:lastmod" /></td>
										</xsl:if>
										<xsl:if test="\$has-changefreq">
											<td class="changefreq"><xsl:value-of select="sitemap:changefreq" /></td>
										</xsl:if>
										<xsl:if test="\$has-priority">
											<td class="priority"><xsl:value-of select="sitemap:priority" /></td>
										</xsl:if>
									</tr>
								</xsl:for-each>
							</tbody>
						</table>
					</div>
				</div>
			</body>
		</html>
	</xsl:template>
</xsl:stylesheet>

XSL;


        return $xsl_content;
    }

    private function getIndexSitemapStylesheet()
    {
        $css = (new \WP_Sitemaps_Stylesheet())->get_stylesheet_css();
        $title = esc_xml('FluentCommunity XML Sitemap');
        $description = esc_xml('This XML Sitemap is generated by FluentCommunity to make your community feeds, spaces, courses, lessons more visible for search engines.');
        $learn_more = \sprintf(
            '<a href="%s">%s</a>',
            esc_url('https://www.fluentcommunity.co/docs/generating-a-sitemap'),
            esc_xml('Learn more about FluentCommunity Sitemaps.')
        );

        $text = \sprintf(
            esc_xml('Number of URLs in this XML Sitemap: %s.'),
            '<xsl:value-of select="count( sitemap:sitemapindex/sitemap:sitemap )" />'
        );

        $lang = get_language_attributes('html');
        $url = 'URL';
        $lastmod = 'Last Modified';

        $xsl_content = <<<XSL
<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet
		version="1.0"
		xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
		xmlns:sitemap="http://www.sitemaps.org/schemas/sitemap/0.9"
		exclude-result-prefixes="sitemap"
		>

	<xsl:output method="html" encoding="UTF-8" indent="yes" />

	<!--
	  Set variables for whether lastmod occurs for any sitemap in the index.
	  We do this up front because it can be expensive in a large sitemap.
	  -->
	<xsl:variable name="has-lastmod" select="count( /sitemap:sitemapindex/sitemap:sitemap/sitemap:lastmod )" />

	<xsl:template match="/">
		<html {$lang}>
			<head>
				<title>{$title}</title>
				<style>
					{$css}
				</style>
			</head>
			<body>
				<div id="sitemap">
					<div id="sitemap__header">
						<h1>{$title}</h1>
						<p>{$description}</p>
						<p>{$learn_more}</p>
					</div>
					<div id="sitemap__content">
						<p class="text">{$text}</p>
						<table id="sitemap__table">
							<thead>
								<tr>
									<th class="loc">{$url}</th>
									<xsl:if test="\$has-lastmod">
										<th class="lastmod">{$lastmod}</th>
									</xsl:if>
								</tr>
							</thead>
							<tbody>
								<xsl:for-each select="sitemap:sitemapindex/sitemap:sitemap">
									<tr>
										<td class="loc"><a href="{sitemap:loc}"><xsl:value-of select="sitemap:loc" /></a></td>
										<xsl:if test="\$has-lastmod">
											<td class="lastmod"><xsl:value-of select="sitemap:lastmod" /></td>
										</xsl:if>
									</tr>
								</xsl:for-each>
							</tbody>
						</table>
					</div>
				</div>
			</body>
		</html>
	</xsl:template>
</xsl:stylesheet>
XSL;


        return $xsl_content;
    }

    public function pushJsonLdData($ldData, $feed, $data)
    {
        $feedUrl = Arr::get($data, 'canonical_url');

        $ld = [
            '@context'             => 'https://schema.org',
            '@type'                => 'DiscussionForumPosting',
            // Posts in this plugin do not require a title. Google wants a headline on
            // every posting, so a titleless post borrows the opening of its own body
            // rather than publishing an empty string.
            'headline'             => $feed->title ? $feed->title : Helper::getHumanExcerpt($feed->message, 110),
            '@id'                  => $feedUrl,
            'url'                  => $feedUrl,
            'text'                 => $feed->message,
            'datePublished'        => $feed->created_at->format(DATE_W3C),
            'dateModified'         => $feed->updated_at->format(DATE_W3C),
            'inLanguage'           => $this->siteLanguage(),
            'author'               => $this->ldPerson($feed->xprofile),
            'commentCount'         => (int) $feed->comments_count,
            'interactionStatistic' => [
                [
                    '@type'                => 'InteractionCounter',
                    'interactionType'      => 'https://schema.org/LikeAction',
                    'userInteractionCount' => (int) $feed->reactions_count
                ],
                [
                    '@type'                => 'InteractionCounter',
                    'interactionType'      => 'https://schema.org/CommentAction',
                    'userInteractionCount' => (int) $feed->comments_count
                ]
            ],
            'comment'              => $this->formatLdComments($feed, $feedUrl),
        ];

        if ($image = Arr::get($data, 'featured_image')) {
            $ld['image'] = $image;
        }

        return $ld;
    }

    /**
     * The name people see on the post is display_name; publishing the username here
     * instead makes the structured data disagree with the rendered page.
     */
    private function ldPerson($xprofile)
    {
        $username = $xprofile && $xprofile->username ? $xprofile->username : 'unknown';

        return [
            '@type' => 'Person',
            'name'  => $xprofile && $xprofile->display_name ? $xprofile->display_name : $username,
            'url'   => Helper::baseUrl('u/' . $username),
        ];
    }

    /**
     * get_locale() returns a WP locale (en_US); schema.org wants a BCP-47 language
     * tag (en-US), which is exactly what the `language` bloginfo key holds.
     */
    private function siteLanguage()
    {
        $language = get_bloginfo('language');

        return $language ? $language : str_replace('_', '-', get_locale());
    }

    private function ldOrganization()
    {
        return [
            '@type' => 'Organization',
            'name'  => get_bloginfo('name'),
            'url'   => home_url()
        ];
    }

    public function pushJsonLdDataForCourse($ldData, BaseSpace $course, $data)
    {
        if (!$this->isCourseDescribable($course)) {
            return $ldData;
        }

        $permalink = $course->getPermalink();
        $organization = $this->ldOrganization();

        // The privacy settings say what a course costs: public is "Anyone can view and
        // enroll the course for free", private is "They can enroll by paying a fee".
        $isFree = $course->privacy === 'public';

        $ld = [
            '@context'      => 'https://schema.org',
            '@id'           => $permalink,
            '@type'         => 'Course',
            'name'          => $course->title,
            'description'   => Helper::getHumanExcerpt($course->description, 1000),
            'url'           => $permalink,
            // Google requires `provider` for the Course rich result. `publisher` stays
            // for the sites that were already reading it.
            'provider'      => $organization,
            'publisher'     => $organization,
            'datePublished' => $course->created_at->format(DATE_W3C),
            'dateModified'  => $course->updated_at->format(DATE_W3C),
            'inLanguage'    => $this->siteLanguage(),
            'isAccessibleForFree' => $isFree,
            'hasCourseInstance'   => $this->ldCourseInstance($course),
        ];

        // Only describe a curriculum the page actually shows: a private course hides it
        // behind the lock screen, and marking up content a visitor cannot see is the
        // mismatch Google acts on.
        if (CourseVisibility::showsCurriculum($course)) {
            $ld['syllabusSections'] = $this->ldSyllabusSections($course);
        }

        if ($offers = $this->ldOffers($course, $isFree, $permalink)) {
            $ld['offers'] = $offers;
        }

        if ($image = Arr::get($data, 'featured_image')) {
            $ld['image'] = $image;
        }

        return $ld;
    }

    /**
     * Draft courses describe nothing - there is no page worth finding yet - and secret
     * courses are invite-only ("Only invited students can view and enroll"). Private is
     * neither: it is the paid tier, so its landing page is a sales page and belongs in
     * the index.
     */
    private function isCourseDescribable(BaseSpace $course)
    {
        return $course->status === 'published' && $course->privacy !== 'secret';
    }

    /**
     * A free course can say so outright. A paid one has to read its real price from the
     * FluentCart products attached to it, because publishing a guessed figure - or worse,
     * "Free" - on a course someone charges for is the mismatch between markup and page
     * that earns a manual action. A paid course with no price to read says only that it
     * is not free.
     */
    private function ldOffers(BaseSpace $course, $isFree, $permalink)
    {
        if ($isFree) {
            $offers = [
                '@type'        => 'Offer',
                'category'     => 'Free',
                'url'          => $permalink,
                'availability' => 'https://schema.org/InStock',
            ];
        } else {
            // Only the prices the lock screen shows: `show_paywalls` can be off, and a
            // custom lock screen picks specific variants. Every attached product would
            // advertise offers the visitor never sees.
            $offers = CourseVisibility::showsPaywalls($course)
                ? $this->ldPaywallOffers($course, $permalink)
                : [];
        }

        return apply_filters('fluent_community/seo/course_offers', $offers, $course, $isFree);
    }

    private function ldPaywallOffers(BaseSpace $course, $permalink)
    {
        $offers = [];

        foreach ($this->coursePaywalls($course, CourseVisibility::visiblePaywallVariantIds($course)) as $paywall) {
            $offer = [
                '@type'         => 'Offer',
                'category'      => 'Paid',
                'price'         => $paywall['price'],
                'priceCurrency' => $paywall['currency'],
                'url'           => $permalink,
                'availability'  => 'https://schema.org/InStock',
            ];

            if ($paywall['variant_title']) {
                $offer['name'] = $paywall['variant_title'];
            }

            // A subscription is a recurring charge; a bare price would misstate it.
            if ($billing = CoursePaywalls::billingSpecification($paywall)) {
                $offer['priceSpecification'] = $billing;
            }

            $offers[] = $offer;
        }

        // A single offer reads better unwrapped, and schema.org accepts either shape.
        return count($offers) === 1 ? $offers[0] : $offers;
    }

    /**
     * @param int[] $variantIds
     */
    protected function coursePaywalls(BaseSpace $course, $variantIds = [])
    {
        return CoursePaywalls::forCourse($course, $variantIds);
    }

    protected function ldSyllabusSections(BaseSpace $course)
    {
        $lessons = [];

        foreach (CourseCurriculum::lessons($course) as $lesson) {
            $lessons[] = [
                '@type'       => 'Syllabus',
                'name'        => $lesson->title,
                'description' => Helper::getHumanExcerpt($lesson->message, 100),
            ];
        }

        return $lessons;
    }

    /**
     * Google's Course Info rich result wants courseWorkload as an ISO-8601 duration.
     * Lessons record `meta.video_length` in seconds - the same figure the SPA prints
     * next to each lesson - so a video course can state its real length. A course with
     * no video says nothing rather than guessing, and a site can supply its own.
     */
    private function ldCourseInstance(BaseSpace $course)
    {
        $instance = [
            '@type'      => 'CourseInstance',
            'courseMode' => 'Online',
        ];

        $workload = apply_filters('fluent_community/seo/course_workload', $this->courseWorkload($course), $course);

        if ($workload) {
            $instance['courseWorkload'] = $workload;
        }

        return $instance;
    }

    protected function courseWorkload(BaseSpace $course)
    {
        $seconds = CourseCurriculum::videoSeconds($course);

        if ($seconds < 60) {
            return '';
        }

        $hours = (int) floor($seconds / 3600);
        $minutes = (int) floor(($seconds % 3600) / 60);

        return 'PT' . ($hours ? $hours . 'H' : '') . ($minutes ? $minutes . 'M' : '');
    }

    public function pushJsonLdDataForLesson($ldData, $lesson, BaseSpace $course, $data)
    {
        if (!$this->isCourseDescribable($course)) {
            return $ldData;
        }

        $permalink = $lesson->getPermalink();

        return [
            '@context'             => 'https://schema.org',
            '@id'                  => $permalink,
            '@type'                => 'LearningResource',
            'name'                 => $lesson->title,
            // Deliberately the excerpt PortalHandler already published as the meta
            // description: lesson bodies are gated behind the enrolment check, so the
            // structured data must not expose more of one than the page head does.
            'description'          => Arr::get($data, 'description', ''),
            'url'                  => $permalink,
            'learningResourceType' => 'Lesson',
            'inLanguage'           => $this->siteLanguage(),
            'datePublished'        => $lesson->created_at->format(DATE_W3C),
            'dateModified'         => $lesson->updated_at->format(DATE_W3C),
            'provider'             => $this->ldOrganization(),
            'isPartOf'             => [
                '@type' => 'Course',
                '@id'   => $course->getPermalink(),
                'name'  => $course->title,
                'url'   => $course->getPermalink(),
            ],
        ];
    }

    protected function formatLdComments($feed, $feedPermalink)
    {
        // Shared with the pre-rendered body, which runs later in this same request.
        $comments = FeedComments::forFeed($feed->id);

        $children = [];

        $formattedComments = [];

        foreach ($comments as $comment) {
            if (!$comment->parent_id) {
                $formattedComments[$comment->id] = [
                    '@type'                => 'Comment',
                    'text'                 => $comment->message,
                    'datePublished'        => $comment->created_at->format(DATE_W3C),
                    'author'               => $this->ldPerson($comment->xprofile),
                    'interactionStatistic' => [
                        '@type'                => 'InteractionCounter',
                        'interactionType'      => 'https://schema.org/LikeAction',
                        'userInteractionCount' => (int) $comment->reactions_count
                    ],
                    'url'                  => $feedPermalink . '?comment_id=' . $comment->id
                ];
            } else {
                $children[] = $comment;
            }
        }

        foreach ($children as $comment) {
            if (isset($formattedComments[$comment->parent_id])) {
                if (empty($formattedComments[$comment->parent_id]['comment'])) {
                    $formattedComments[$comment->parent_id]['comment'] = [];
                }
                $formattedComments[$comment->parent_id]['comment'][] = [
                    '@type'                => 'Comment',
                    'text'                 => $comment->message,
                    'datePublished'        => $comment->created_at->format(DATE_W3C),
                    'author'               => $this->ldPerson($comment->xprofile),
                    'interactionStatistic' => [
                        '@type'                => 'InteractionCounter',
                        'interactionType'      => 'https://schema.org/LikeAction',
                        'userInteractionCount' => (int) $comment->reactions_count
                    ],
                    'url'                  => $feedPermalink . '?comment_id=' . $comment->id
                ];
            }
        }

        return array_values($formattedComments);
    }
}
