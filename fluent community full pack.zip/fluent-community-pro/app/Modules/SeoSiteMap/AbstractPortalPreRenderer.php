<?php

namespace FluentCommunityPro\App\Modules\SeoSiteMap;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;

/**
 * Shared machinery for server-rendering a portal route's first paint.
 *
 * The portal is a Vue SPA: `#fluent_com_portal` ships empty and Vue fills it after
 * the bundle loads and a REST call returns. Google's renderer copes with that, but
 * Bing, the AI crawlers (GPTBot, ClaudeBot, PerplexityBot) and every social unfurler
 * do not execute JS, so without this those routes are head tags and nothing else.
 *
 * Vue's mount() empties the container before it renders, so everything printed here
 * is replaced wholesale. That makes this a pre-render, not hydration: no subclass has
 * to match the SPA's DOM, and there is no mismatch class of bug to manage. What the
 * markup DOES reuse is the SPA's class names and wrapper chain, so the portal
 * stylesheet places the pre-paint exactly where Vue will place its own render.
 *
 * What it never reuses is Element Plus. No el-button, el-icon, el-select, el-tooltip,
 * el-scrollbar or avatar components: they exist to carry behaviour this markup does
 * not have, and they would cost DOM for a few hundred milliseconds of life. The
 * el-container/el-main/el-aside layout classes are the exception - pure CSS.
 *
 * Every subclass renders for logged-out visitors only. Nothing user-specific is baked
 * in, so the response is identical for every anonymous visitor and safe to page-cache.
 */
abstract class AbstractPortalPreRenderer
{
    /**
     * The `route_group` PortalHandler resolves for this route.
     */
    abstract protected function routeName();

    abstract protected function renderFor($model, $context);

    public function register()
    {
        add_action('fluent_community/portal_content_pre_render', [ $this, 'maybeRender' ], 10, 1);
    }

    public function maybeRender($context)
    {
        if (Arr::get($context, 'route') !== $this->routeName()) {
            return;
        }

        if (!$this->isEnabled()) {
            return;
        }

        $this->renderFor(Arr::get($context, 'model'), $context);
    }

    /**
     * Pre-rendering is for anonymous crawl and first paint only. Logged-in members get
     * personalised markup from the SPA, and baking any of it into the document would
     * make the response uncacheable and risk leaking one member's state to another.
     */
    protected function isEnabled()
    {
        if (is_user_logged_in()) {
            return false;
        }

        $settings = Helper::generalSettings();

        if (Arr::get($settings, 'access.acess_level') !== 'public') {
            return false;
        }

        return (bool) apply_filters('fluent_community/seo/pre_render', true, $this->routeName());
    }

    /**
     * The wrapper chain is not decoration: .fcom_feed_box carries the 680px cap and the
     * auto margins, .fhr_content_layout_body the page gutters, and the empty el-aside
     * reserves the sidebar column so .el-main resolves to the same width it will have
     * once Vue renders. Drop any of them and the pre-paint goes full-bleed and then
     * visibly snaps into place.
     *
     * @param object|null $space      Space whose header/links frame the content.
     * @param string      $routeClass SPA route modifier, e.g. `space_feed`.
     * @param bool        $withCover  Whether to paint the space cover strip.
     */
    protected function openLayout($space, $routeClass, $withCover = false)
    {
        $spaceClass = $space ? ' fcom_space_' . sanitize_html_class($space->slug) : '';
        $routeClass = sanitize_html_class($routeClass);

        ?>
        <div class="fcom_single_layout fcom_max_layout<?php echo esc_attr($spaceClass); ?> feeds">
            <div class="feeds_main">
                <div class="no_bg_layout fcom_route_<?php echo esc_attr($routeClass); ?> fhr_content_layout">
                    <?php $this->renderSpaceHeader($space); ?>
                    <div class="fhr_content_layout_body">
                        <?php
                        if ($withCover) {
                            $this->renderSpaceCover($space);
                        }
                        ?>
                        <section class="el-container fcom_resp_container fcom_space_container fcom_main_container">
                            <main class="el-main fcom_main">
                                <div class="fcom_layout_timeline fcom_route_<?php echo esc_attr($routeClass); ?> fcom_feed_box">
                                    <div class="space_route">
                                        <div class="space_holder">
        <?php
    }

    protected function closeLayout()
    {
        ?>
                                        </div>
                                    </div>
                                </div>
                            </main>
                            <aside class="el-aside fcom_resp_side" style="--el-aside-width: 306px;"></aside>
                        </section>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * The space header and its link bar sit above the content in the SPA and account
     * for the whole vertical offset between the two renders (52px + 41px of
     * min-height, both set in CSS - so these elements hold the right space open on
     * their own and nothing here depends on a hard-coded height).
     *
     * They also earn their keep for crawlers: a post page otherwise never says which
     * space it belongs to, and these are the only internal links out of it.
     */
    protected function renderSpaceHeader($space)
    {
        if (!$space) {
            return;
        }

        $spaceUrl = Helper::baseUrl('space/' . $space->slug . '/home');

        ?>
        <div class="fhr_content_layout_header">
            <?php
            // h2, not the SPA's h1: on a post page the post title is the document
            // heading. The header's `h2, h1` rule styles both identically, so this
            // costs nothing visually and leaves a single h1 on the page.
            ?>
            <h2 class="fcom_page_title">
                <a class="fcom_space_title" href="<?php echo esc_url($spaceUrl); ?>">
                    <span><?php echo esc_html($space->title); ?></span>
                </a>
            </h2>
            <div class="fhr_page_actions">
                <div class="space_header">
                    <div class="object_menu">
                        <nav aria-label="<?php esc_attr_e('Space menu', 'fluent-community-pro'); ?>" class="fcom_desktop_only">
                            <ul class="fcom_space_menu_ul">
                                <li>
                                    <a href="<?php echo esc_url($spaceUrl); ?>"><span><?php esc_html_e('Posts', 'fluent-community-pro'); ?></span></a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <?php

        $this->renderSpaceLinks($space);
    }

    protected function renderSpaceLinks($space)
    {
        $links = Arr::get($space->settings, 'links', []);

        if (!$links || !is_array($links)) {
            return;
        }

        // Anonymous render, so member-only links must not leak into the markup. The
        // rule is the free plugin's own (the one the REST payload applies for a
        // logged-out caller), so the paint and the SPA agree on which links exist: a
        // link saved before privacy existed carries no `privacy` key at all and is
        // public, and a stricter inline check here was dropping every one of those.
        $links = array_filter($links, function ($link) {
            return is_array($link)
                && Arr::get($link, 'permalink')
                && Helper::isLinkAccessible($link, null);
        });

        if (!$links) {
            return;
        }

        ?>
        <nav aria-label="<?php esc_attr_e('Space Links', 'fluent-community-pro'); ?>" class="fcom_sub_header">
            <div class="object_menu">
                <ul class="fcom_space_menu_ul">
                    <?php foreach ($links as $link): ?>
                        <li>
                            <a href="<?php echo esc_url(Arr::get($link, 'permalink')); ?>"
                                <?php if (Arr::get($link, 'new_tab') === 'yes'): ?>target="_blank" rel="noopener nofollow"<?php endif; ?>>
                                <span><?php echo esc_html(Arr::get($link, 'title')); ?></span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </nav>
        <?php
    }

    protected function renderSpaceCover($space)
    {
        if (!$space || !$space->cover_photo) {
            return;
        }

        ?>
        <div class="object_header space_header">
            <div class="object_cover" style="background-image: url('<?php echo esc_url($space->cover_photo); ?>');"></div>
        </div>
        <?php
    }

    /**
     * @param string $variant `single` on a post page, `list` inside a feed listing.
     */
    protected function renderFeedCard($feed, $variant = 'single')
    {
        $typeClass = sanitize_html_class('feed_type_' . ($feed->content_type ? $feed->content_type : 'text'));
        $variantClass = $variant === 'single' ? 'feed_single' : 'feed_list_item';

        ?>
        <div class="<?php echo esc_attr($typeClass . ' ' . $variantClass); ?> feed">
            <?php $this->renderFeedHeader($feed); ?>
            <?php $this->renderFeedBody($feed, $variant); ?>
            <?php $this->renderFeedMedia($feed); ?>
            <?php $this->renderFeedFooterMeta($feed); ?>
            <?php
            if ($variant === 'single') {
                $this->renderComments($feed);
            }
            ?>
        </div>
        <?php
    }

    protected function renderFeedHeader($feed)
    {
        $author = $feed->xprofile;
        $permalink = $feed->getPermalink();
        ?>
        <div class="fcom_feed_header_wrap">
            <?php $this->renderTopics($feed); ?>
            <div class="feed_header">
                <div class="feed_user">
                    <?php $this->renderAvatar($author); ?>
                    <div class="feed_user_info">
                        <div class="feed_user_name">
                            <?php $this->renderUserLink($author); ?>
                        </div>
                        <div class="feed_meta_info">
                            <a class="feed_timestamp"
                               href="<?php echo esc_url($permalink); ?>"
                               title="<?php echo esc_attr($feed->created_at->format('Y-m-d H:i:s')); ?>">
                                <time datetime="<?php echo esc_attr($feed->created_at->format(DATE_W3C)); ?>"><?php echo esc_html($this->timeAgo($feed->created_at)); ?></time>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    protected function renderTopics($feed)
    {
        $terms = $feed->terms;

        if (!$terms || !count($terms) || !$feed->space) {
            return;
        }

        $spaceUrl = Helper::baseUrl('space/' . $feed->space->slug . '/home');
        ?>
        <div class="fcom_feed_topics">
            <?php foreach ($terms as $term): ?>
                <a class="feed_timestamp" href="<?php echo esc_url($spaceUrl . '?topic=' . $term->slug); ?>">#<?php echo esc_html($term->title); ?></a>
            <?php endforeach; ?>
        </div>
        <?php
    }

    protected function renderFeedBody($feed, $variant)
    {
        ?>
        <div class="feed_body">
            <?php if ($feed->title): ?>
                <div class="feed_title">
                    <?php if ($variant === 'single'): ?>
                        <?php // h1 rather than the SPA's h2: on a single post page this is the document heading. ?>
                        <h1 class="feed_title_heading"><?php echo esc_html($feed->title); ?></h1>
                    <?php else: ?>
                        <h2 class="feed_title_heading">
                            <a href="<?php echo esc_url($feed->getPermalink()); ?>"><?php echo esc_html($feed->title); ?></a>
                        </h2>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <div class="feed_md_content feed_texts"><?php echo wp_kses_post($feed->message_rendered); ?></div>
        </div>
        <?php
    }

    /**
     * Images only. Video and oembed blocks are player components that need the SPA,
     * and a crawler gets nothing from an empty embed shell.
     *
     * FeedsHelper::transformFeed() moves the images off `meta.media_items` onto
     * `media_images` - and for a single uploaded image, which the editor stores as
     * `meta.media_preview` instead, resolves the Media row into that same list. Every
     * feed handed to a card has been through that transform, so `media_images` is
     * where the images are; `meta.media_items` is only the untransformed fallback.
     */
    protected function renderFeedMedia($feed)
    {
        $items = isset($feed->media_images) && is_array($feed->media_images)
            ? $feed->media_images
            : Arr::get($feed->meta, 'media_items', []);

        $images = is_array($items) ? array_filter($items, function ($item) {
            return Arr::get($item, 'type') === 'image' && Arr::get($item, 'url');
        }) : [];

        // _MediaPreview.vue: a `media_preview` that is an image, or was uploaded, is
        // painted as one. That is where a single uploaded image lives when the Media
        // row behind it cannot be resolved, and where the transform leaves it.
        if (!$images) {
            $preview = Arr::get($feed->meta, 'media_preview', []);

            if (is_array($preview) && Arr::get($preview, 'image')
                && (Arr::get($preview, 'type') === 'image' || Arr::get($preview, 'is_uploaded'))
            ) {
                $images = [ [ 'type' => 'image', 'url' => Arr::get($preview, 'image') ] ];
            }
        }

        if (!$images) {
            return;
        }

        ?>
        <div class="feed_media">
            <?php foreach ($images as $image): ?>
                <img src="<?php echo esc_url(Arr::get($image, 'url')); ?>"
                     alt="<?php echo esc_attr($feed->title ? $feed->title : ''); ?>"
                     loading="lazy"/>
            <?php endforeach; ?>
        </div>
        <?php
    }

    /**
     * The SPA's footer has two halves: the react/comment buttons, which are Element Plus
     * components, and the meta row under them, which is plain markup. Only the meta row
     * carries text, so that is the half worth rendering for a crawler.
     */
    protected function renderFeedFooterMeta($feed)
    {
        $reactions = (int) $feed->reactions_count;
        $comments = (int) $feed->comments_count;

        if (!$reactions && !$comments) {
            return;
        }

        ?>
        <div class="feed_footer">
            <div class="fcom_feed_footer_meta">
                <ul>
                    <?php if ($reactions): ?>
                        <li class="fcom_reactions_count feed_reaction_meta">
                            <div class="fcom_reactions">
                                <span>
                                <?php
                                echo esc_html(sprintf(
                                    /* translators: %s is the number of likes */
                                    _n('%s like', '%s likes', $reactions, 'fluent-community-pro'),
                                    number_format_i18n($reactions)
                                ));
                                ?>
                                </span>
                            </div>
                        </li>
                    <?php endif; ?>
                    <?php if ($comments): ?>
                        <li class="feed_reaction_meta">
                            <div class="feed_comment_count">
                            <?php
                            echo esc_html(sprintf(
                                /* translators: %s is the number of comments */
                                _n('%s comment', '%s comments', $comments, 'fluent-community-pro'),
                                number_format_i18n($comments)
                            ));
                            ?>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <?php
    }

    protected function renderComments($feed)
    {
        $comments = $feed->comments;

        if (!$comments || !count($comments)) {
            return;
        }

        $limit = (int) apply_filters('fluent_community/seo/pre_render_comment_limit', 50);

        $roots = [];
        $children = [];

        foreach ($comments as $comment) {
            if ($comment->parent_id) {
                $children[$comment->parent_id][] = $comment;
            } else {
                $roots[] = $comment;
            }
        }

        $roots = array_slice($roots, 0, $limit);

        ?>
        <div class="feed_comments">
            <?php foreach ($roots as $comment): ?>
                <div class="each_comment">
                    <div class="person_avatar">
                        <?php $this->renderAvatar($comment->xprofile); ?>
                    </div>
                    <div class="comment_wrap">
                        <?php $this->renderCommentText($comment); ?>
                        <div class="child_comments">
                            <?php foreach (Arr::get($children, $comment->id, []) as $child): ?>
                                <div class="each_comment">
                                    <div class="person_avatar">
                                        <?php $this->renderAvatar($child->xprofile); ?>
                                    </div>
                                    <div class="comment_wrap">
                                        <?php $this->renderCommentText($child); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
    }

    protected function renderCommentText($comment)
    {
        ?>
        <div class="comment_text">
            <div class="comment_text_head">
                <div class="comment_text_head_name">
                    <?php $this->renderUserLink($comment->xprofile); ?>
                    <div class="comment_text_head_time" title="<?php echo esc_attr($comment->created_at->format('Y-m-d H:i:s')); ?>">
                        <time datetime="<?php echo esc_attr($comment->created_at->format(DATE_W3C)); ?>"><?php echo esc_html($this->timeAgo($comment->created_at)); ?></time>
                    </div>
                </div>
            </div>
            <?php // No `clamped`: the SPA truncates long comments behind a toggle, crawlers want all of it. ?>
            <div class="feed_md_content comment_text_body"><?php echo wp_kses_post($comment->message_rendered); ?></div>
        </div>
        <?php
    }

    /**
     * The SPA's UserAvatar falls back to generated initials; that needs component
     * state, so a member with no uploaded avatar simply gets no image here.
     */
    protected function renderAvatar($profile)
    {
        if (!$profile || !$profile->avatar) {
            return;
        }

        ?>
        <div class="fcom_avatar_is_rounded fcom_user_avatar">
            <span><img src="<?php echo esc_url($profile->avatar); ?>" alt="" loading="lazy"/></span>
        </div>
        <?php
    }

    protected function renderUserLink($profile)
    {
        $name = $profile && $profile->display_name
            ? $profile->display_name
            : __('Someone', 'fluent-community-pro');

        if (!$profile || !$profile->username) {
            ?>
            <span class="user_route"><p class="fcom_user_display_name"><?php echo esc_html($name); ?></p></span>
            <?php
            return;
        }

        ?>
        <span class="user_route">
            <a class="user_route" href="<?php echo esc_url(Helper::baseUrl('u/' . $profile->username)); ?>">
                <p class="fcom_user_display_name"><?php echo esc_html($name); ?></p>
            </a>
        </span>
        <?php
    }

    protected function timeAgo($date)
    {
        $timestamp = strtotime($date->format('Y-m-d H:i:s'));

        return sprintf(
            /* translators: %s: human readable time difference, e.g. "3 weeks" */
            __('%s ago', 'fluent-community-pro'),
            human_time_diff($timestamp, current_time('timestamp'))
        );
    }

    /**
     * Inlined ahead of the SPA bundle, which is a deferred module script and therefore
     * always executes after this.
     */
    protected function renderDataIsland($globalName, $payload)
    {
        $encoded = wp_json_encode($payload, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

        if (!$encoded) {
            return;
        }

        ?>
        <script>window.<?php echo esc_js($globalName); ?> = <?php echo $encoded; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>;</script>
        <?php
    }
}
