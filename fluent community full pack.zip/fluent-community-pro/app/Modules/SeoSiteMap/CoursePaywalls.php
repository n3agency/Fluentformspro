<?php

namespace FluentCommunityPro\App\Modules\SeoSiteMap;

use FluentCommunity\App\Models\BaseSpace;
use FluentCommunity\Framework\Support\Arr;
// FluentCart is optional; both are guarded by defined('FLUENTCART_VERSION') before use.
use FluentCart\App\Helpers\Helper as CartHelper;
use FluentCart\App\Models\Product as CartProduct;

/**
 * The prices a paid course shows on its lock screen.
 *
 * `settings.cart_product_ids` is the same list PaywallController reads to render that
 * lock screen, so what is published here - in the markup and in the structured data -
 * is what the visitor is quoted. Amounts are stored in minor units; FluentCart's own
 * helper converts them, which keeps zero-decimal currencies right.
 */
class CoursePaywalls
{
    /**
     * Products already loaded this request, keyed by course id. A paid course page
     * reads its prices from the JSON-LD, from the lock screen, and once per paywall
     * field of a custom lock screen; the products behind them do not change between
     * those reads, so FluentCart is asked once.
     *
     * @var array<int, array>
     */
    protected static $loaded = [];

    /**
     * @param BaseSpace $course
     * @param int[]     $variantIds Restrict to these variants - a custom lock screen
     *                              picks specific ones (PaywallController's
     *                              `paywall_ids`). Empty means every variant.
     * @return array<int, array{variant_id: int, product_title: string, variant_title: string, price: mixed, price_display: mixed, currency: string, payment_type: string, repeat_interval: string}>
     */
    public static function forCourse(BaseSpace $course, $variantIds = [])
    {
        return self::filter(self::all($course), $variantIds);
    }

    /**
     * Every variant of every published product attached to the course, in memory
     * after the first call; each caller narrows it with filter().
     */
    public static function all(BaseSpace $course)
    {
        if (isset(self::$loaded[$course->id])) {
            return self::$loaded[$course->id];
        }

        self::$loaded[$course->id] = self::load($course);

        return self::$loaded[$course->id];
    }

    /**
     * @param array $paywalls  As returned by all().
     * @param int[] $variantIds Empty keeps everything.
     */
    public static function filter(array $paywalls, $variantIds = [])
    {
        $variantIds = array_values(array_filter(array_map('intval', (array) $variantIds)));

        if (!$variantIds) {
            return $paywalls;
        }

        return array_values(array_filter($paywalls, function ($paywall) use ($variantIds) {
            return in_array((int) Arr::get($paywall, 'variant_id'), $variantIds, true);
        }));
    }

    public static function reset()
    {
        self::$loaded = [];
    }

    protected static function load(BaseSpace $course)
    {
        $productIds = Arr::get($course->settings, 'cart_product_ids', []);

        if (!$productIds || !defined('FLUENTCART_VERSION') || !class_exists(CartProduct::class)) {
            return [];
        }

        $products = CartProduct::whereIn('ID', $productIds)
            ->where('post_status', 'publish')
            ->with([
                'variants' => function ($query) {
                    $query->select('id', 'post_id', 'item_price', 'variation_title', 'other_info');
                },
            ])
            ->get();

        $currency = CartHelper::shopConfig('currency');
        $offers = [];

        foreach ($products as $product) {
            foreach ($product->variants as $variant) {
                if ($variant->item_price === null) {
                    continue;
                }

                $otherInfo = is_array($variant->other_info) ? $variant->other_info : [];

                $offers[] = [
                    'variant_id'      => (int) $variant->id,
                    'product_title'   => $product->post_title,
                    'variant_title'   => $variant->variation_title,
                    'price'           => CartHelper::toDecimal($variant->item_price, false, null, false),
                    'price_display'   => CartHelper::toDecimal($variant->item_price),
                    'currency'        => $currency,
                    // What the SPA reads to print "$49 / month" rather than "$49".
                    'payment_type'    => (string) Arr::get($otherInfo, 'payment_type', ''),
                    'repeat_interval' => (string) Arr::get($otherInfo, 'repeat_interval', ''),
                ];
            }
        }

        return $offers;
    }

    /**
     * The interval suffix the lock screen prints after a subscription price
     * (_DefaultLockscreenPaywall.vue / _LockscreenPaywallView.vue).
     *
     * @return string Empty for a one-time purchase or an unknown interval.
     */
    public static function intervalLabel($paywall)
    {
        if (Arr::get($paywall, 'payment_type') !== 'subscription') {
            return '';
        }

        $labels = [
            'daily'       => __('day', 'fluent-community-pro'),
            'weekly'      => __('week', 'fluent-community-pro'),
            'monthly'     => __('month', 'fluent-community-pro'),
            'quarterly'   => __('quarter', 'fluent-community-pro'),
            'half_yearly' => __('half year', 'fluent-community-pro'),
            'yearly'      => __('year', 'fluent-community-pro'),
        ];

        return Arr::get($labels, Arr::get($paywall, 'repeat_interval'), '');
    }

    /**
     * schema.org UnitPriceSpecification for a subscription: the billing period as a
     * duration in the UN/CEFACT unit codes Google reads. Null for a one-time price
     * or an interval with no clean unit.
     */
    public static function billingSpecification($paywall)
    {
        if (Arr::get($paywall, 'payment_type') !== 'subscription') {
            return null;
        }

        $periods = [
            'daily'       => [ 1, 'DAY' ],
            'weekly'      => [ 1, 'WEE' ],
            'monthly'     => [ 1, 'MON' ],
            'quarterly'   => [ 3, 'MON' ],
            'half_yearly' => [ 6, 'MON' ],
            'yearly'      => [ 1, 'ANN' ],
        ];

        $period = Arr::get($periods, Arr::get($paywall, 'repeat_interval'));

        if (!$period) {
            return null;
        }

        return [
            '@type'           => 'UnitPriceSpecification',
            'price'           => Arr::get($paywall, 'price'),
            'priceCurrency'   => Arr::get($paywall, 'currency'),
            'billingDuration' => $period[0],
            'unitCode'        => $period[1],
        ];
    }
}
