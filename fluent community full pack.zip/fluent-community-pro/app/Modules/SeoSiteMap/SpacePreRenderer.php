<?php

namespace FluentCommunityPro\App\Modules\SeoSiteMap;

use FluentCommunity\App\Models\BaseSpace;
use FluentCommunity\App\Models\Feed;
use FluentCommunity\App\Services\FeedsHelper;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;

/**
 * Server-rendered first paint for a space's post listing.
 *
 * This is the higher-leverage half of the pre-render work. A single post page only
 * gets crawled if something already links to it; the space page is the hub that links
 * to every post in the space, and the sitemap already submits it. Until now it was
 * submitted while rendering an empty body, which is a thin-content signal AND a dead
 * end - crawlers reached the hub and found no path onward.
 *
 * Unlike FeedPreRenderer there is no data island: the SPA loads a listing through the
 * Pinia feed store, which has no seeding entry point the way ViewFeed.vue does for a
 * single post. The markup is therefore for crawlers and first paint only; Vue still
 * fetches page one as it does today. Seeding the store would need a new seam in
 * src/stores/feed.js plus an asset rebuild, and would only ever cover the default
 * unfiltered view.
 */
class SpacePreRenderer extends AbstractPortalPreRenderer
{
    protected function routeName()
    {
        return 'community_view';
    }

    /**
     * Feeds already loaded this request, keyed by space, page and page size, so the
     * head tags (which need to know whether page N exists) and the body (which
     * paints it) share one query.
     */
    protected static $feeds = [];

    protected function renderFor($model, $context)
    {
        $page = $this->paintedPage($model, Arr::get($context, 'path', ''));

        if (!$page) {
            return;
        }

        $space = $this->resolveSpace($model, Arr::get($context, 'path', ''));
        $perPage = $this->perPage($space);
        $feeds = $this->loadFeeds($space, $page, $perPage);

        $this->openLayout($space, 'space_feeds', true);

        // The sticky post is pinned to page one in the SPA, so it stays there here.
        $sticky = $page === 1 ? $this->getStickyFeed($space) : null;

        if ($sticky) {
            ?>
            <div class="fcom_sticky_feed"><?php $this->renderFeedCard($sticky, 'list'); ?></div>
            <?php
        }

        ?>
        <div class="fcom_feed_style_timeline all_feeds">
            <div class="all_feeds_holder">
                <?php foreach ($feeds as $feed): ?>
                    <?php $this->renderFeedCard($feed, 'list'); ?>
                <?php endforeach; ?>
            </div>
        </div>
        <?php

        $this->renderPagination($space, $page, $perPage, count($feeds));

        $this->closeLayout();
    }

    /**
     * Without this a crawler reaches the space - the hub that links to everything -
     * and can only see the newest ten posts. Everything older is reachable only from
     * the sitemap, which carries no context about how posts relate.
     *
     * The SPA does not read `page` from the query string (its listing is load-more
     * driven), so these links are for crawlers and the no-JS paint. A visitor who
     * clicks one gets the right page server-side and then the SPA resets to page one
     * when it mounts; making that consistent needs Feeds.vue to honour the parameter.
     */
    protected function renderPagination($space, $page, $perPage, $renderedCount)
    {
        $baseUrl = Helper::baseUrl('space/' . $space->slug . '/home');
        $hasNext = $renderedCount === $perPage;

        if ($page === 1 && !$hasNext) {
            return;
        }

        $pageUrl = function ($number) use ($baseUrl) {
            return $number <= 1 ? $baseUrl : add_query_arg('page', $number, $baseUrl);
        };

        ?>
        <nav class="fcom_pre_render_pagination" aria-label="<?php esc_attr_e('Posts pagination', 'fluent-community-pro'); ?>">
            <?php if ($page > 1): ?>
                <a rel="prev" href="<?php echo esc_url($pageUrl($page - 1)); ?>"><?php esc_html_e('Newer posts', 'fluent-community-pro'); ?></a>
            <?php endif; ?>
            <?php if ($hasNext): ?>
                <a rel="next" href="<?php echo esc_url($pageUrl($page + 1)); ?>"><?php esc_html_e('Older posts', 'fluent-community-pro'); ?></a>
            <?php endif; ?>
        </nav>
        <?php
    }

    /**
     * Bounded so a crawler cannot walk an unbounded query string into the database.
     *
     * Anything that is not a clean positive integer within the cap returns 0 and is
     * not pre-rendered at all. Clamping instead would serve one page's posts at every
     * one of ?page=101..n, and coercing junk (absint('-5') is 5, absint('abc') is 0)
     * would put real content behind an unbounded set of nonsense URLs. The SPA still
     * shows page one to a human in every one of those cases; only the pre-paint is
     * withheld. Posts past the cap stay reachable through the sitemap.
     *
     * @return int Page to render, or 0 when the request should not be pre-rendered.
     */
    protected function currentPage()
    {
        return self::requestedPage();
    }

    /**
     * Static because the head tags need the same answer as the body: the canonical
     * of ?page=N has to point at ?page=N only when that page is what gets painted.
     *
     * @return int
     */
    public static function requestedPage()
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination read
        $raw = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';

        if ($raw === '') {
            return 1;
        }

        if (!ctype_digit($raw) || (int) $raw < 1) {
            return 0;
        }

        $maxPage = (int) apply_filters('fluent_community/seo/pre_render_max_page', 100);

        return (int) $raw > $maxPage ? 0 : (int) $raw;
    }

    protected function perPage($space)
    {
        return (int) apply_filters('fluent_community/seo/pre_render_feed_count', 10, $space);
    }

    /**
     * PortalHandler only excludes `secret` when it builds the head tags, because a
     * private space still gets a title and an OG card. A body is a different question:
     * an anonymous visitor cannot read a private space, so only public ones are
     * pre-rendered.
     *
     * The listing is also the only sub-route worth rendering - /members, /about and
     * the rest are separate views, and painting a post list under them would be wrong.
     */
    protected function resolveSpace($contextModel, $path)
    {
        if (!$contextModel instanceof BaseSpace) {
            return null;
        }

        if ($contextModel->privacy !== 'public' || $contextModel->status !== 'published') {
            return null;
        }

        if (!$this->isFeedListingRoute($path)) {
            return null;
        }

        return $contextModel;
    }

    /**
     * PortalHandler hands over the portal-relative path it already resolved, so the
     * routing rules live in exactly one place.
     */
    protected function isFeedListingRoute($path)
    {
        return self::isListingPath($path);
    }

    public static function isListingPath($path)
    {
        $parts = array_values(array_filter(explode('/', trim((string) $path, '/'))));

        // `space/{slug}` (SpaceHomeRedirect) and `space/{slug}/home` (SpaceFeeds).
        if (count($parts) === 2) {
            return true;
        }

        return count($parts) === 3 && $parts[2] === 'home';
    }

    /**
     * The page this request paints for the given space, or 0 when it paints nothing:
     * every gate renderFor() applies, including whether the page has any posts. The
     * head tags ask this before the body runs, so ?page=N is only its own canonical
     * when page N is actually on the page - an empty page past the end still shows
     * page one, and keeps page one's canonical.
     *
     * @return int
     */
    public function paintedPage($contextModel, $path)
    {
        $space = $this->resolveSpace($contextModel, $path);

        if (!$space) {
            return 0;
        }

        $page = $this->currentPage();

        if ($page > 1 && !count($this->loadFeeds($space, $page, $this->perPage($space)))) {
            return 0;
        }

        return $page;
    }

    protected function loadFeeds($space, $page, $perPage)
    {
        $key = (isset($space->id) ? $space->id : spl_object_id($space)) . ':' . $page . ':' . $perPage;

        if (!isset(self::$feeds[$key])) {
            self::$feeds[$key] = $this->getFeeds($space, $page, $perPage);
        }

        return self::$feeds[$key];
    }

    public static function resetFeedCache()
    {
        self::$feeds = [];
    }

    /**
     * The relations a listing card reads: author, space and topics. The single-post
     * relation set also eager-loads every comment (with its author) and the reaction
     * sample, which a list card never prints - ten well-discussed posts would hydrate
     * thousands of rows the feed LIMIT does not bound. Those two are left out here.
     */
    public static function listingRelations($space)
    {
        return Arr::except(Feed::withPublicRelations(null, $space), [ 'comments', 'reactions' ]);
    }

    /**
     * FeedsHelper::transformFeed() walks `$feed->comments`; on a model that never
     * loaded the relation that is a lazy load of every comment, per feed. An empty
     * collection set up front is what "no comments were loaded" has to look like.
     */
    protected function withoutComments(Feed $feed)
    {
        return $feed->setRelation('comments', $feed->newCollection());
    }

    /**
     * Mirrors FeedsController@get for the anonymous, unfiltered, first page: the
     * listing a logged-out visitor actually lands on.
     */
    protected function getFeeds($space, $page = 1, $perPage = 10)
    {
        $feeds = Feed::query()
            ->select(Feed::$publicColumns)
            ->with(self::listingRelations($space))
            ->byContentModerationAccessStatus(null, $space)
            ->customOrderBy(Arr::get($space->settings, 'default_post_sort_by', ''))
            ->filterBySpaceSlug($space->slug)
            ->where('is_sticky', 0)
            ->byUserAccess(0)
            ->whereHas('xprofile', function ($q) {
                $q->where('status', 'active');
            })
            ->limit($perPage)
            ->offset(($page - 1) * $perPage)
            ->get()
            ->each(function (Feed $feed) {
                $this->withoutComments($feed);
            });

        return FeedsHelper::transformFeedsCollection($feeds);
    }

    protected function getStickyFeed($space)
    {
        $sticky = Feed::query()
            ->where('space_id', $space->id)
            ->where('is_sticky', 1)
            ->select(Feed::$publicColumns)
            ->with(self::listingRelations($space))
            ->byContentModerationAccessStatus(null, $space)
            ->byUserAccess(0)
            ->first();

        return $sticky ? FeedsHelper::transformFeed($this->withoutComments($sticky)) : null;
    }
}
