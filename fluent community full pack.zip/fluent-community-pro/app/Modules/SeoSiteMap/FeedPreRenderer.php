<?php

namespace FluentCommunityPro\App\Modules\SeoSiteMap;

use FluentCommunity\App\Models\Feed;
use FluentCommunity\App\Services\FeedsHelper;
use FluentCommunity\Framework\Support\Arr;

/**
 * Server-rendered first paint for single feed views.
 *
 * Beyond the shared markup in AbstractPortalPreRenderer, this inlines the payload the
 * REST endpoint would have returned as `window.__showing_feed`. ViewFeed.vue already
 * prefers that global over fetching - it is how client-side navigation from a feed
 * list avoids a round trip - so the seeded render removes the REST call from the
 * critical path instead of causing a content flash.
 */
class FeedPreRenderer extends AbstractPortalPreRenderer
{
    protected function routeName()
    {
        return 'feed_view';
    }

    protected function renderFor($model, $context)
    {
        $feed = $this->resolveFeed($model);

        if (!$feed) {
            return;
        }

        $this->openLayout($feed->space, 'space_feed');
        $this->renderFeedCard($feed, 'single');
        $this->closeLayout();

        $this->renderDataIsland('__showing_feed', $this->withoutComments($feed));
    }

    /**
     * The island carries no comments. The body above painted a bounded page of them
     * for crawlers; the SPA must not mistake that page for the whole thread, and it
     * does not have to: __FeedComments.vue fetches feeds/{id}/comments itself when
     * the feed it is given has no `comments` key. An empty array would not do - it is
     * truthy in JavaScript and would read as "this post has no comments".
     */
    protected function withoutComments($feed)
    {
        // A shallow copy: the caller's model keeps its comments, the island's does not.
        $seed = clone $feed;
        unset($seed->comments);

        return $seed;
    }

    /**
     * Re-query rather than reuse the model handed over by PortalHandler: that one is
     * loaded for meta tags (no reactions or terms) and with every column, so
     * serialising it would hand the SPA a differently-shaped feed than the REST
     * endpoint returns. Mirroring FeedsController@getFeedBySlug keeps the seeded
     * payload and the fetched payload identical - except for the comments, which the
     * REST relation set loads in full. A popular post has thousands; the body needs a
     * bounded page of them and the island none, so they come from FeedComments, the
     * same capped query the JSON-LD already ran for this request.
     */
    protected function resolveFeed($contextModel)
    {
        if (!$contextModel instanceof Feed) {
            return null;
        }

        $feed = Feed::query()
            ->where('id', $contextModel->id)
            ->select(Feed::$publicColumns)
            ->with(Arr::except(Feed::withPublicRelations(null), [ 'comments' ]))
            ->whereHas('xprofile', function ($q) {
                $q->where('status', 'active');
            })
            ->byUserAccess(0)
            ->first();

        if (!$feed) {
            return null;
        }

        if (!in_array($feed->status, FeedsHelper::getViewableByLinkStatuses(), true)) {
            return null;
        }

        // Set before the transform: FeedsHelper::transformFeed() walks the relation,
        // and on a model that never loaded it that is a lazy load of every comment.
        $feed->setRelation('comments', FeedComments::forFeed($feed->id));

        return FeedsHelper::transformFeed($feed);
    }
}
