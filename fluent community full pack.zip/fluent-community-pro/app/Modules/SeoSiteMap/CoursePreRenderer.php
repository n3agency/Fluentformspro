<?php

namespace FluentCommunityPro\App\Modules\SeoSiteMap;

use FluentCommunity\App\Services\FeedsHelper;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunity\Modules\Course\Model\Course;

/**
 * Server-rendered first paint for a course landing page.
 *
 * These are the pages the sitemap has been submitting with nothing in them: the whole
 * course view - title, description, curriculum, lock screen, prices - is SPA-only, so a
 * crawler that does not run JavaScript received an empty container. A paid course was
 * being advertised to search engines as a blank page.
 *
 * What gets painted follows what the SPA shows a logged-out visitor, never more:
 * a public course shows its curriculum, a private one shows its lock screen.
 */
class CoursePreRenderer extends AbstractPortalPreRenderer
{
    protected function routeName()
    {
        return 'course_view';
    }

    protected function renderFor($model, $context)
    {
        $course = $this->resolveCourse($model, Arr::get($context, 'path', ''));

        if (!$course) {
            return;
        }

        $sections = $this->getSections($course);

        $this->openCourseLayout($course);
        $this->renderCourseIntro($course, $sections);

        // ViewCourse.vue: a private course shows its lock screen to a logged-out
        // visitor, and a custom lock screen decides for itself whether the curriculum
        // is one of its sections. A curriculum outside the lock screen would drop
        // the sales copy around it.
        if ($course->privacy === 'private') {
            $this->renderLockscreen($course, $sections);
        } else {
            $this->renderCurriculum($sections);
        }

        $this->closeCourseLayout();
    }

    /**
     * PortalHandler hands over any course that is not secret, drafts included, so the
     * gates that decide whether this page is worth describing live here - the same ones
     * the structured data uses.
     */
    protected function resolveCourse($contextModel, $path)
    {
        if (!$this->isCourseLandingRoute($path)) {
            return null;
        }

        $course = $this->findCourse($this->courseSlug($path));

        if (!$course || $course->privacy === 'secret') {
            return null;
        }

        if (CourseVisibility::redirectsAway($course)) {
            return null;
        }

        return $course;
    }

    protected function findCourse($slug)
    {
        return Course::query()
            ->where('slug', $slug)
            ->where('status', 'published')
            ->first();
    }

    /**
     * `course/{slug}/lessons` only. A lesson URL nests under the same prefix and is a
     * different view with its own gating.
     */
    protected function isCourseLandingRoute($path)
    {
        $parts = array_values(array_filter(explode('/', trim($path, '/'))));

        return count($parts) === 3 && $parts[0] === 'course' && $parts[2] === 'lessons';
    }

    protected function courseSlug($path)
    {
        $parts = array_values(array_filter(explode('/', trim($path, '/'))));

        return isset($parts[1]) ? $parts[1] : '';
    }

    /**
     * Shared with the JSON-LD, which ran during the head tags of this same request.
     */
    protected function getSections($course)
    {
        return CourseCurriculum::sections($course);
    }

    protected function openCourseLayout($course)
    {
        ?>
        <div class="fcom_single_layout fcom_max_layout fcom_course_view_layout">
            <div class="no_bg_layout fcom_route_view_course fhr_content_layout">
                <?php $this->renderCourseHeader($course); ?>
                <div class="fhr_content_layout_body">
                    <section class="el-container fcom_resp_container fcom_space_container fcom_main_container">
                        <main class="el-main fcom_main">
                            <div class="fcom_feed_box course_box">
                                <div class="fcom_course_sections">
        <?php
    }

    protected function closeCourseLayout()
    {
        ?>
                                </div>
                            </div>
                        </main>
                        <aside class="el-aside fcom_resp_side" style="--el-aside-width: 306px;"></aside>
                    </section>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * The SPA puts the course name in a breadcrumb here and repeats it as an h3 in the
     * intro below. For a crawler the course name is the document heading, so it is an
     * h1 in the intro and the breadcrumb carries only the trail.
     */
    protected function renderCourseHeader($course)
    {
        $coursesUrl = Helper::baseUrl('courses');

        ?>
        <div class="fhr_content_layout_header">
            <h2 class="fcom_page_title">
                <nav aria-label="<?php esc_attr_e('Breadcrumb', 'fluent-community-pro'); ?>" class="el-breadcrumb">
                    <span class="el-breadcrumb__item">
                        <a class="el-breadcrumb__inner is-link" href="<?php echo esc_url($coursesUrl); ?>"><?php esc_html_e('Courses', 'fluent-community-pro'); ?></a>
                    </span>
                    <span class="el-breadcrumb__item">
                        <span class="el-breadcrumb__inner"><?php echo esc_html($course->title); ?></span>
                    </span>
                </nav>
            </h2>
        </div>
        <?php

        // ViewCourse.vue shows the course links only with the curriculum
        // (`showCourseSections`), which is never the case for a logged-out visitor to
        // a private course - even one whose custom lock screen lists the lessons.
        if ($course->privacy !== 'private') {
            $this->renderSpaceLinks($course);
        }
    }

    protected function renderCourseIntro($course, $sections)
    {
        $lessonCount = 0;

        foreach ($sections as $section) {
            $lessonCount += count($section->lessons);
        }

        $sectionCount = count($sections);
        $details = $this->courseDetailsHtml($course);

        ?>
        <div class="fcom_course_intro">
            <div class="fcom_course_labels">
                <h1><?php echo esc_html($course->title); ?></h1>
                <p class="fcom_course_info">
                    <?php
                    /* translators: %s is the number of topics */
                    echo esc_html(sprintf(_n('%s Topic', '%s Topics', $sectionCount, 'fluent-community-pro'), number_format_i18n($sectionCount)));
                    ?>
                    <span> • </span>
                    <?php
                    /* translators: %s is the number of lessons */
                    echo esc_html(sprintf(_n('%s Lesson', '%s Lessons', $lessonCount, 'fluent-community-pro'), number_format_i18n($lessonCount)));
                    ?>
                </p>
            </div>
        </div>
        <?php if ($course->description): ?>
            <div class="fcom_course_description feed_md_content"><?php echo wp_kses_post(wpautop($course->description)); ?></div>
        <?php endif; ?>
        <?php if ($details): ?>
            <div class="fcom_course_details feed_md_content"><?php echo wp_kses_post($details); ?></div>
            <?php
        endif;
    }

    /**
     * `course_details_rendered` is not a stored setting: CourseController::processCourse()
     * derives it from `course_details` for the REST response and never persists it, so
     * a model straight from the database only ever has the Markdown source. Render it
     * the same way the controller does.
     */
    protected function courseDetailsHtml($course)
    {
        $rendered = Arr::get($course->settings, 'course_details_rendered');

        if ($rendered) {
            return $rendered;
        }

        $source = Arr::get($course->settings, 'course_details');

        return $source ? wp_kses_post(FeedsHelper::mdToHtml($source)) : '';
    }

    protected function renderCurriculum($sections)
    {
        if (!count($sections)) {
            return;
        }

        ?>
        <div class="course_contents_header">
            <h4><?php esc_html_e('Course Contents', 'fluent-community-pro'); ?></h4>
        </div>
        <div class="fcom_card_sections">
            <div class="fcom_section_items">
                <?php foreach ($sections as $section): ?>
                    <div class="fcom_section_primary">
                        <div class="fcom_section_primary_item">
                            <div class="fcom_section_primary_item_title">
                                <div class="title_line_container">
                                    <div class="title_line">
                                        <h4><?php echo esc_html($section->title); ?></h4>
                                    </div>
                                    <span class="fcom_meta_text">
                                        <?php
                                        $count = count($section->lessons);
                                        /* translators: %s is the number of lessons in the section */
                                        echo esc_html(sprintf(_n('%s lesson', '%s lessons', $count, 'fluent-community-pro'), number_format_i18n($count)));
                                        ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <?php foreach ($section->lessons as $lesson): ?>
                            <div class="fcom_section_item">
                                <div class="fcom_section_item_title">
                                    <p class="fcom_heading_item">
                                        <a href="<?php echo esc_url($lesson->getPermalink()); ?>"><?php echo esc_html($lesson->title); ?></a>
                                    </p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    /**
     * Mirrors _LockscreenView.vue for a logged-out visitor: the default lock box, or
     * the configured fields when the course uses a custom lock screen. Element Plus
     * icons and the paywall's checkout buttons are left out - they are components, and
     * a crawler gets nothing from an inert button.
     */
    protected function renderLockscreen($course, $sections)
    {
        if (CourseVisibility::hasCustomLockscreen($course)) {
            $this->renderCustomLockscreen($course, $sections);
            return;
        }

        $showPaywalls = CourseVisibility::showsPaywalls($course);

        ?>
        <div class="space_default_lockscreen">
            <div class="space_lock_box space_default_lock_box">
                <h4><?php esc_html_e('This is a private course', 'fluent-community-pro'); ?></h4>
                <p class="lock_desc">
                    <?php
                    if ($showPaywalls) {
                        esc_html_e('Purchase access below or log in if you are already a member.', 'fluent-community-pro');
                    } else {
                        esc_html_e('Members have to be invited to this course.', 'fluent-community-pro');
                    }
                    ?>
                </p>
            </div>
            <?php
            if ($showPaywalls) {
                $this->renderPaywalls($course);
            }
            ?>
        </div>
        <?php
    }

    /**
     * Follows _CustomLockscreenView.vue field by field, in the order the admin
     * arranged them: banners, block content, the curriculum where its `lesson` section
     * is switched on, and the paywall fields with the variants each one selected. The
     * welcome banner is skipped - it is a dismissable, per-visitor notice.
     */
    protected function renderCustomLockscreen($course, $sections)
    {
        $fields = CourseVisibility::lockscreenFields($course);

        if (!$fields) {
            return;
        }

        ?>
        <div class="fcom_custom_lockscreen">
            <div class="fcom_lockscreen_content">
                <?php foreach ($fields as $field): ?>
                    <?php $type = Arr::get($field, 'type'); ?>
                    <?php if ($type === 'image'): ?>
                        <div class="fcom_item">
                            <div class="fcom_image_wrap">
                                <div class="fcom_content">
                                    <h2><?php echo esc_html(Arr::get($field, 'heading')); ?></h2>
                                    <p><?php echo esc_html(Arr::get($field, 'description')); ?></p>
                                    <?php if (Arr::get($field, 'button_text') && Arr::get($field, 'button_link')): ?>
                                        <a class="fcom_btn" href="<?php echo esc_url(Arr::get($field, 'button_link')); ?>"><?php echo esc_html(Arr::get($field, 'button_text')); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php elseif ($type === 'block' && Arr::get($field, 'content')): ?>
                        <div class="fcom_item">
                            <div class="fcom_content_wrap">
                                <div class="fcom_custom_editor_html"><?php echo wp_kses_post(Arr::get($field, 'content')); ?></div>
                            </div>
                        </div>
                    <?php elseif ($type === 'lesson'): ?>
                        <div class="fcom_item">
                            <div class="fcom_content_wrap"><?php $this->renderCurriculum($sections); ?></div>
                        </div>
                    <?php elseif ($type === 'paywall' && (array) Arr::get($field, 'paywalls', [])): ?>
                        <div class="fcom_item"><?php $this->renderPaywalls($course, (array) Arr::get($field, 'paywalls', [])); ?></div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    /**
     * @param int[] $variantIds The variants a custom lock screen field selected; empty
     *                          for the default lock screen, which shows all of them.
     */
    protected function getPaywalls($course, $variantIds = [])
    {
        return CoursePaywalls::forCourse($course, $variantIds);
    }

    protected function renderPaywalls($course, $variantIds = [])
    {
        $paywalls = $this->getPaywalls($course, $variantIds);

        if (!$paywalls) {
            return;
        }

        ?>
        <div class="fcom_paywall_wrap">
            <ul class="fcom_paywall_items">
                <?php foreach ($paywalls as $paywall): ?>
                    <?php $interval = CoursePaywalls::intervalLabel($paywall); ?>
                    <li class="fcom_paywall_item">
                        <span class="fcom_paywall_title"><?php echo esc_html($paywall['variant_title'] ? $paywall['variant_title'] : $paywall['product_title']); ?></span>
                        <span class="fcom_paywall_price">
                        <?php
                            echo esc_html(wp_strip_all_tags(html_entity_decode((string) $paywall['price_display'])));
                        if ($interval) {
                            // The SPA prints "$49 / month" for a subscription; a bare
                            // "$49" would quote a recurring charge as a one-off.
                            echo ' / ' . esc_html($interval);
                        }
                        ?>
                        </span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php
    }
}
