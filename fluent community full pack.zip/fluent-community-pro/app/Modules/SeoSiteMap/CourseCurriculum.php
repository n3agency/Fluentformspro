<?php

namespace FluentCommunityPro\App\Modules\SeoSiteMap;

use FluentCommunity\App\Models\BaseSpace;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunity\Modules\Course\Model\CourseTopic;

/**
 * The published curriculum of a course, loaded once per request.
 *
 * Three things on an anonymous course page want it: the pre-rendered body, the
 * JSON-LD syllabus, and the workload figure. Each used to run its own query - and
 * the workload one hydrated every lesson in full - so a large course paid for its
 * lessons three times on every crawl. Everything now reads from here.
 *
 * Columns are kept to what the consumers use. The lesson body is the wide column,
 * and it is only selected when the page actually describes the curriculum: a
 * private course behind a lock screen loads its lessons title-only, for the counts
 * in the intro and the workload in the structured data.
 */
class CourseCurriculum
{
    /** @var array<int, \FluentCommunity\Framework\Database\Orm\Collection> */
    protected static $sections = [];

    /**
     * Sections in order, each with its published lessons in order. Every lesson has
     * its `course` relation set to the given model, so getPermalink() does not query.
     */
    public static function sections(BaseSpace $course)
    {
        if (isset(self::$sections[$course->id])) {
            return self::$sections[$course->id];
        }

        $columns = [ 'id', 'parent_id', 'space_id', 'slug', 'title', 'status', 'priority', 'meta' ];

        if (CourseVisibility::showsCurriculum($course)) {
            $columns[] = 'message';
        }

        $sections = CourseTopic::where('space_id', $course->id)
            ->orderBy('priority', 'ASC')
            ->with([
        'lessons' => function ($query) use ($columns) {
                $query->select($columns)->where('status', 'published');
        },
        ])
            ->get();

        foreach ($sections as $section) {
            foreach ($section->lessons as $lesson) {
                $lesson->setRelation('course', $course);
            }
        }

        return self::$sections[$course->id] = $sections;
    }

    /**
     * @return \FluentCommunity\Modules\Course\Model\CourseLesson[]
     */
    public static function lessons(BaseSpace $course)
    {
        $lessons = [];

        foreach (self::sections($course) as $section) {
            foreach ($section->lessons as $lesson) {
                $lessons[] = $lesson;
            }
        }

        return $lessons;
    }

    /**
     * Total of the lessons' recorded video lengths, in seconds - the figure the SPA
     * prints next to each lesson, so a video course can state its real length.
     */
    public static function videoSeconds(BaseSpace $course)
    {
        $seconds = 0;

        foreach (self::lessons($course) as $lesson) {
            $seconds += (int) Arr::get($lesson->meta, 'video_length', 0);
        }

        return $seconds;
    }

    public static function reset()
    {
        self::$sections = [];
    }
}
