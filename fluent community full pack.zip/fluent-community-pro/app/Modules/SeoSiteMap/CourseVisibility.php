<?php

namespace FluentCommunityPro\App\Modules\SeoSiteMap;

use FluentCommunity\App\Models\BaseSpace;
use FluentCommunity\App\Services\LockscreenService;
use FluentCommunity\Framework\Support\Arr;

/**
 * What an anonymous visitor is actually shown on a course page.
 *
 * Both the pre-render and the structured data have to answer the same question, and
 * they have to answer it the same way: markup that describes content the page does not
 * show is exactly the mismatch Google penalises, and a pre-render that paints a
 * curriculum the SPA then hides would flash the wrong thing at every visitor.
 */
class CourseVisibility
{
    /**
     * ViewCourse.vue: `showCourseSections = isEnrolled || is_course_admin ||
     * !lockscreen_config`. Nobody is enrolled or an admin here, and
     * LockscreenService returns null for anything that is not private - so a public
     * course shows its whole curriculum to a logged-out visitor, and a private one
     * shows the lock screen instead.
     *
     * The exception is a custom lock screen with its `lesson` section switched on:
     * that is a course deliberately advertising its curriculum to non-members.
     */
    public static function showsCurriculum(BaseSpace $course)
    {
        if ($course->privacy !== 'private') {
            return true;
        }

        if (!self::hasCustomLockscreen($course)) {
            return false;
        }

        foreach (self::lockscreenFields($course) as $field) {
            if (Arr::get($field, 'type') === 'lesson') {
                return true;
            }
        }

        return false;
    }

    /**
     * Whether the page quotes any price to a logged-out visitor.
     *
     * Mirrors LockscreenService::getLockscreenConfig() for the default lock screen
     * (`show_paywalls`) and _CustomLockscreenView.vue for a custom one, which only
     * renders a `paywall` field that has variants selected. Structured data must not
     * advertise an offer the page does not show. Whether FluentCart is installed is
     * CoursePaywalls' concern: without it there are simply no prices to show.
     */
    public static function showsPaywalls(BaseSpace $course)
    {
        if ($course->privacy !== 'private') {
            return false;
        }

        if (self::hasCustomLockscreen($course)) {
            return (bool) self::visiblePaywallFields($course);
        }

        return Arr::get($course->settings, 'show_paywalls') === 'yes';
    }

    /**
     * The variant ids a custom lock screen has chosen to display, across all of its
     * visible paywall fields. Empty means "no restriction" - the default lock screen
     * shows every variant of every attached product - so callers must check
     * showsPaywalls() first rather than reading an empty list as "show all".
     *
     * @return int[]
     */
    public static function visiblePaywallVariantIds(BaseSpace $course)
    {
        if (!self::hasCustomLockscreen($course)) {
            return [];
        }

        $ids = [];

        foreach (self::visiblePaywallFields($course) as $field) {
            foreach ((array) Arr::get($field, 'paywalls', []) as $variantId) {
                $ids[] = (int) $variantId;
            }
        }

        return array_values(array_unique(array_filter($ids)));
    }

    /**
     * A course set to redirect sends unenrolled visitors somewhere else the moment the
     * SPA boots, so there is no page here to describe.
     */
    public static function redirectsAway(BaseSpace $course)
    {
        return $course->privacy === 'private'
            && Arr::get($course->settings, 'custom_lock_screen') === 'redirect'
            && Arr::get($course->settings, 'onboard_redirect_url');
    }

    public static function hasCustomLockscreen(BaseSpace $course)
    {
        return Arr::get($course->settings, 'custom_lock_screen') === 'yes';
    }

    /**
     * `$viewOnly` renders block content the way the SPA receives it, so the pre-render
     * prints the same HTML rather than raw block comments.
     */
    public static function lockscreenFields(BaseSpace $course)
    {
        $fields = LockscreenService::getLockscreenSettings($course, true);

        return array_values(array_filter((array) $fields, function ($field) {
            return is_array($field) && !Arr::get($field, 'hidden');
        }));
    }

    /**
     * _CustomLockscreenView.vue renders a paywall field only when it has variants
     * selected (`field.paywalls?.length > 0`).
     */
    protected static function visiblePaywallFields(BaseSpace $course)
    {
        return array_values(array_filter(self::lockscreenFields($course), function ($field) {
            return Arr::get($field, 'type') === 'paywall' && (array) Arr::get($field, 'paywalls', []);
        }));
    }
}
