<?php

namespace FluentCommunityPro\App\Modules\MediaGallery\Http;

use FluentCommunity\App\Http\Controllers\Controller;
use FluentCommunity\App\Models\Space;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunityPro\App\Modules\MediaGallery\Services\MediaGalleryService;

class MediaGalleryController extends Controller
{
    public function index(Request $request, $spaceSlug)
    {
        $spaceSlug = sanitize_text_field($spaceSlug);

        $space = Space::where('slug', $spaceSlug)->first();
        if (!$space) {
            return $this->sendError([
                'message' => __('Space not found', 'fluent-community-pro'),
            ], 404);
        }

        $user = $this->getUser();

        if (!$space->verifyUserPermisson($user, 'can_view_media', false)) {
            return $this->sendError([
                'message'           => __('You do not have permission to view this gallery', 'fluent-community-pro'),
                'permission_failed' => true,
            ], 403);
        }

        $type = $request->getSafe('type', 'sanitize_text_field', 'photos');
        $type = in_array($type, ['photos', 'videos', 'audios'], true) ? $type : 'photos';

        $cursor  = (int) $request->get('cursor', 0);
        $perPage = (int) $request->get('per_page', 24);

        $data = MediaGalleryService::getItems($space, $type, $cursor, $perPage);

        $response = [
            'items'    => $data['items'],
            'has_more' => $data['has_more'],
            'cursor'   => $data['cursor'],
        ];

        // Audios tab shows only when the space has audio. Check once, on the first page.
        if (!$cursor) {
            $response['has_audio'] = MediaGalleryService::spaceHasAudio($space);
        }

        do_action('fluent_community/space_media/viewed', $space, $user, $type);

        return apply_filters('fluent_community/space_media/api_response', $response, $space, $type);
    }
}
