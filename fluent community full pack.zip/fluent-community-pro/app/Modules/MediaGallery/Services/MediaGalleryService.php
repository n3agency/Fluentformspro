<?php

namespace FluentCommunityPro\App\Modules\MediaGallery\Services;

use FluentCommunity\App\Models\Media;

class MediaGalleryService
{
    const TYPE_IMAGE_PREFIX = 'image/';
    const TYPE_VIDEO        = 'fluent_player';
    // PHP-serialized token for settings.viewType === 'audio' (both 5-char strings).
    const TYPE_AUDIO_TOKEN  = '"viewType";s:5:"audio"';

    /**
     * Fetch a page of gallery media for a space, transformed for the API.
     * Returns data only — the controller shapes the response.
     *
     * @param object $space   BaseSpace instance, already permission-validated.
     * @param string $type    'photos' | 'videos' | 'audios'.
     * @param int    $cursor  Last seen media id (0 = first page).
     * @param int    $perPage Items per page.
     * @return array{items:array<int,array<string,mixed>>, has_more:bool, cursor:int|null}
     */
    public static function getItems($space, $type, $cursor, $perPage)
    {
        $type    = in_array($type, ['photos', 'videos', 'audios'], true) ? $type : 'photos';
        $perPage = min(48, max(12, (int) $perPage));
        $cursor  = (int) $cursor;

        $query = self::buildQuery($space, $type);

        if ($cursor) {
            $query->where('id', '<', $cursor);
        }

        // Fetch N+1 so we can detect has_more without a separate COUNT.
        $rows    = $query->orderBy('id', 'desc')->limit($perPage + 1)->get();
        $hasMore = $rows->count() > $perPage;
        $rows    = $rows->take($perPage)->values();
        $lastId  = $rows->isEmpty() ? null : (int) $rows->last()->id;

        $items = $rows->map(function ($m) use ($space) {
            return self::transformItem($m, $space);
        })->all();

        return [
            'items'    => $items,
            'has_more' => $hasMore,
            'cursor'   => $hasMore ? $lastId : null,
        ];
    }

    /** Shape a media row into the API item structure (runs the space_media/transform_item filter for extensions). */
    protected static function transformItem($m, $space)
    {
        return apply_filters(
            'fluent_community/space_media/transform_item',
            [
                'id'         => (int) $m->id,
                'url'        => $m->public_url,
                'media_type' => $m->media_type,
                'kind'       => self::resolveKind($m),
                'settings'   => $m->settings ?: [],
                'created_at' => $m->created_at,
                'feed'       => $m->feed ? [
                    'id'         => (int) $m->feed->id,
                    'slug'       => $m->feed->slug,
                    'title'      => $m->feed->title,
                    'permalink'  => $m->feed->permalink,
                    'created_at' => $m->feed->created_at,
                    'author'     => $m->feed->xprofile ? [
                        'name'     => $m->feed->xprofile->display_name,
                        'avatar'   => $m->feed->xprofile->avatar,
                        'username' => $m->feed->xprofile->username,
                    ] : null,
                ] : null,
            ],
            $m,
            $space
        );
    }

    /** Whether the space has any audio item — gates the Audios tab; exists() short-circuits at the first match. */
    public static function spaceHasAudio($space)
    {
        return self::baseQuery($space)
            ->where('media_type', self::TYPE_VIDEO)
            ->where('settings', 'like', '%' . self::TYPE_AUDIO_TOKEN . '%')
            ->exists();
    }

    /** Classify a media row as image, video, or audio (video/audio share media_type; settings.viewType splits them, missing = video). */
    public static function resolveKind($m)
    {
        if ((string) $m->media_type !== self::TYPE_VIDEO) {
            return 'image';
        }
        $settings = is_array($m->settings) ? $m->settings : [];
        return (isset($settings['viewType']) && $settings['viewType'] === 'audio') ? 'audio' : 'video';
    }

    /** Base query scoping media to a space's active, published feed items. */
    protected static function baseQuery($space)
    {
        return Media::query()
            ->where('object_source', 'feed')
            ->where('is_active', 1)
            ->whereHas('feed', function ($q) use ($space) {
                $q->where('space_id', $space->id)
                  ->where('status', 'published');
            });
    }

    /** Build the type-filtered gallery query (no cursor/pagination) with eager loads. */
    protected static function buildQuery($space, $type)
    {
        $query = self::baseQuery($space)
            ->select([
                'id', 'user_id', 'feed_id',
                'media_url', 'media_type', 'driver',
                'settings', 'created_at',
            ])
            ->with([
                'feed' => function ($q) {
                    $q->select(['id', 'slug', 'space_id', 'title', 'user_id', 'created_at']);
                },
                'feed.xprofile' => function ($q) {
                    $q->select(['user_id', 'display_name', 'avatar', 'username']);
                },
            ]);

        $audioLike = '%' . self::TYPE_AUDIO_TOKEN . '%';

        if ($type === 'videos') {
            // fluent_player minus audio. NULL settings (legacy rows) count as video.
            $query->where('media_type', self::TYPE_VIDEO)
                  ->where(function ($q) use ($audioLike) {
                      $q->whereNull('settings')
                        ->orWhere('settings', 'not like', $audioLike);
                  });
        } elseif ($type === 'audios') {
            $query->where('media_type', self::TYPE_VIDEO)
                  ->where('settings', 'like', $audioLike);
        } else {
            $query->where('media_type', 'like', self::TYPE_IMAGE_PREFIX . '%');
        }

        return apply_filters('fluent_community/space_media/query', $query, $space, $type);
    }
}
