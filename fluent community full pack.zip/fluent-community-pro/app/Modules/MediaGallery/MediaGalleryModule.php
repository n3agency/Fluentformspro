<?php

namespace FluentCommunityPro\App\Modules\MediaGallery;

use FluentCommunity\Framework\Support\Arr;

class MediaGalleryModule
{
    public function register($app)
    {
        add_filter('fluent_community/space_header_links', [$this, 'addToSpaceMenu'], 0, 2);

        $app->router->group(function ($router) {
            $router->prefix('media-gallery')
                ->namespace('FluentCommunityPro\App\Modules\MediaGallery\Http')
                ->withPolicy(\FluentCommunity\App\Http\Policies\PortalPolicy::class)
                ->group(function ($router) {
                    $router->get('/{spaceSlug}', 'MediaGalleryController@index')
                           ->alphaNumDash('spaceSlug');
                });
        });
    }

    public function addToSpaceMenu($links, $space)
    {
        if (!Arr::get($space->permissions, 'can_view_media')) {
            return $links;
        }

        $links[] = [
            'title' => apply_filters(
                'fluent_community/space_media_title_label',
                __('Media', 'fluent-community-pro'),
                $space
            ),
            'route' => [
                'name' => 'space_media',
            ],
        ];

        return $links;
    }
}
