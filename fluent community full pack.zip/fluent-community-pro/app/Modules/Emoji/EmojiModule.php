<?php

namespace FluentCommunityPro\App\Modules\Emoji;

class EmojiModule
{
    public function register($app)
    {
        add_filter('fluent_community/portal_vars', function ($vars) {
            $vars['features']['emoji_app'] = true;
            return $vars;
        });

        add_action('fluent_community/before_js_loaded', function () {
            ?>
            <style>
                .emoji-type-image.emoji-set-twitter {
                    background-image: url(<?php echo esc_url(plugin_dir_url(__FILE__) . 'emoji-set.png'); ?>);
                }
            </style>
            <?php
        });

    }
}
