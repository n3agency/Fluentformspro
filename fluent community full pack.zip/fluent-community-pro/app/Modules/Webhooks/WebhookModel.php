<?php

namespace FluentCommunityPro\App\Modules\Webhooks;

use FluentCommunity\App\Models\Meta;
use FluentCommunity\App\Services\Helper;

class WebhookModel extends Meta
{

    protected $appends = ['webhook_url'];

    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->object_type = 'webhook';
            $model->meta_key = $model->generateUniqueSlug();
        });

        static::addGlobalScope('object_type', function ($builder) {
            $builder->where('object_type', 'webhook');
        });
    }

    public function scopeSearchBy($query, $search)
    {
        if (!$search) {
            return $query;
        }

        // Escape LIKE metacharacters so user input is treated as a literal string
        $escaped = str_replace(['\\', '%', '_'], ['\\\\', '\%', '\_'], $search);

        return $query->where('meta_key', 'like', "%{$escaped}%")
            ->orWhere('value', 'like', "%{$escaped}%");
    }

    public function generateUniqueSlug()
    {
        $slug = bin2hex(random_bytes(32));

        if (self::where('meta_key', $slug)->exists()) {
            return $this->generateUniqueSlug();
        }

        return $slug;
    }

    public function getWebhookUrlAttribute()
    {
        return Helper::baseUrl('?fcom_action=incoming_webhook&webhook=' . $this->meta_key);
    }
}
