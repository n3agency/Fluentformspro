<?php

namespace FluentCommunityPro\App\Modules\SpacePages;

use FluentCommunity\App\Models\BaseSpace;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Modules\SpacePages\Services\SpacePageHelper;

class SpacePagesModule
{
    public function register($app)
    {
        $app->router->group(function ($router) {
            require_once __DIR__ . '/Http/space_pages_api.php';
        });

        add_filter('fluent_community/user/space/permissions', [$this, 'addSpacePermissions'], 10, 4);

        // After Media (0) and Documents (1) so pages sit rightmost in the tab bar.
        add_filter('fluent_community/space_header_links', [$this, 'addToSpaceMenu'], 5, 2);

        add_filter('fluent_community/block_editor_post_types', [$this, 'registerEditorPostType']);
        add_filter('fluent_community/block_editor_context', [$this, 'handleEditorContext'], 10, 3);

        add_filter('fluent_community/portal_page_meta', [$this, 'maybePushPageMeta'], 10, 2);

        // A deleted space should not leave orphan page rows behind.
        add_action('fluent_community/space/before_delete', [$this, 'deleteSpacePages']);
    }

    /**
     * @param array $permissions
     * @param BaseSpace $space
     * @param string|null $role
     * @param \FluentCommunity\App\Models\User $user
     * @return array
     */
    public function addSpacePermissions($permissions, $space, $role, $user)
    {
        $canView = true;

        if (!$role || $role === 'pending') {
            if (in_array($space->privacy, ['secret', 'private'], true)) {
                $canView = false;
            }
        }

        $permissions['can_view_pages'] = $canView;
        $permissions['can_manage_pages'] = $user && $space->isAdmin($user->ID, true);

        return $permissions;
    }

    /**
     * @param array $links
     * @param BaseSpace $space
     * @return array
     */
    public function addToSpaceMenu($links, $space)
    {
        // Courses have no page viewer route in the portal SPA yet, and pushing an
        // unresolvable route name would break the tab bar. Phase 2 adds course_page.
        if ($space->type !== 'community') {
            return $links;
        }

        $pages = SpacePageHelper::getViewableNavPages($space, Helper::getCurrentUser(true));

        if (!$pages) {
            return $links;
        }

        foreach ($pages as $page) {
            $links[] = [
                'title' => esc_html($page->getNavLabel()),
                'route' => [
                    'name'   => 'space_page',
                    'params' => [
                        'page_slug' => $page->slug
                    ]
                ]
            ];
        }

        return $links;
    }

    public function registerEditorPostType($postTypes)
    {
        $postTypes['fcom-page'] = [
            'label'        => 'Space Page',
            'public'       => false,
            'show_in_rest' => true,
            'supports'     => ['title', 'editor', 'thumbnail'],
        ];

        return $postTypes;
    }

    /**
     * Authorizes and seeds the Gutenberg iframe for context=space_page.
     *
     * @param array $config
     * @param string|null $context
     * @param array $data
     * @return array
     */
    public function handleEditorContext($config, $context, $data)
    {
        if ($context !== 'space_page') {
            return $config;
        }

        $config['post_type'] = 'fcom-page';
        $config['has_access'] = false;

        // Merged into fcomEditorVars by FluentBlockEditorHandler, so the layout picker
        // in the sidebar renders the same registry sanitizeMeta() validates against.
        $config['editor_vars'] = [
            'page_layouts' => SpacePageHelper::getLayoutTemplates(),
        ];

        $pageId = (int)Arr::get($data, 'page_id');

        if (!$pageId) {
            return $config;
        }

        $page = SpacePageModel::find($pageId);

        if (!$page || !$page->space_id) {
            return $config;
        }

        $space = BaseSpace::withoutGlobalScopes()->find($page->space_id);

        if (!SpacePageHelper::canManagePages($space)) {
            return $config;
        }

        $config['has_access'] = true;
        $config['has_content'] = true;
        $config['title'] = $page->title;
        $config['content'] = $page->message;

        return $config;
    }

    /**
     * Server rendered SEO/OG tags for a page URL, so shared links unfurl correctly.
     *
     * @param array $data
     * @param string $currentPath
     * @return array
     */
    public function maybePushPageMeta($data, $currentPath)
    {
        if (!$currentPath || strpos('//' . $currentPath, '/page/') === false) {
            return $data;
        }

        $parts = array_values(array_filter(explode('/', $currentPath), 'strlen'));

        $spaceSlug = '';
        $pageSlug = '';

        if (count($parts) >= 4 && in_array($parts[0], ['space', 'course'], true) && $parts[2] === 'page') {
            $spaceSlug = $parts[1];
            $pageSlug = $parts[3];
        }

        // page/{slug} is reserved for community wide pages, which have no route yet.
        if (!$spaceSlug || !$pageSlug) {
            return $data;
        }

        // Resolve the space first: page slugs are only unique within one, so a
        // slug-first lookup would answer with whichever space happened to be created
        // first and then fail the slug comparison, costing the real page its metadata.
        $space = BaseSpace::withoutGlobalScopes()
            ->where('slug', $spaceSlug)
            ->where('status', 'published')
            ->where('privacy', 'public')
            ->first();

        if (!$space) {
            return $data;
        }

        $page = SpacePageModel::where('space_id', $space->id)
            ->where('slug', $pageSlug)
            ->where('status', 'published')
            ->where('privacy', 'public')
            ->first();

        if (!$page) {
            return $data;
        }

        $data['landing_route'] = 'space_page_view';
        $data['title'] = esc_html($page->title) . ' - ' . $data['title'];
        $data['og_title'] = esc_html($page->title);
        $data['canonical_url'] = $page->getPermalink();

        $description = Arr::get($page->meta, 'seo_description');

        if (!$description && $page->message) {
            $description = Helper::getHumanExcerpt($page->message, 160);
        }

        if ($description) {
            $data['description'] = esc_html($description);
        }

        if ($page->featured_image) {
            $data['featured_image'] = esc_url($page->featured_image);
        } elseif ($ogImage = Arr::get($space->settings, 'og_image')) {
            $data['featured_image'] = $ogImage;
        } elseif ($space->cover_photo) {
            $data['featured_image'] = $space->cover_photo;
        }

        return $data;
    }

    /**
     * @param BaseSpace $space
     * @return void
     */
    public function deleteSpacePages($space)
    {
        if (!$space || !$space->id) {
            return;
        }

        // One at a time: a builder delete skips model events, so the pages would take
        // their comment threads with them only on the per page path.
        $pages = SpacePageModel::where('space_id', $space->id)->get();

        foreach ($pages as $page) {
            $page->delete();
        }
    }
}
