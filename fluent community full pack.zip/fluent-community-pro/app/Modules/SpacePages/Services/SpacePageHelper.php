<?php

namespace FluentCommunityPro\App\Modules\SpacePages\Services;

use FluentCommunity\App\Functions\Utility;
use FluentCommunity\App\Models\BaseSpace;
use FluentCommunity\App\Models\User;
use FluentCommunity\App\Services\CustomSanitizer;
use FluentCommunity\App\Services\SmartCodeParser;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Modules\SpacePages\SpacePageModel;

class SpacePageHelper
{
    /**
     * Admins and moderators author pages.
     *
     * @param BaseSpace|null $space
     * @param int|null $userId
     * @return bool
     */
    public static function canManagePages($space, $userId = null)
    {
        if (!$space) {
            return false;
        }

        if ($userId === null) {
            $userId = get_current_user_id();
        }

        if (!$userId) {
            return false;
        }

        return $space->isAdmin($userId, true);
    }

    /**
     * @param SpacePageModel $page
     * @param BaseSpace $space
     * @param User|null $user
     * @return bool
     */
    public static function canViewPage($page, $space, $user = null)
    {
        $canView = static::resolveViewAccess($page, $space, $user);

        return apply_filters('fluent_community/space_page/can_view_page', $canView, $page, $space, $user);
    }

    protected static function resolveViewAccess($page, $space, $user)
    {
        if (!$page || !$space) {
            return false;
        }

        $userId = $user ? $user->ID : null;

        // Admins and moderators see everything, including drafts.
        if ($userId && $space->isAdmin($userId, true)) {
            return true;
        }

        if ($page->status !== 'published') {
            return false;
        }

        // The space itself must be viewable before any page inside it is.
        // can_view_posts is the one key present in every permission branch, including
        // getPublicPermissions() for logged out visitors.
        if (!static::canViewSpaceContent($space, $user)) {
            return false;
        }

        if ($page->privacy === 'members_only') {
            if (!$userId) {
                return false;
            }

            $membership = $space->getMembership($userId);

            return $membership && isset($membership->pivot) && $membership->pivot->status === 'active';
        }

        return true;
    }

    /**
     * Baseline "may this viewer see content inside this space at all".
     *
     * @param \FluentCommunity\App\Models\BaseSpace $space
     * @param User|null $user
     * @return bool
     */
    public static function canViewSpaceContent($space, $user = null)
    {
        $permissions = $space->getUserPermissions($user);

        return (bool)Arr::get($permissions, 'can_view_posts', false);
    }

    /**
     * Block markup is rendered on read, exactly like a course lesson. message_rendered
     * is intentionally left NULL — always read through this method, never the column.
     *
     * @param SpacePageModel $page
     * @param User|null $user
     * @param array $config
     * @return array
     */
    public static function formatPageData($page, $user = null, $config = [])
    {
        $canView = Arr::get($config, 'can_view', false);
        $parseContent = Arr::get($config, 'parse_content', true);

        $content = '';
        $inlineCss = '';

        if ($canView && $parseContent) {
            $content = $page->message_rendered;

            if (!$content && $page->message) {
                $content = apply_filters('the_content', $page->message); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound

                if (function_exists('wp_style_engine_get_stylesheet_from_context')) {
                    $inlineCss = wp_style_engine_get_stylesheet_from_context('block-supports', []);
                }
            }

            if (!$content) {
                $content = '';
            }

            $content = (new SmartCodeParser())->parse($content, $user);
        }

        /*
         * The comment thread needs both of these and neither is decoration.
         *
         * CommentBox gates its composer on hasCommentPermission(feed) (src/app.js), which
         * for a row carrying a space_id resolves hasSpaceAccess(feed.space?.slug). That
         * helper short circuits to TRUE on a falsy slug, so without `space` the client
         * check silently passed for everyone - a non member got a composer, wrote a
         * comment, and only then hit the server's can_comment refusal. Sending the space
         * is what makes the client gate agree with FeedsHelper::commentsEnabled() and the
         * space permission check behind it. `type` keys the fcom_comment_box_{type} class
         * the same component writes.
         *
         * The relation is already resolved by getPermalink() below, so this costs no
         * extra query on the read path.
         */
        $space = $page->space;

        $formatted = [
            'id'             => $page->id,
            'type'           => $page->type,
            'title'          => $page->title,
            'slug'           => $page->slug,
            'content'        => $content,
            'space_id'       => $page->space_id,
            'space'          => $space ? [
                'id'    => $space->id,
                'slug'  => $space->slug,
                'title' => $space->title,
            ] : null,
            'status'         => $page->status,
            'privacy'        => $page->privacy,
            'priority'       => $page->priority,
            'featured_image' => $page->featured_image,
            'meta'           => $page->meta,
            'comments_count' => $page->comments_count,
            'can_view'       => $canView,
            'inline_css'     => $inlineCss,
            'permalink'      => $page->getPermalink(),
            'created_at'     => $page->created_at ? $page->created_at->format('Y-m-d H:i:s') : '',
            'updated_at'     => $page->updated_at ? $page->updated_at->format('Y-m-d H:i:s') : '',
        ];

        if (!$canView) {
            $formatted['access_message'] = static::getAccessMessage($page);
        }

        return apply_filters('fluent_community/space_page/formatted_page', $formatted, $page, $user);
    }

    /**
     * The shape the pages manager lists a row in.
     *
     * A superset of what a viewer needs, and deliberately not formatPageData(): the
     * manager has to answer "is this page finished, who wrote it and how does it
     * render" without opening the editor, while a reader gets none of that and should
     * not pay for the author lookup on every page view.
     *
     * Callers listing more than one page must eager load `xprofile`, or the byline is
     * an N+1.
     *
     * @param SpacePageModel $page
     * @return array
     */
    public static function formatManagerRow($page)
    {
        $meta = (array)$page->meta;
        $layouts = static::getLayoutTemplates();
        $layoutKey = (string)Arr::get($meta, 'layout');

        $row = [
            'id'             => $page->id,
            'title'          => $page->title,
            'slug'           => $page->slug,
            'status'         => $page->status,
            'privacy'        => $page->privacy,
            'priority'       => $page->priority,
            'featured_image' => $page->featured_image,
            'meta'           => $meta,
            'permalink'      => $page->getPermalink(),
            'comments_count' => $page->comments_count,
            'layout_label'   => Arr::get($layouts, $layoutKey . '.label', $layoutKey),
            'word_count'     => static::countWords($page->message),
            'author'         => static::formatAuthor($page),
            'created_at'     => $page->created_at ? $page->created_at->format('Y-m-d H:i:s') : '',
            'updated_at'     => $page->updated_at ? $page->updated_at->format('Y-m-d H:i:s') : '',
        ];

        return apply_filters('fluent_community/space_page/manager_row', $row, $page);
    }

    /**
     * @param SpacePageModel $page
     * @return array|null
     */
    protected static function formatAuthor($page)
    {
        if (!$page->user_id) {
            return null;
        }

        $xprofile = $page->xprofile;

        if (!$xprofile) {
            return null;
        }

        return [
            'id'     => (int)$xprofile->user_id,
            'name'   => $xprofile->display_name,
            'avatar' => $xprofile->avatar,
        ];
    }

    /**
     * Rough length of a page, so the manager can tell a stub from a finished page.
     *
     * strip_tags also drops the `<!-- wp:* -->` block delimiters, which are HTML
     * comments. preg_split rather than str_word_count(), which only counts Latin
     * letters and answers 0 for a page written in any other script.
     *
     * @param string|null $body
     * @return int
     */
    protected static function countWords($body)
    {
        $text = trim(wp_strip_all_tags(strip_shortcodes((string)$body)));

        if (!$text) {
            return 0;
        }

        $words = preg_split('/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY);

        return $words ? count($words) : 0;
    }

    public static function getAccessMessage($page)
    {
        $message = '<p>' . esc_html__('You do not have access to view this page.', 'fluent-community-pro') . '</p>';

        return apply_filters('fluent_community/space_page/access_message_html', $message, $page);
    }

    public static function santizePageBody($body)
    {
        return CustomSanitizer::santizeEditorBody((string)$body);
    }

    public static function getValidStatuses()
    {
        return ['draft', 'published'];
    }

    public static function getValidPrivacies()
    {
        return ['public', 'members_only'];
    }

    /**
     * The layout templates a page can be rendered with.
     *
     * Three of the four differ on two axes an author can learn at a glance: how wide the
     * page is (the full space container, as the Members and Documents tabs use, or a
     * single post's column) and whether the content sits in a card. Unified is the odd
     * one out on purpose - it drops the card idea entirely and turns the whole content
     * area into one surface, the way a course lesson reads.
     *
     * Every template renders inside the normal space shell - the space name, the tab bar
     * and the sub links all stay put. Nothing here hides them.
     *
     * This is the single source of truth: sanitizeMeta() clamps against these keys and
     * SpacePagesModule::handleEditorContext() ships the same list to the Gutenberg
     * sidebar as fcomEditorVars.page_layouts, so a filter-registered template shows up
     * in the picker and survives a save without touching the JS. The front end owns the
     * actual CSS, keyed by the body class fcom_page_layout_{key} (see
     * src/StyleParts/_SpacePages.scss in the free plugin), so a third party registering
     * a key must also ship that CSS.
     *
     * @return array<string, array>
     */
    public static function getLayoutTemplates()
    {
        // Order is the order of the picker, and the first one is what a new page gets.
        $templates = [
            'unified'    => [
                'label'       => __('Unified', 'fluent-community-pro'),
                'description' => __('One surface filling the whole area, read like a course lesson. No box.', 'fluent-community-pro'),
            ],
            'standard'   => [
                'label'       => __('Standard', 'fluent-community-pro'),
                'description' => __('A card across the full width of the space, like the Members and Documents tabs.', 'fluent-community-pro'),
            ],
            'classic'    => [
                'label'       => __('Classic', 'fluent-community-pro'),
                'description' => __('Reads like a normal post: a card the width of a feed post, with the space sidebar beside it.', 'fluent-community-pro'),
            ],
            'full_width' => [
                'label'       => __('Full Width', 'fluent-community-pro'),
                'description' => __('No card. Full width blocks design the page edge to edge.', 'fluent-community-pro'),
            ],
        ];

        return apply_filters('fluent_community/space_page/layout_templates', $templates);
    }

    /**
     * @param array $meta
     * @return array
     */
    public static function sanitizeMeta($meta)
    {
        $meta = (array)$meta;

        return [
            'show_in_nav'     => Arr::get($meta, 'show_in_nav') === 'yes' ? 'yes' : 'no',
            'nav_label'       => sanitize_text_field((string)Arr::get($meta, 'nav_label', '')),
            'emoji'           => CustomSanitizer::sanitizeEmoji((string)Arr::get($meta, 'emoji', '')),
            'enable_comments' => Arr::get($meta, 'enable_comments') === 'yes' ? 'yes' : 'no',
            'seo_description' => sanitize_textarea_field((string)Arr::get($meta, 'seo_description', '')),
            // The attachment picked in the editor's Featured Image panel. The
            // featured_image column stays the canonical URL; see
            // SpacePageController::update(), which resolves one from the other.
            'featured_image_id' => (int)Arr::get($meta, 'featured_image_id', 0),
            // The template settles width and the card. The title and the featured image
            // are independent of it, because wanting a full width page without a big
            // heading on it has nothing to do with wanting a card.
            //
            // This is the only write path, so an out of enum value can never reach the
            // DOM as a class name.
            'layout'              => static::enumValue(static::aliasLayout(Arr::get($meta, 'layout')), array_keys(static::getLayoutTemplates()), Arr::get(SpacePageModel::getDefaultMeta(), 'layout')),
            'show_title'          => Arr::get($meta, 'show_title') === 'no' ? 'no' : 'yes',
            // Opt in, unlike show_title: most pages set a featured image for the link
            // preview and the card in the manager, not to print it across the page.
            'show_featured_image' => Arr::get($meta, 'show_featured_image') === 'yes' ? 'yes' : 'no',
        ];
    }

    /**
     * Renamed template keys, so a page authored against an earlier build keeps its look
     * instead of silently falling back to the default.
     *
     * @param mixed $value
     * @return mixed
     */
    protected static function aliasLayout($value)
    {
        $aliases = [
            'narrow' => 'classic',
        ];

        return is_string($value) && isset($aliases[$value]) ? $aliases[$value] : $value;
    }

    /**
     * @param mixed $value
     * @param array $allowed
     * @param string $fallback
     * @return string
     */
    protected static function enumValue($value, $allowed, $fallback)
    {
        $value = sanitize_key((string)$value);

        return in_array($value, $allowed, true) ? $value : $fallback;
    }

    /**
     * Resolve a community space by slug. Courses are excluded - they have no page
     * viewer route in the portal yet.
     *
     * @param string $slug
     * @return BaseSpace|null
     */
    public static function getSpaceBySlug($slug)
    {
        return BaseSpace::withoutGlobalScopes()
            ->where('type', 'community')
            ->where('slug', $slug)
            ->first();
    }

    /**
     * A page slug only has to be unique among the pages of one space.
     *
     * A page is read at space/{spaceSlug}/page/{pageSlug} and
     * SpacePageController::show() looks it up with a space_id filter, so "rules" in
     * one space and "rules" in another never compete. Community wide pages
     * (space_id NULL, reserved) form their own scope.
     *
     * Other row types in the shared fcom_posts table are none of our business: a
     * feed lives at space/{spaceSlug}/post/{slug} and a lesson at
     * course/{courseSlug}/lessons/{slug}, and every lookup on those routes filters
     * by type - including the SEO ones in PortalHandler::maybePushDynamicMetaData(),
     * which narrows to Feed::$feedViewTypes. A page and a post may share a slug.
     *
     * @param string $slug
     * @param int|null $ignoreId
     * @param int|null $spaceId
     * @return bool
     */
    public static function slugExists($slug, $ignoreId = null, $spaceId = null)
    {
        $query = SpacePageModel::where('slug', $slug);

        if ($spaceId) {
            $query->where('space_id', $spaceId);
        } else {
            $query->whereNull('space_id');
        }

        if ($ignoreId) {
            $query->where('id', '!=', $ignoreId);
        }

        return $query->exists();
    }

    /**
     * @param string $slug
     * @param string $fallbackTitle
     * @param int|null $ignoreId
     * @param int|null $spaceId the space the page belongs to, see slugExists()
     * @return string
     */
    public static function uniqueSlug($slug, $fallbackTitle = '', $ignoreId = null, $spaceId = null)
    {
        $slug = sanitize_title($slug);

        if (!$slug) {
            $slug = Utility::slugify($fallbackTitle, 'page-' . time());
        }

        if (static::slugExists($slug, $ignoreId, $spaceId)) {
            $slug = $slug . '-' . time();
        }

        return $slug;
    }

    /**
     * formatSpaceData() runs for every space a user belongs to on portal bootstrap, and
     * again for every space in every group in getSpaceGroups(), so the result is held for
     * the request and each space is read at most once.
     *
     * Read per space rather than site wide: `space_id > 0` is a range on the leading
     * column of idx_space_id_status, so a site wide read uses no index at all and scans
     * fcom_posts - a table that is mostly feeds - on every portal request.
     *
     * @param int $spaceId
     * @return array
     */
    public static function getNavPages($spaceId)
    {
        static $bySpace = [];

        $spaceId = (int)$spaceId;

        if ($spaceId <= 0) {
            return [];
        }

        if (isset($bySpace[$spaceId])) {
            return $bySpace[$spaceId];
        }

        $limit = (int)apply_filters('fluent_community/space_page/nav_query_limit', 1000);

        $bySpace[$spaceId] = SpacePageModel::published()
            ->where('space_id', $spaceId)
            ->ordered()
            ->select(['id', 'title', 'slug', 'privacy', 'status', 'priority', 'meta', 'space_id'])
            ->limit($limit)
            ->get()
            ->all();

        return $bySpace[$spaceId];
    }

    /**
     * Nav links for one space. Space level access is resolved once rather than per page,
     * so this stays free of per-page membership lookups.
     *
     * @param \FluentCommunity\App\Models\BaseSpace $space
     * @param User|null $user
     * @return array
     */
    public static function getViewableNavPages($space, $user = null)
    {
        $pages = static::getNavPages($space->id);

        if (!$pages) {
            return [];
        }

        $userId = $user ? $user->ID : null;
        $isManager = $userId && $space->isAdmin($userId, true);

        if (!$isManager && !static::canViewSpaceContent($space, $user)) {
            return [];
        }

        $membershipActive = null;
        $visible = [];

        foreach ($pages as $page) {
            if (Arr::get($page->meta, 'show_in_nav') !== 'yes') {
                continue;
            }

            if (!$isManager && $page->privacy === 'members_only') {
                if ($membershipActive === null) {
                    $membership = $userId ? $space->getMembership($userId) : null;
                    $membershipActive = $membership && isset($membership->pivot) && $membership->pivot->status === 'active';
                }

                if (!$membershipActive) {
                    continue;
                }
            }

            $visible[] = $page;
        }

        return $visible;
    }
}
