<?php

namespace FluentCommunityPro\App\Modules\SpacePages\Http\Controllers;

use FluentCommunity\App\Http\Controllers\Controller;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Modules\SpacePages\Services\SpacePageHelper;
use FluentCommunityPro\App\Modules\SpacePages\SpacePageModel;

class SpacePageController extends Controller
{
    /**
     * Manager listing. Includes drafts, admins/moderators only.
     */
    public function index(Request $request, $spaceSlug)
    {
        $space = SpacePageHelper::getSpaceBySlug($spaceSlug);

        if (!$space) {
            return $this->sendError([
                'message' => __('Space not found', 'fluent-community-pro')
            ], 404);
        }

        // xprofile for the byline, space for getPermalink() - both are read per row by
        // formatManagerRow(), and the space one was a query per page.
        $pages = SpacePageModel::where('space_id', $space->id)
            ->with(['xprofile', 'space'])
            ->ordered()
            ->get();

        $formatted = [];
        foreach ($pages as $page) {
            $formatted[] = SpacePageHelper::formatManagerRow($page);
        }

        return [
            'pages'    => $formatted,
            'space_id' => $space->id,
        ];
    }

    /**
     * Member facing read. Applies the access gate.
     */
    public function show(Request $request, $spaceSlug, $pageSlug)
    {
        $space = SpacePageHelper::getSpaceBySlug($spaceSlug);

        if (!$space) {
            return $this->sendError([
                'message' => __('Page not found', 'fluent-community-pro')
            ], 404);
        }

        $page = SpacePageModel::where('space_id', $space->id)
            ->where('slug', $pageSlug)
            ->first();

        if (!$page) {
            return $this->sendError([
                'message' => __('Page not found', 'fluent-community-pro')
            ], 404);
        }

        $user = $this->getUser(false);

        $canView = SpacePageHelper::canViewPage($page, $space, $user);

        // A page the viewer may not even know exists should not confirm its existence.
        if (!$canView && $page->status !== 'published') {
            return $this->sendError([
                'message' => __('Page not found', 'fluent-community-pro')
            ], 404);
        }

        $formatted = SpacePageHelper::formatPageData($page, $user, [
            'can_view'      => $canView,
            'parse_content' => true,
        ]);

        // The editor needs the raw block markup; never expose it to a plain viewer.
        if (SpacePageHelper::canManagePages($space)) {
            $formatted['message'] = $page->message;
        }

        return [
            'page' => $formatted
        ];
    }

    public function store(Request $request, $spaceSlug)
    {
        $space = SpacePageHelper::getSpaceBySlug($spaceSlug);

        if (!$space) {
            return $this->sendError([
                'message' => __('Space not found', 'fluent-community-pro')
            ], 404);
        }

        $title = sanitize_text_field((string)$request->get('title', ''));

        if (!$title) {
            return $this->sendError([
                'message' => __('Page title is required', 'fluent-community-pro')
            ], 422);
        }

        $maxPriority = SpacePageModel::where('space_id', $space->id)->max('priority');

        $page = SpacePageModel::create([
            'title'    => $title,
            'space_id' => $space->id,
            'status'   => 'draft',
            'privacy'  => 'public',
            'priority' => (int)$maxPriority + 1,
            'message'  => '',
            'meta'     => SpacePageModel::getDefaultMeta(),
        ]);

        do_action('fluent_community/space_page/created', $page, $space);

        return [
            'message' => __('Page has been created', 'fluent-community-pro'),
            'page'    => SpacePageHelper::formatManagerRow($page)
        ];
    }

    public function update(Request $request, $spaceSlug, $pageId)
    {
        $space = SpacePageHelper::getSpaceBySlug($spaceSlug);

        if (!$space) {
            return $this->sendError([
                'message' => __('Space not found', 'fluent-community-pro')
            ], 404);
        }

        $page = SpacePageModel::where('space_id', $space->id)->where('id', $pageId)->first();

        if (!$page) {
            return $this->sendError([
                'message' => __('Page not found', 'fluent-community-pro')
            ], 404);
        }

        $data = $request->get('page', []);

        if (!is_array($data)) {
            $data = [];
        }

        $updateData = [];

        if (array_key_exists('title', $data)) {
            $title = sanitize_text_field((string)Arr::get($data, 'title', ''));
            if (!$title) {
                return $this->sendError([
                    'message' => __('Page title is required', 'fluent-community-pro')
                ], 422);
            }
            $updateData['title'] = $title;
        }

        if (array_key_exists('message', $data)) {
            $updateData['message'] = SpacePageHelper::santizePageBody(Arr::get($data, 'message', ''));
        }

        if (array_key_exists('slug', $data)) {
            $updateData['slug'] = SpacePageHelper::uniqueSlug(
                (string)Arr::get($data, 'slug', ''),
                Arr::get($updateData, 'title', $page->title),
                $page->id,
                $page->space_id
            );
        }

        if (array_key_exists('status', $data)) {
            $status = Arr::get($data, 'status');
            $updateData['status'] = in_array($status, SpacePageHelper::getValidStatuses(), true) ? $status : 'draft';
        }

        if (array_key_exists('privacy', $data)) {
            $privacy = Arr::get($data, 'privacy');
            $updateData['privacy'] = in_array($privacy, SpacePageHelper::getValidPrivacies(), true) ? $privacy : 'public';
        }

        if (array_key_exists('featured_image', $data)) {
            $updateData['featured_image'] = sanitize_url((string)Arr::get($data, 'featured_image', ''));
        }

        if (array_key_exists('meta', $data)) {
            $updateData['meta'] = SpacePageHelper::sanitizeMeta(Arr::get($data, 'meta', []));

            /*
             * The editor sets the featured image through Gutenberg's own panel, which
             * yields an attachment id. featured_image stays the canonical URL that
             * rendering, SEO and the sitemap read, so derive one from the other.
             *
             * Pages authored before the panel existed hold a bare URL and no id -
             * leave those alone rather than clearing an image the editor never
             * showed. Only an id that was there and is now gone means "removed".
             */
            if (!array_key_exists('featured_image', $data)) {
                $newMediaId = (int)Arr::get($updateData['meta'], 'featured_image_id');
                $oldMediaId = (int)Arr::get((array)$page->meta, 'featured_image_id');

                if ($newMediaId) {
                    $mediaUrl = wp_get_attachment_url($newMediaId);
                    $updateData['featured_image'] = $mediaUrl ? sanitize_url($mediaUrl) : '';
                } elseif ($oldMediaId) {
                    $updateData['featured_image'] = '';
                }
            }
        }

        if (!$updateData) {
            return [
                'message' => __('Nothing to update', 'fluent-community-pro'),
                'page'    => $this->formatSavedPage($page)
            ];
        }

        $updateData = apply_filters('fluent_community/space_page/update_data', $updateData, $page, $request->all());

        $page->fill($updateData);
        $page->save();

        do_action('fluent_community/space_page/updated', $page, $space);

        return [
            'message' => __('Page has been updated', 'fluent-community-pro'),
            'page'    => $this->formatSavedPage($page->fresh())
        ];
    }

    public function destroy(Request $request, $spaceSlug, $pageId)
    {
        $space = SpacePageHelper::getSpaceBySlug($spaceSlug);

        if (!$space) {
            return $this->sendError([
                'message' => __('Space not found', 'fluent-community-pro')
            ], 404);
        }

        $page = SpacePageModel::where('space_id', $space->id)->where('id', $pageId)->first();

        if (!$page) {
            return $this->sendError([
                'message' => __('Page not found', 'fluent-community-pro')
            ], 404);
        }

        do_action('fluent_community/space_page/before_delete', $page, $space);

        $page->delete();

        return [
            'message' => __('Page has been deleted', 'fluent-community-pro')
        ];
    }

    /**
     * Copy a page, body and settings included, as a fresh draft.
     *
     * The copy is always a draft and always out of the nav, whatever the original was:
     * a duplicate is a starting point, and publishing one into the tab bar the moment
     * it is made is never what was meant.
     */
    public function duplicate(Request $request, $spaceSlug, $pageId)
    {
        $space = SpacePageHelper::getSpaceBySlug($spaceSlug);

        if (!$space) {
            return $this->sendError([
                'message' => __('Space not found', 'fluent-community-pro')
            ], 404);
        }

        $page = SpacePageModel::where('space_id', $space->id)->where('id', $pageId)->first();

        if (!$page) {
            return $this->sendError([
                'message' => __('Page not found', 'fluent-community-pro')
            ], 404);
        }

        $meta = SpacePageHelper::sanitizeMeta((array)$page->meta);
        $meta['show_in_nav'] = 'no';

        $maxPriority = SpacePageModel::where('space_id', $space->id)->max('priority');

        /* translators: %s is the title of the page being copied */
        $title = sprintf(__('%s (Copy)', 'fluent-community-pro'), $page->title);

        // The slug is left empty on purpose - SpacePageModel::generateNewSlug() derives
        // it from the title through the same uniqueness rule every other write uses.
        $copy = SpacePageModel::create([
            'title'          => sanitize_text_field($title),
            'space_id'       => $space->id,
            'status'         => 'draft',
            'privacy'        => $page->privacy,
            'priority'       => (int)$maxPriority + 1,
            'message'        => $page->message,
            'featured_image' => $page->featured_image,
            'meta'           => $meta,
        ]);

        do_action('fluent_community/space_page/created', $copy, $space);
        do_action('fluent_community/space_page/duplicated', $copy, $page, $space);

        return [
            'message' => __('Page has been duplicated', 'fluent-community-pro'),
            'page'    => SpacePageHelper::formatManagerRow($copy)
        ];
    }

    /**
     * What a write answers with: the editor needs the rendered content and the manager
     * listing needs the byline, the length and the template label, and one save updates
     * both. The manager keys are layered on top because the two formatters agree on
     * every field they share.
     *
     * @param SpacePageModel $page
     * @return array
     */
    protected function formatSavedPage($page)
    {
        return array_merge(
            SpacePageHelper::formatPageData($page, $this->getUser(false), ['can_view' => true]),
            SpacePageHelper::formatManagerRow($page)
        );
    }

    public function reIndex(Request $request, $spaceSlug)
    {
        $space = SpacePageHelper::getSpaceBySlug($spaceSlug);

        if (!$space) {
            return $this->sendError([
                'message' => __('Space not found', 'fluent-community-pro')
            ], 404);
        }

        $pageIds = (array)$request->get('page_ids', []);
        $pageIds = array_filter(array_map('intval', $pageIds));

        if (!$pageIds) {
            return $this->sendError([
                'message' => __('No pages provided to sort', 'fluent-community-pro')
            ], 422);
        }

        // Only reorder rows that actually belong to this space.
        $ownedIds = SpacePageModel::where('space_id', $space->id)
            ->whereIn('id', $pageIds)
            ->pluck('id')
            ->toArray();

        $priority = 1;
        foreach ($pageIds as $pageId) {
            if (!in_array($pageId, $ownedIds)) {
                continue;
            }

            SpacePageModel::where('id', $pageId)->update([
                'priority' => $priority
            ]);

            $priority++;
        }

        return [
            'message' => __('Pages have been sorted', 'fluent-community-pro')
        ];
    }
}
