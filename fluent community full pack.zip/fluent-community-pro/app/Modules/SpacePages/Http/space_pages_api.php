<?php

/**
 * @var $router FluentCommunity\Framework\Http\Router
 */

use FluentCommunityPro\App\Http\Policies\SpacePagePolicy;
use FluentCommunityPro\App\Modules\SpacePages\Http\Controllers\SpacePageController;

$router->prefix('spaces')->withPolicy(SpacePagePolicy::class)->group(function ($router) {
    $router->get('/{spaceSlug}/pages', [SpacePageController::class, 'index'])
        ->alphaNumDash('spaceSlug');

    $router->post('/{spaceSlug}/pages', [SpacePageController::class, 'store'])
        ->alphaNumDash('spaceSlug');

    $router->patch('/{spaceSlug}/pages/re-index', [SpacePageController::class, 'reIndex'])
        ->alphaNumDash('spaceSlug');

    $router->get('/{spaceSlug}/pages/{pageSlug}', [SpacePageController::class, 'show'])
        ->alphaNumDash('spaceSlug')
        ->alphaNumDash('pageSlug');

    $router->post('/{spaceSlug}/pages/{pageId}/duplicate', [SpacePageController::class, 'duplicate'])
        ->alphaNumDash('spaceSlug')
        ->int('pageId');

    $router->put('/{spaceSlug}/pages/{pageId}', [SpacePageController::class, 'update'])
        ->alphaNumDash('spaceSlug')
        ->int('pageId');

    $router->delete('/{spaceSlug}/pages/{pageId}', [SpacePageController::class, 'destroy'])
        ->alphaNumDash('spaceSlug')
        ->int('pageId');
});
