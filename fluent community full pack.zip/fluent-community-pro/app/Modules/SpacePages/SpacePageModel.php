<?php

namespace FluentCommunityPro\App\Modules\SpacePages;

use FluentCommunity\App\Functions\Utility;
use FluentCommunity\App\Models\BaseSpace;
use FluentCommunity\App\Models\Comment;
use FluentCommunity\App\Models\XProfile;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Models\Model;
use FluentCommunityPro\App\Modules\SpacePages\Services\SpacePageHelper;

/**
 *  Space Page Model - DB Model for a static, admin authored page inside a Space
 *
 *  Stored in the shared fcom_posts table, discriminated by type = 'space_page'.
 *
 * @package FluentCommunityPro\App\Modules\SpacePages
 *
 * @property int         $id
 * @property int|null    $user_id
 * @property string|null $title
 * @property string|null $slug
 * @property string|null $message
 * @property string|null $message_rendered
 * @property string|null $type
 * @property int|null    $space_id
 * @property string|null $privacy
 * @property string|null $status
 * @property string|null $featured_image
 * @property string|null $content_type
 * @property int         $comments_count
 * @property array       $meta
 * @property int|null    $priority
 * @property int|null    $parent_id
 * @property string|null $created_at
 * @property string|null $updated_at
 */
class SpacePageModel extends Model
{
    protected $table = 'fcom_posts';

    protected $guarded = ['id'];

    protected $casts = [
        'comments_count' => 'int',
        'priority'       => 'int',
    ];

    protected $fillable = [
        'user_id',
        'title',
        'slug',
        'message',
        'message_rendered',
        'type',
        'space_id',
        'privacy',
        'status',
        'featured_image',
        'content_type',
        'comments_count',
        'meta',
        'priority',
        'parent_id',
    ];

    protected $searchable = [
        'title',
        'message',
    ];

    protected static $type = 'space_page';

    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->user_id)) {
                $model->user_id = get_current_user_id();
            }

            if (empty($model->slug)) {
                $model->slug = self::generateNewSlug($model);
            }

            $model->type = self::$type;

            if (empty($model->content_type)) {
                $model->content_type = 'text';
            }

            if (empty($model->status)) {
                $model->status = 'draft';
            }

            if (empty($model->privacy)) {
                $model->privacy = 'public';
            }

            if (empty($model->message)) {
                $model->message = '';
            }

            if (empty($model->meta)) {
                $model->meta = self::getDefaultMeta();
            }
        });

        // fcom_post_comments has no cascading key, so a deleted page would leave its
        // thread behind. Deleted one model at a time so each comment's own cleanup
        // (replies, reactions, media, activity, notifications) runs.
        static::deleting(function ($page) {
            $comments = Comment::where('post_id', $page->id)->get();

            foreach ($comments as $comment) {
                $comment->delete();
            }
        });

        static::addGlobalScope('type', function ($builder) {
            $builder->where('type', self::$type);
        });
    }

    /**
     * Also the read fallback - the meta accessor runs wp_parse_args against this - so a
     * page written before a key existed answers with the default rather than nothing.
     *
     * A new page is Unified: no card at all, the content area itself is the surface and
     * the page reads like a course lesson. Every other template puts the content in a box,
     * and a box is what a feed post is - looking like a post is the thing a page should
     * not do by default.
     *
     * The featured image is off to match. It is set for the link preview and the card in
     * the pages manager far more often than to be printed across the top of the page, so
     * printing it is the opt in.
     *
     * @return array
     */
    public static function getDefaultMeta()
    {
        return [
            'show_in_nav'         => 'yes',
            'nav_label'           => '',
            'emoji'               => '',
            'enable_comments'     => 'no',
            'seo_description'     => '',
            'layout'              => 'unified',
            'show_title'          => 'yes',
            'show_featured_image' => 'no',
        ];
    }

    /**
     * One rule for generated and author supplied slugs alike - see
     * SpacePageHelper::slugExists() for what "unique" means and why the scope
     * differs per collision type.
     *
     * @param SpacePageModel $newModel
     * @return string
     */
    protected static function generateNewSlug($newModel)
    {
        return SpacePageHelper::uniqueSlug(
            '',
            $newModel->title,
            null,
            $newModel->space_id
        );
    }

    public function space()
    {
        return $this->belongsTo(BaseSpace::class, 'space_id', 'id');
    }

    /**
     * The author, for the byline in the pages manager. Eager load it - the listing
     * renders one row per page and a lazy relation would be an N+1.
     */
    public function xprofile()
    {
        return $this->belongsTo(XProfile::class, 'user_id', 'user_id');
    }

    public function setMetaAttribute($value)
    {
        $this->attributes['meta'] = maybe_serialize($value);
    }

    public function getMetaAttribute($value)
    {
        $meta = Utility::safeUnserialize($value);

        if (!$meta || !is_array($meta)) {
            $meta = [];
        }

        return wp_parse_args($meta, self::getDefaultMeta());
    }

    public function getPermalink()
    {
        if (!$this->space_id) {
            return Helper::baseUrl('page/' . $this->slug);
        }

        $space = $this->space;

        if (!$space) {
            return Helper::baseUrl('/');
        }

        $prefix = $space->type === 'course' ? 'course/' : 'space/';

        return Helper::baseUrl($prefix . $space->slug . '/page/' . $this->slug);
    }

    public function getNavLabel()
    {
        return Arr::get($this->meta, 'nav_label') ?: $this->title;
    }

    public function isCommentsEnabled()
    {
        return Arr::get($this->meta, 'enable_comments') === 'yes';
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('priority', 'ASC')->orderBy('id', 'ASC');
    }

    public function scopePublished($query)
    {
        return $query->where('status', 'published');
    }
}
