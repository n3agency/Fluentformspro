<?php

namespace FluentCommunityPro\App\Modules\Quiz;

use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Models\Model;
use FluentCommunity\App\Models\User;
use FluentCommunity\App\Models\XProfile;
use FluentCommunity\Modules\Course\Model\CourseLesson;

class QuizModel extends Model
{
    protected $table = 'fcom_post_comments';

    protected $guarded = ['id'];

    protected $fillable = [
        'user_id',
        'post_id',
        'parent_id',
        'meta',
        'type',
        'score',
        'status',
        'message',
        'content_type',
        'created_at',
        'updated_at'
    ];

    protected $attributeMap = [
        'score'   => 'reactions_count'
    ];

    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->type = 'quiz';
            $model->content_type = 'quiz';
            if (empty($model->status)) {
                $model->status = 'published';
            }
        });

        static::addGlobalScope('type', function ($builder) {
            $builder->where('type', 'quiz');
        });

        static::addGlobalScope('defaultSelect', function ($builder) {
            $builder->select([
                'id',
                'user_id',
                'post_id',
                'parent_id',
                'meta',
                'type',
                'status',
                'content_type',
                'message',
                'reactions_count as score',
                'updated_at'
            ]);
        });
    }

    public function getAttribute($key)
    {
        if (array_key_exists($key, $this->attributeMap)) {
            if (array_key_exists($key, $this->attributes)) {
                return parent::getAttribute($key);
            }
            return parent::getAttribute($this->attributeMap[$key]);
        }

        return parent::getAttribute($key);
    }

    public function setAttribute($key, $value)
    {
        if (array_key_exists($key, $this->attributeMap)) {
            return parent::setAttribute($this->attributeMap[$key], $value);
        }

        return parent::setAttribute($key, $value);
    }

    public function setMetaAttribute($value)
    {
        $this->attributes['meta'] = \maybe_serialize($value);
    }

    public function getMetaAttribute($value)
    {
        return \maybe_unserialize($value);
    }

    public function getMessageAttribute($value)
    {
        return \maybe_unserialize($value);
    }

    public function setMessageAttribute($value)
    {
        $this->attributes['message'] = \maybe_serialize($value);
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'ID');
    }

    public function xprofile()
    {
        return $this->belongsTo(XProfile::class, 'user_id', 'user_id');
    }

    public function lesson()
    {
        return $this->belongsTo(CourseLesson::class, 'post_id', 'id');
    }

    public function hideCorrectAnswers()
    {
        return array_map(function ($answer) {
            if (isset($answer['is_correct'])) {
                unset($answer['is_correct']);
            }
            return $answer;
        }, $this->message);
    }

    public static function isCorrectAnswer($question, $userAnswer)
    {
        $questionType = Arr::get($question, 'type');
        $questionOptions = Arr::get($question, 'options');

        if ($questionType === 'written_answer') {
            if (empty($userAnswer)) {
                return false;
            }
            $gradingMode = Arr::get($question, 'grading_mode', 'open');
            if ($gradingMode === 'exact_match') {
                $normalize = fn($s) => strtolower(trim((string) $s, " \t\n\r\0\x0B.,!?;:"));
                $normalizedUser = $normalize($userAnswer);
                foreach (Arr::get($question, 'correct_answers', []) as $accepted) {
                    if ($normalize($accepted) === $normalizedUser) {
                        return true;
                    }
                }
                return false;
            }
            return true;
        }

        if ($questionType === 'single_choice') {
            foreach ($questionOptions as $option) {
                if ($userAnswer == Arr::get($option, 'label') && Arr::isTrue($option, 'is_correct')) {
                    return true;
                }
            }
            return false;
        }

        if ($questionType === 'multiple_choice') {
            $correctLabels = [];
            foreach ($questionOptions as $option) {
                if (Arr::isTrue($option, 'is_correct')) {
                    $correctLabels[] = Arr::get($option, 'label');
                }
            }
            if (!is_array($userAnswer)) {
                return false;
            }

            // Set comparison, not a count plus a one-way diff. array_diff()
            // compares values and ignores multiplicity, so ['A','A'] diffed
            // against ['A','B'] came out empty while count() saw 2 == 2: a
            // student who knew one of two correct options could submit it twice
            // and be graded fully correct. Deduplicating first and diffing both
            // ways makes a missing selection and a repeated one both wrong.
            $userLabels = array_unique($userAnswer);

            return !array_diff($userLabels, $correctLabels)
                && !array_diff($correctLabels, $userLabels);
        }

        return false;
    }
}
