<?php

namespace FluentCommunityPro\App\Services;

use FluentCommunity\App\Functions\Utility;
use FluentCommunity\Framework\Support\Arr;

class ProfileFieldsService
{
    private static $config = null;

    public static function getDefaultConfig()
    {
        return [
            'is_enabled' => 'no',
            'groups'     => [],
            'fields'     => []
        ];
    }

    public static function getDefaultGroup()
    {
        return [
            'slug'             => '_additional_info',
            'label'            => __('Additional Information', 'fluent-community-pro'),
            'edit_description' => __('Fill in additional information about yourself.', 'fluent-community-pro'),
            'is_system'        => true,
        ];
    }

    public static function getConfig($force = false)
    {
        if (!empty(self::$config) && !$force) {
            return self::$config;
        }

        $config = Utility::getOption('custom_profile_fields', []);

        if (empty($config)) {
            $config = self::getDefaultConfig();
        }

        self::$config = $config;

        return $config;
    }

    public static function getFields()
    {
        return Arr::get(self::getConfig(), 'fields', []);
    }

    public static function getGroups()
    {
        return Arr::get(self::getConfig(), 'groups', []);
    }

    public static function getFieldTypes()
    {
        return apply_filters('fluent_community/custom_profile_field_types', [
            'text'        => __('Text', 'fluent-community-pro'),
            'textarea'    => __('Textarea', 'fluent-community-pro'),
            'number'      => __('Number', 'fluent-community-pro'),
            'date'        => __('Date', 'fluent-community-pro'),
            'select'      => __('Dropdown', 'fluent-community-pro'),
            'radio'       => __('Radio', 'fluent-community-pro'),
            'url'         => __('URL', 'fluent-community-pro'),
            'multiselect' => __('Multi Select', 'fluent-community-pro'),
        ]);
    }

    public static function sanitizeProfileFieldGroups($groups = [])
    {
        $usedSlugs = [];
        $formattedGroups = [];

        foreach ($groups as $group) {
            $label = sanitize_text_field(Arr::get($group, 'label', ''));
            if (!$label) {
                continue;
            }

            $slug = self::uniqueSlug(Arr::get($group, 'slug', '') ?: $label, $usedSlugs);

            $formattedGroups[] = [
                'slug'             => $slug,
                'label'            => $label,
                'edit_description' => sanitize_text_field(Arr::get($group, 'edit_description', '')),
                'is_system'        => $slug === '_additional_info',
            ];
        }

        if (!array_filter($formattedGroups, fn($g) => !empty($g['is_system']))) {
            array_unshift($formattedGroups, self::getDefaultGroup());
        }

        return $formattedGroups;
    }

    public static function sanitizeProfileFields($fields = [], $validGroupSlugs = [])
    {
        if (empty($fields) || empty($validGroupSlugs)) {
            return [];
        }

        $allowedTypes = array_keys(self::getFieldTypes());
        $allowedPrivacy = ['public', 'logged_in', 'internal', 'private'];
        $usedSlugs = [];
        $formattedFields = [];

        foreach ($fields as $field) {
            $label = sanitize_text_field(Arr::get($field, 'label', ''));
            if (!$label) {
                continue;
            }

            $slug = self::uniqueSlug(Arr::get($field, 'slug', '') ?: $label, $usedSlugs);
            $type = self::sanitizeEnum(Arr::get($field, 'type', 'text'), $allowedTypes, 'text');
            $privacy = self::sanitizeEnum(Arr::get($field, 'privacy', 'public'), $allowedPrivacy, 'public');

            $groupSlug = sanitize_text_field(Arr::get($field, 'group', ''));
            if (!in_array($groupSlug, $validGroupSlugs, true)) {
                $groupSlug = $validGroupSlugs[0];
            }

            $formattedFields[] = [
                'slug'        => $slug,
                'label'       => $label,
                'type'        => $type,
                'placeholder' => sanitize_text_field(Arr::get($field, 'placeholder', '')),
                'options'     => self::sanitizeOptions(Arr::get($field, 'options', []), $type),
                'is_required' => (bool) Arr::get($field, 'is_required', false),
                'is_enabled'  => (bool) Arr::get($field, 'is_enabled', true),
                'privacy'     => $privacy,
                'group'       => $groupSlug
            ];
        }

        return $formattedFields;
    }

    /**
     * Sanitize and validate user-submitted custom field values against field configs.
     *
     * @param array $fieldData
     * @param array $fields
     * @return array Sanitized values (empty values filtered out)
     * @throws \Exception if a required field is empty
     */
    public static function sanitizeAndValidateValues($fieldData, $fields)
    {
        $sanitized = [];

        foreach ($fields as $field) {
            $slug = Arr::get($field, 'slug');
            if (!$slug || !array_key_exists($slug, $fieldData)) {
                continue;
            }

            $value = self::sanitizeFieldValue(Arr::get($fieldData, $slug), $field);

            if (Arr::get($field, 'is_required', false) && empty($value)) {
                throw new \Exception(
                    sprintf(__('%s is required', 'fluent-community-pro'), Arr::get($field, 'label', $slug))
                );
            }

            $sanitized[$slug] = $value;
        }

        return $sanitized;
    }

    /**
     * Get fields accessible to the current viewer based on privacy settings.
     */
    public static function getAccessibleFields($isOwn, $isAdmin)
    {
        return array_filter(self::getFields(), function ($field) use ($isOwn, $isAdmin) {
            if (!Arr::get($field, 'is_enabled', true)) {
                return false;
            }

            if ($isAdmin) {
                return true;
            }

            return self::canViewField(Arr::get($field, 'privacy'), $isOwn);
        });
    }

    /**
     * Check if a viewer can see a field based on its privacy setting.
     */
    public static function canViewField($privacy, $isOwn)
    {
        switch ($privacy) {
            case 'public':
                return true;
            case 'logged_in':
                return !!get_current_user_id();
            case 'private':
                return $isOwn;
            case 'internal':
                return false;
            default:
                return false;
        }
    }

    public static function sanitizeFieldValue($value, $field)
    {
        $type = Arr::get($field, 'type', 'text');
        $options = Arr::get($field, 'options', []);

        if ($type === 'multiselect') {
            if (!is_array($value)) {
                return [];
            }

            $sanitized = [];
            foreach ($value as $val) {
                $sanitized[] = self::sanitizeChoiceValue($val, $options);
            }

            return $sanitized;
        }

        if (!is_scalar($value)) {
            return '';
        }

        $sanitizers = [
            'textarea' => fn($v) => sanitize_textarea_field($v),
            'number'   => fn($v) => is_numeric($v) ? floatval($v) : '',
            'url'      => fn($v) => sanitize_url($v),
            'date'     => function ($v) {
                $date = \DateTime::createFromFormat('Y-m-d', $v);
                return ($date && $date->format('Y-m-d') === $v) ? $v : '';
            },
            'select'   => fn($v) => self::sanitizeChoiceValue($v, $options),
            'radio'    => fn($v) => self::sanitizeChoiceValue($v, $options),
        ];

        $sanitizer = $sanitizers[$type] ?? fn($v) => sanitize_text_field($v);

        return $sanitizer($value);
    }

    private static function sanitizeChoiceValue($value, $options)
    {
        if (!is_array($options) || empty($options)) {
            return '';
        }

        $value = sanitize_text_field($value);

        if (!$value) {
            return '';
        }

        $isList = array_keys($options) === range(0, count($options) - 1);

        if ($isList ? !in_array($value, $options, true) : !array_key_exists($value, $options)) {
            return '';
        }

        return $value;
    }

    public static function migrateCustomFieldsToXProfile()
    {
        global $wpdb;

        $table = $wpdb->prefix . 'fcom_xprofile';

        $isMigrated = $wpdb->get_col($wpdb->prepare(
            "SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND COLUMN_NAME='custom_fields' AND TABLE_NAME=%s",
            $table
        ));

        if (!$isMigrated) {
            $safe_table = esc_sql($table);
            $wpdb->query("ALTER TABLE `{$safe_table}` ADD COLUMN `custom_fields` JSON NULL AFTER `meta`");
        }
    }

    private static function uniqueSlug($source, &$usedSlugs)
    {
        $slug = Utility::slugify($source);
        if (strpos($slug, '_') !== 0) {
            $slug = '_' . $slug;
        }

        $slug = substr($slug, 0, 25);
        $original = $slug;
        $counter = 1;

        while (in_array($slug, $usedSlugs, true)) {
            $suffix = '_' . $counter++;
            $slug = substr($original, 0, 25 - strlen($suffix)) . $suffix;
        }

        $usedSlugs[] = $slug;

        return $slug;
    }

    private static function sanitizeEnum($value, $allowed, $default)
    {
        $value = sanitize_text_field($value);

        return in_array($value, $allowed, true) ? $value : $default;
    }

    private static function sanitizeOptions($rawOptions, $type)
    {
        if (!in_array($type, ['select', 'radio', 'multiselect'], true)) {
            return [];
        }

        $options = [];

        if ($type === 'multiselect') {
            foreach ($rawOptions as $key => $label) {
                $key = sanitize_text_field((string) $key);
                $label = sanitize_text_field((string) $label);
                if ($key !== '' && $label !== '') {
                    $options[$key] = $label;
                }
            }
        } else {
            foreach ($rawOptions as $option) {
                if (!is_string($option)) {
                    continue;
                }
                $sanitized = sanitize_text_field($option);
                if ($sanitized !== '') {
                    $options[] = $sanitized;
                }
            }
        }

        return $options;
    }
}
