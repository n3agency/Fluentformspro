<?php

namespace FluentCommunityPro\App\Services\Analytics;

/**
 * Tolerant parsing for the `start_date` / `end_date` query parameters.
 *
 * These arrive from the request having been through `sanitize_text_field()`,
 * which strips tags and does NOT validate a date. `new \DateTime()` throws on
 * anything it cannot parse (DateMalformedStringException on PHP 8.3+, plain
 * Exception before), and nothing between the controller and the analytics
 * services catches it — so `?start_date=abc` used to 500 the endpoint.
 *
 * This lives in one place on purpose. The first fix for that bug guarded
 * ReportGenerator only, and `Overview::getPopularDayTime()` — a sibling path
 * with its own `new \DateTime($this->startDate)` and its own defaults — kept
 * throwing. Two copies of the guard was what let the second one be missed, so
 * there is now one copy and both callers use it.
 */
class DateRangeParser
{
    /**
     * Parse, or fall back to the default the caller would have got by omitting
     * the parameter entirely.
     *
     * @param mixed $value
     * @param string $fallback a date string this class controls, not user input
     * @return \DateTime
     */
    public static function parse($value, $fallback)
    {
        return static::tryParse($value) ?: new \DateTime($fallback);
    }

    /**
     * Returns null instead of throwing, so a caller can tell "the user gave me
     * something unusable" apart from "the user gave me a valid date".
     *
     * @param mixed $value
     * @return \DateTime|null
     */
    public static function tryParse($value)
    {
        if ((!is_string($value) || trim($value) === '') && !is_numeric($value)) {
            return null;
        }

        try {
            return new \DateTime((string) $value);
        } catch (\Exception $e) {
            return null;
        }
    }
}
