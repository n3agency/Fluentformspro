<?php

namespace FluentCommunityPro\App\Services\Analytics;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunity\App\Models\XProfile;
use FluentCommunity\App\Models\Comment;
use FluentCommunity\App\Models\Space;
use FluentCommunity\App\Models\Feed;

class Overview
{
    protected $provider;

    protected $startDate;

    protected $endDate;

    public function __construct($provider, $startDate = null, $endDate = null)
    {
        $this->provider = $provider;
        $this->startDate = $startDate;
        $this->endDate = $endDate;
    }

    public function getWidget()
    {
        $dateRanges = $this->getDateRanges($this->startDate, $this->endDate);

        return [
            'members'  => $this->provider->getWidgetCountsWithComparison($dateRanges, new XProfile(), __('Members', 'fluent-community-pro')),
            'posts'    => $this->provider->getWidgetCountsWithComparison($dateRanges, new Feed(), __('Posts', 'fluent-community-pro')),
            'comments' => $this->provider->getWidgetCountsWithComparison($dateRanges, new Comment(), __('Comments', 'fluent-community-pro')),
            'spaces'   => $this->provider->getWidgetCountsWithComparison($dateRanges, new Space(), __('Spaces', 'fluent-community-pro'))
        ];
    }

    public function getActivity($activity, $field = 'created_at')
    {
        $providers = [
            'comments' => [
                'model' => Comment::class,
                'title' => __('Comments', 'fluent-community-pro'),
            ],
            'members'  => [
                'model' => XProfile::class,
                'title' => __('Members', 'fluent-community-pro'),
            ],
            'posts'    => [
                'model' => Feed::class,
                'title' => __('Posts', 'fluent-community-pro'),
            ],
            'spaces'   => [
                'model' => Space::class,
                'title' => __('Spaces', 'fluent-community-pro'),
            ],
        ];


        if (!array_key_exists($activity, $providers)) {
            throw new \InvalidArgumentException('Invalid activity type provided.');
        }


        $data = $this
            ->provider->reports($this->startDate, $this->endDate)
            ->getModelDataBySequence(
                new $providers[$activity]['model'](),
                $field
            )
        ;

        $datePeriods = array_keys($data);

        $statistics = [
            'activity' => $activity,
            'title'    => $providers[$activity]['title'],
        ];

        $statisticsData = [];

        foreach ($datePeriods as $date) {
            $statisticsData[] = [
                'date' => $date,
                'data' => Arr::get($data, $date, 0),
            ];
        }

        // failsafe for sorting
        usort($statisticsData, function ($a, $b) {
            return strtotime($a['date']) <=> strtotime($b['date']);
        });

        $statistics['data'] = $statisticsData;


        // the casting is necessary to avoid the error of the type array<LIKE>. make sure the result is array
        return (array)$statistics;
    }

    public function getPopularDayTime()
    {
        $activitiesModels = [Comment::class, Feed::class, Space::class, XProfile::class];
        // Set default start and end dates if not provided
        // Unparseable input falls back to this method's own defaults rather
        // than throwing. These two lines are a second instance of the bug fixed
        // in ReportGenerator: an unvalidated query parameter reaching
        // new \DateTime() 500s the endpoint. See DateRangeParser.
        $startDate = DateRangeParser::parse($this->startDate, 'last sunday -6 days');
        $endDate = DateRangeParser::parse($this->endDate, 'last sunday');

        // Define time segments for each day
        $timeSegments = $this->provider->generateTimeSegments(6, false);
        $hoursPerSegment = (int)(24 / count($timeSegments));

        // Define days of the week
        $weekDays = $this->provider->generateWeekdays();

        // Define models to count activities from
        $tableData = [];

        // Initialize the structure for table data
        foreach ($timeSegments as $segment) {
            $row = ['time_range' => $segment];
            foreach ($weekDays as $day) {
                $row[$day] = 0;  // Initialize counts for each day
            }
            $tableData[] = $row;
        }

        $startBoundary = $startDate->format('Y-m-d') . ' 00:00:00';
        $endBoundary = $endDate->format('Y-m-d') . ' 23:59:59';
        $weekDayMap = [
            1 => 'Sunday',
            2 => 'Monday',
            3 => 'Tuesday',
            4 => 'Wednesday',
            5 => 'Thursday',
            6 => 'Friday',
            7 => 'Saturday'
        ];

        foreach ($activitiesModels as $model) {
            $stats = $model::query()
                ->selectRaw('DAYOFWEEK(created_at) as weekday_index, HOUR(created_at) as hour_index, COUNT(*) as total_count')
                ->whereBetween('created_at', [$startBoundary, $endBoundary])
                ->groupBy('weekday_index', 'hour_index')
                ->get();

            foreach ($stats as $stat) {
                $dayOfWeek = Arr::get($weekDayMap, (int)$stat->weekday_index);
                if (!$dayOfWeek) {
                    continue;
                }

                $segmentIndex = (int)floor(((int)$stat->hour_index) / $hoursPerSegment);
                if (!isset($tableData[$segmentIndex]) || !isset($tableData[$segmentIndex][$dayOfWeek])) {
                    continue;
                }

                $tableData[$segmentIndex][$dayOfWeek] += (int)$stat->total_count;
            }
        }

        // Prepare columns for the table
        $weekDays = $this->provider->getWeekDaysColumns();

        // Return the table data
        return [
            'columns' => $weekDays,
            'data'    => $tableData
        ];
    }

    public function getDateRanges($startDate, $endDate)
    {
        return [
            'start_date' => gmdate('Y-m-d', strtotime($startDate)) . ' 00:00:00',
            'end_date'   => gmdate('Y-m-d', strtotime($endDate)) . ' 23:59:59'
        ];
    }
}
