<?php

namespace FluentCommunityPro\App\Services;

use FluentCommunity\App\Models\Comment;
use FluentCommunity\App\Models\Feed;
use FluentCommunity\App\Models\Meta;
use FluentCommunity\App\Models\User;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Support\Arr;

class ModerationService
{
    protected static $flaggedUsersCache = [];

    public static function isUserFlagged($userId)
    {
        if (!$userId) {
            return false;
        }

        if (!isset(static::$flaggedUsersCache[$userId])) {
            $flagValue = Meta::where('object_type', 'user')
                ->where('object_id', $userId)
                ->where('meta_key', '_is_flagged')
                ->value('value');

            static::$flaggedUsersCache[$userId] = $flagValue === 'yes';
        }

        return static::$flaggedUsersCache[$userId];
    }

    public static function updateUserFlag($targetUser, $isFlagged)
    {
        $targetUser->updateCustomMeta('_is_flagged', $isFlagged ? 'yes' : 'no');

        if (!$isFlagged) {
            $targetUser->updateCustomMeta('_moderation_rejections', 0);
            $targetUser->updateCustomMeta('_moderation_reporters', []);
        }

        static::$flaggedUsersCache[$targetUser->ID] = (bool)$isFlagged;
    }

    public static function recordRejectionStrike($content)
    {
        $threshold = (int)Arr::get(Helper::getModerationConfig(), 'auto_flag_user_reject_threshold', 0);

        if ($threshold <= 0) {
            return;
        }

        $author = static::strikeableAuthor($content);

        if (!$author) {
            return;
        }

        $count = (int)$author->getCustomMeta('_moderation_rejections', 0) + 1;
        $author->updateCustomMeta('_moderation_rejections', $count);

        if ($count >= $threshold) {
            static::updateUserFlag($author, true);
        }
    }

    public static function recordReportStrike($content, $reporterId)
    {
        $threshold = (int)Arr::get(Helper::getModerationConfig(), 'auto_flag_user_report_threshold', 0);

        if ($threshold <= 0 || !$reporterId) {
            return;
        }

        $author = static::strikeableAuthor($content);

        if (!$author) {
            return;
        }

        $reporters = array_map('intval', (array)$author->getCustomMeta('_moderation_reporters', []));

        if (in_array((int)$reporterId, $reporters, true)) {
            return;
        }

        $reporters[] = (int)$reporterId;
        $author->updateCustomMeta('_moderation_reporters', $reporters);

        if (count($reporters) >= $threshold) {
            static::updateUserFlag($author, true);
        }
    }

    protected static function strikeableAuthor($content)
    {
        $authorId = (int)$content->user_id;

        if (!$authorId || static::isModeratorUser($authorId) || static::isUserFlagged($authorId)) {
            return null;
        }

        return User::find($authorId);
    }

    public static function isModeratorUser($userId)
    {
        if (Helper::isSuperAdmin($userId)) {
            return true;
        }

        $communityRoles = Meta::where('object_type', 'user')
            ->where('object_id', $userId)
            ->where('meta_key', '_user_community_roles')
            ->value('value');

        return !!array_intersect(['moderator', 'admin'], (array)$communityRoles);
    }

    public static function getUserFlaggedReason($userId)
    {
        if (!static::isUserFlagged($userId)) {
            return false;
        }

        return [
            'reason'      => 'user_flagged',
            'explanation' => __('Member is under moderation', 'fluent-community-pro')
        ];
    }

    public static function getProfanityReason($profanityWords, $content)
    {
        $flaggedWord = Helper::isProfanity($profanityWords, $content);

        if (!$flaggedWord) {
            return false;
        }

        return [
            'reason'      => 'profanity',
            'explanation' => sprintf(__('Word: %s', 'fluent-community-pro'), $flaggedWord)
        ];
    }

    public static function isContentFlagged($data)
    {
        $moderationConfig = Helper::getModerationConfig();

        $profiency = Arr::get($moderationConfig, 'profanity_filter', '');
        $flagAllPosts = Arr::get($moderationConfig, 'flag_all_new_posts') == 'yes';
        $flagPostSpaces = Arr::get($moderationConfig, 'flag_all_new_posts_spaces', []);
        $firstPostApproval = Arr::get($moderationConfig, 'first_post_approval', 'no') == 'yes';
        $spaceId = Arr::get($data, 'space_id');

        $content = Arr::get($data, 'title') . ' ' . Arr::get($data, 'message');

        if ($flagged = static::getUserFlaggedReason(Arr::get($data, 'user_id'))) {
            return $flagged;
        }

        if ($flagAllPosts) {
            return [
                'reason'      => 'flag_all_new_posts',
                'explanation' => __('Global moderation settings require review', 'fluent-community-pro')
            ];
        }

        if ($flagPostSpaces && $spaceId && in_array($spaceId, $flagPostSpaces)) {
            return [
                'reason'      => 'flag_all_new_posts_spaces',
                'explanation' => __('Space moderation settings require review', 'fluent-community-pro')
            ];
        }

        if ($firstPostApproval && !Feed::where('user_id', $data['user_id'])->where('status', 'published')->exists()) {
            return [
                'reason'      => 'first_post_approval',
                'explanation' => __('First post requires approval', 'fluent-community-pro')
            ];
        }

        return static::getProfanityReason($profiency, $content);
    }

    public static function isCommentFlagged($data)
    {
        $moderationConfig = Helper::getModerationConfig();

        $profiency = Arr::get($moderationConfig, 'profanity_filter', '');
        $firstCommentApproval = Arr::get($moderationConfig, 'first_comment_approval', 'no') == 'yes';

        $content = Arr::get($data, 'message');
        $userId = get_current_user_id();

        if ($flagged = static::getUserFlaggedReason($userId)) {
            return $flagged;
        }

        if ($flagged = static::getProfanityReason($profiency, $content)) {
            return $flagged;
        }

        if ($firstCommentApproval && $userId && !Comment::where('user_id', $userId)->where('status', 'published')->exists()) {
            return [
                'reason'      => 'first_comment_approval',
                'explanation' => __('First comment requires approval', 'fluent-community-pro')
            ];
        }

        return false;
    }
}
