<?php

namespace FluentCommunityPro\App\Services;

use FluentCommunity\App\Functions\Utility;
use FluentCommunity\App\Models\Space;
use FluentCommunity\App\Models\User;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\App\Services\ProfileHelper;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunity\Modules\Course\Model\Course;
use FluentCommunity\Modules\Course\Services\CourseHelper;

class BulkMemberHelper
{
    public static function processSourceCopyBatch(Request $request, callable $processor)
    {
        $emptyResult = [
            'added'       => 0,
            'skipped'     => 0,
            'failed'      => 0,
            'processed'   => 0,
            'total'       => 0,
            'next_offset' => 0,
            'has_more'    => false,
            'message'     => sprintf(__('%d added successfully.', 'fluent-community-pro'), 0),
        ];

        $currentUser = Helper::getCurrentUser(true);
        if (!$currentUser) {
            return $emptyResult;
        }

        $fromCourseId  = (int) $request->get('from_course_id');
        $fromSpaceSlug = $request->getSafe('from_space_slug');

        $membersQuery = null;
        if ($fromCourseId) {
            $fromCourse = Course::find($fromCourseId);
            if ($fromCourse && $fromCourse->verifyUserPermisson($currentUser, 'can_view_members', false)) {
                $membersQuery = $fromCourse->students();
            }
        } elseif ($fromSpaceSlug) {
            $fromSpace = Space::where('slug', $fromSpaceSlug)->first();
            if ($fromSpace && $fromSpace->verifyUserPermisson($currentUser, 'can_view_members', false)) {
                $membersQuery = $fromSpace->members();
            }
        }

        if (!$membersQuery) {
            return $emptyResult;
        }

        $offset  = max(0, (int) $request->get('offset', 0));
        $perPage = min(500, max(50, (int) $request->get('per_page', 500)));

        $total = (clone $membersQuery)->count();

        $batch = $membersQuery->orderBy('user_id', 'asc')
            ->offset($offset)
            ->limit($perPage)
            ->pluck('user_id')
            ->toArray();

        $startTime = microtime(true);
        $maxTime   = Utility::getMaxRunTime();
        $added     = 0;
        $skipped   = 0;
        $failed    = 0;

        $usersMap = $batch ? User::whereIn('ID', $batch)->get()->keyBy('ID') : collect();

        foreach ($batch as $userId) {
            if ((microtime(true) - $startTime) >= $maxTime) {
                break;
            }

            $outcome = $processor($userId, $usersMap->get($userId));

            if ($outcome === 'added') {
                $added++;
            } elseif ($outcome === 'skipped') {
                $skipped++;
            } else {
                $failed++;
            }
        }

        $processed  = $added + $skipped + $failed;
        $nextOffset = $offset + $processed;

        return [
            'added'       => $added,
            'skipped'     => $skipped,
            'failed'      => $failed,
            'processed'   => $processed,
            'total'       => $total,
            'next_offset' => $nextOffset,
            'has_more'    => $nextOffset < $total,
            'message'     => sprintf(__('%d added successfully.', 'fluent-community-pro'), $added),
        ];
    }

    public static function processCourseEnrollments(Course $course, array $userIds = [])
    {
        $startTime = microtime(true);
        $maxTime   = Utility::getMaxRunTime();

        $added     = 0;
        $skipped   = 0;
        $failed    = 0;
        $processed = 0;
        $total     = count($userIds);

        $usersMap = $userIds ? User::whereIn('ID', $userIds)->get()->keyBy('ID') : collect();

        foreach ($userIds as $userId) {
            if ($processed > 0 && (microtime(true) - $startTime) >= $maxTime) {
                break;
            }

            $processed++;

            $user = $usersMap->get($userId);

            if (!$user) {
                $failed++;
                continue;
            }

            $xprofile = $user->syncXProfile();

            if ($xprofile && $xprofile->status !== 'active') {
                $failed++;
                continue;
            }

            $enrolled = CourseHelper::enrollCourse($course, $userId, 'by_admin', true);

            if ($enrolled) {
                $added++;
            } else {
                $skipped++;
            }
        }

        return [
            'added'     => $added,
            'skipped'   => $skipped,
            'failed'    => $failed,
            'processed' => $processed,
            'total'     => $total,
            'has_more'  => $processed < $total,
            'message'   => sprintf(__('%d student(s) added successfully.', 'fluent-community-pro'), $added),
        ];
    }

    public static function processSpaceAdditions(Space $space, array $userIds, string $role)
    {
        $startTime = microtime(true);
        $maxTime   = Utility::getMaxRunTime();

        $added     = 0;
        $skipped   = 0;
        $failed    = 0;
        $processed = 0;
        $total     = count($userIds);

        $usersMap = $userIds ? User::whereIn('ID', $userIds)->get()->keyBy('ID') : collect();

        foreach ($userIds as $userId) {
            if ($processed > 0 && (microtime(true) - $startTime) >= $maxTime) {
                break;
            }

            $processed++;

            $user = $usersMap->get($userId);

            if (!$user) {
                $failed++;
                continue;
            }

            $xprofile = $user->syncXProfile();

            if ($xprofile && $xprofile->status !== 'active') {
                $failed++;
                continue;
            }

            $result = Helper::addToSpace($space, $userId, $role, 'by_admin', true);

            if ($result) {
                $added++;
            } else {
                $skipped++;
            }
        }

        return [
            'added'     => $added,
            'skipped'   => $skipped,
            'failed'    => $failed,
            'processed' => $processed,
            'total'     => $total,
            'has_more'  => $processed < $total,
            'message'   => sprintf(__('%d member(s) added successfully.', 'fluent-community-pro'), $added),
        ];
    }

    public static function runBulkImport(Request $request, string $type, $target)
    {
        if (!in_array($type, ['course', 'space'], true)) {
            throw new \InvalidArgumentException('Invalid bulk import type: ' . $type);
        }

        $rawRows       = (array) $request->get('rows', []);
        $rawRows       = array_slice($rawRows, 0, 500);
        $createMissing = (bool) $request->get('create_missing', false);
        $notifyNew     = (bool) $request->get('notify_new_users', false);

        $creationDenied = $createMissing && !self::canCreateWpUsers();
        if ($creationDenied) {
            $createMissing = false;
        }

        $startTime = microtime(true);
        $maxTime   = Utility::getMaxRunTime();

        $added     = 0;
        $skipped   = 0;
        $failed    = 0;
        $processed = 0;
        $total     = count($rawRows);
        $seen      = [];

        $rowEmails = [];
        foreach ($rawRows as $row) {
            $cleanEmail = sanitize_email((string) ($row['email'] ?? ''));
            if (is_email($cleanEmail)) {
                $rowEmails[] = strtolower($cleanEmail);
            }
        }

        $userMap = [];
        if ($rowEmails) {
            $users = User::whereIn('user_email', array_unique($rowEmails))->get();
            foreach ($users as $existingUser) {
                $userMap[strtolower($existingUser->user_email)] = $existingUser;
            }
        }

        foreach ($rawRows as $row) {
            if ($processed > 0 && (microtime(true) - $startTime) >= $maxTime) {
                break;
            }

            $processed++;

            $email    = sanitize_email((string) ($row['email'] ?? ''));
            $name     = sanitize_text_field((string) ($row['name'] ?? ''));
            $username = sanitize_user((string) ($row['username'] ?? ''), true);
            $emailKey = strtolower($email);

            if (!is_email($email) || isset($seen[$emailKey])) {
                $failed++;
                continue;
            }

            $seen[$emailKey] = true;

            if (isset($userMap[$emailKey])) {
                $user   = $userMap[$emailKey];
                $userId = (int) $user->ID;
            } elseif ($createMissing) {
                $newId = ProfileHelper::createWpUser([
                    'email'     => $email,
                    'full_name' => $name,
                    'username'  => $username,
                ]);

                if (is_wp_error($newId)) {
                    $failed++;
                    continue;
                }
                $userId = $newId;
                $user   = User::find($userId);

                if (!$user) {
                    $failed++;
                    continue;
                }

                $userMap[$emailKey] = $user;

                if ($notifyNew) {
                    as_enqueue_async_action('fluent_community/send_new_user_notification', [(int) $userId], 'fluent-community');
                }
            } else {
                $failed++;
                continue;
            }

            $xprofile = $user->syncXProfile();

            if ($xprofile && $xprofile->status !== 'active') {
                $failed++;
                continue;
            }

            $ok = $type === 'course'
                ? CourseHelper::enrollCourse($target, $userId, 'by_admin', true)
                : Helper::addToSpace($target, $userId, 'member', 'by_admin', true);

            if ($ok) {
                $added++;
            } else {
                $skipped++;
            }
        }

        return [
            'added'     => $added,
            'skipped'   => $skipped,
            'failed'    => $failed,
            'processed' => $processed,
            'total'     => $total,
            'has_more'  => $processed < $total,
            'message'   => $creationDenied
                ? sprintf(__('%d added successfully. New user accounts were not created because you do not have permission to create users.', 'fluent-community-pro'), $added)
                : sprintf(__('%d added successfully.', 'fluent-community-pro'), $added),
        ];
    }

    public static function resolveCrmTagPaged(int $tagId, bool $createMissing, int $offset, int $perPage, bool $notifyNew = false): array
    {
        $creationDenied = $createMissing && !self::canCreateWpUsers();
        if ($creationDenied) {
            $createMissing = false;
        }

        $startTime = microtime(true);
        $maxTime   = Utility::getMaxRunTime();

        $baseQuery = \FluentCrm\App\Models\Subscriber::whereHas('tags', function ($query) use ($tagId) {
            $query->where('object_id', $tagId);
        });

        $total = (clone $baseQuery)->count();

        $subscribers = $baseQuery
            ->select(['email', 'first_name', 'last_name'])
            ->offset($offset)
            ->limit($perPage)
            ->get();

        $userIds   = [];
        $failed    = 0;
        $processed = 0;

        $pageEmails = [];
        foreach ($subscribers as $subscriber) {
            $cleanEmail = sanitize_email((string) $subscriber->email);
            if (is_email($cleanEmail)) {
                $pageEmails[] = strtolower($cleanEmail);
            }
        }

        $existingMap = [];
        if ($pageEmails) {
            $rows = User::whereIn('user_email', array_unique($pageEmails))
                ->select(['ID', 'user_email'])
                ->get();
            foreach ($rows as $row) {
                $existingMap[strtolower($row->user_email)] = (int) $row->ID;
            }
        }

        foreach ($subscribers as $subscriber) {
            if ($processed > 0 && (microtime(true) - $startTime) >= $maxTime) {
                break;
            }

            $processed++;

            $email = sanitize_email((string) $subscriber->email);

            if (!is_email($email)) {
                $failed++;
                continue;
            }

            $emailKey = strtolower($email);

            if (isset($existingMap[$emailKey])) {
                $userIds[] = $existingMap[$emailKey];
                continue;
            }

            if (!$createMissing) {
                continue;
            }

            $newId = ProfileHelper::createWpUser([
                'email'     => $email,
                'full_name' => trim($subscriber->first_name . ' ' . $subscriber->last_name),
            ]);

            if (is_wp_error($newId)) {
                $failed++;
                continue;
            }

            $existingMap[$emailKey] = (int) $newId;
            $userIds[]              = $newId;

            if ($notifyNew) {
                as_enqueue_async_action('fluent_community/send_new_user_notification', [(int) $newId], 'fluent-community');
            }
        }

        $nextOffset = $offset + $processed;

        return [
            'user_ids'        => $userIds,
            'failed'          => $failed,
            'processed'       => $processed,
            'total'           => $total,
            'next_offset'     => $nextOffset,
            'has_more'        => $nextOffset < $total,
            'creation_denied' => $creationDenied,
        ];
    }

    private static function canCreateWpUsers()
    {
        return (bool) apply_filters('fluent_community/bulk_members/can_create_wp_users', current_user_can('create_users'));
    }
}
