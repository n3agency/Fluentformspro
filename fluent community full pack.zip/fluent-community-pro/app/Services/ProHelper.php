<?php

namespace FluentCommunityPro\App\Services;


use FluentCommunity\App\Functions\Utility;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\App\Services\ProfileHelper;
use FluentCommunity\App\Services\Libs\Mailer;
use FluentCommunity\Framework\Support\Arr;

class ProHelper
{
    /*
     * Install Plugins with direct download link ( which doesn't have wordpress.org repo )
     */
    public static function backgroundInstallerDirect($plugin_to_install, $plugin_id, $downloadUrl)
    {
        if (!empty($plugin_to_install['repo-slug'])) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
            require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
            require_once ABSPATH . 'wp-admin/includes/plugin.php';

            \WP_Filesystem();

            $skin = new \Automatic_Upgrader_Skin();
            $upgrader = new \WP_Upgrader($skin);
            $installed_plugins = array_reduce(array_keys(\get_plugins()), array(static::class, 'associate_plugin_file'), array());
            $plugin_slug = $plugin_to_install['repo-slug'];
            $plugin_file = isset($plugin_to_install['file']) ? $plugin_to_install['file'] : $plugin_slug . '.php';
            $installed = false;
            $activate = false;

            // See if the plugin is installed already.
            if (isset($installed_plugins[$plugin_file])) {
                $installed = true;
                $activate = !is_plugin_active($installed_plugins[$plugin_file]);
            }

            // Install this thing!
            if (!$installed) {
                // Suppress feedback.
                ob_start();

                try {
                    $package = $downloadUrl;
                    $download = $upgrader->download_package($package);

                    if (is_wp_error($download)) {
                        throw new \Exception($download->get_error_message());
                    }

                    $working_dir = $upgrader->unpack_package($download, true);

                    if (is_wp_error($working_dir)) {
                        throw new \Exception($working_dir->get_error_message());
                    }

                    $result = $upgrader->install_package(
                        array(
                            'source'                      => $working_dir,
                            'destination'                 => WP_PLUGIN_DIR,
                            'clear_destination'           => false,
                            'abort_if_destination_exists' => false,
                            'clear_working'               => true,
                            'hook_extra'                  => array(
                                'type'   => 'plugin',
                                'action' => 'install',
                            ),
                        )
                    );

                    if (is_wp_error($result)) {
                        throw new \Exception($result->get_error_message());
                    }

                    $activate = true;
                } finally {
                    // Discard feedback.
                    ob_end_clean();
                }
            }

            wp_clean_plugins_cache();

            // Activate this thing.
            if ($activate) {
                $result = activate_plugin($installed ? $installed_plugins[$plugin_file] : $plugin_slug . '/' . $plugin_file);

                if (is_wp_error($result)) {
                    throw new \Exception($result->get_error_message());
                }
            }
        }
    }

    private static function associate_plugin_file($plugins, $key)
    {
        $path = explode('/', $key);
        $filename = end($path);
        $plugins[$filename] = $key;
        return $plugins;
    }

    public static function createUserFromCrmContact(\FluentCrm\App\Models\Subscriber $subscriber)
    {
        $userName = ProfileHelper::createUserNameFromStrings($subscriber->email, array_filter([
            $subscriber->first_name,
            $subscriber->last_name
        ]));

        $userData = [
            'role'       => get_option('default_role', 'subscriber'),
            'user_email' => $subscriber->email,
            'user_login' => $userName,
            'user_pass'  => wp_generate_password(8, false),
            'first_name' => $subscriber->first_name,
            'last_name'  => $subscriber->last_name
        ];

        $userId = wp_insert_user($userData);

        if (is_wp_error($userId)) {
            return $userId;
        }

        return $userId;
    }

    public static function getSnippetsSettings()
    {
        $defaults = [
            'custom_css' => '',
            'custom_js' => '',
        ];

        $settings = Utility::getOption('snippets_settings', $defaults);

        $settings = wp_parse_args($settings, $defaults);

        return $settings;
    }

    public static function updateSnippetsSettings($settings)
    {
        $preSettings = self::getSnippetsSettings();

        $settings = Arr::only($settings, array_keys($preSettings));

        Utility::updateOption('snippets_settings', $settings);

        return $settings;
    }

    /**
     * Keep only known selectors and strict color literals; generateCss() emits values unescaped.
     */
    public static function sanitizeColorConfig($config)
    {
        if (!is_array($config)) {
            return [];
        }

        $allowedSelectors = ['body', 'fcom_top_menu', 'spaces'];

        $sanitized = [];

        foreach ($config as $selector => $props) {
            if (!is_string($selector) || !in_array($selector, $allowedSelectors, true) || !is_array($props)) {
                continue;
            }

            $cleanProps = [];
            foreach ($props as $prop => $value) {
                if (!is_string($prop) || !preg_match('/^[a-z][a-z0-9_]{0,40}$/', $prop)) {
                    continue;
                }

                $color = self::sanitizeCssColor($value);
                if ($color === '') {
                    continue;
                }

                $cleanProps[$prop] = $color;
            }

            $sanitized[$selector] = $cleanProps;
        }

        return $sanitized;
    }

    /**
     * Returns the value if it is a hex, rgb()/rgba()/hsl()/hsla() or `transparent` literal, else ''.
     */
    public static function sanitizeCssColor($value)
    {
        if (!is_string($value)) {
            return '';
        }

        $value = trim($value);

        if ($value === '' || strlen($value) > 64) {
            return '';
        }

        if (strcasecmp($value, 'transparent') === 0) {
            return 'transparent';
        }

        if (preg_match('/^#(?:[0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i', $value)) {
            return $value;
        }

        if (preg_match('/^(?:rgb|rgba|hsl|hsla)\(\s*[0-9.%]+(?:\s*[,\/\s]\s*[0-9.%]+){2,3}\s*\)$/i', $value)) {
            return $value;
        }

        return '';
    }

    public static function sanitizeCSS($css)
    {
        if (!is_string($css) || $css === '') {
            return '';
        }

        // One pass to drop well-formed tags, then remove every remaining '<'.
        // Nested fragments like `</</x>style>` reassemble after a strip, but no
        // valid CSS needs a literal '<' and without one no tag can be formed,
        // so this is a breakout guard in linear time. This runs on every page
        // load, so it must not loop over the input.
        $css = preg_replace('#</?\w[^>]*>#', '', $css);

        if ($css === null) {
            return '';
        }

        $css = str_replace('<', '', $css);

        // Legacy IE / old-Firefox vectors. These can also reassemble when nested,
        // so re-run a bounded number of times and fail closed if still changing.
        $dangerous = [
            '/expression\s*\([^)]*\)/i',
            '/javascript\s*:/i',
            '/-moz-binding\s*:[^;}]*/i',
        ];

        for ($pass = 0; $pass < 5; $pass++) {
            $cleaned = preg_replace($dangerous, '', $css);

            if ($cleaned === null) {
                return '';
            }

            if ($cleaned === $css) {
                return $css;
            }

            $css = $cleaned;
        }

        return '';
    }

    public static function getCourseSmartCodes()
    {
        return apply_filters('fluent_community/course_smart_codes', [
            '{{section.title}}'           => __('Section Title', 'fluent-community-pro'),
            '{{section.url}}'             => __('Section URL', 'fluent-community-pro'),
            '{{course.title}}'            => __('Course Title', 'fluent-community-pro'),
            '{{user.display_name}}'       => __('User Name', 'fluent-community-pro'),
            '{{community.name}}'          => __('Site Name', 'fluent-community-pro'),
            '{{community.name_with_url}}' => __('Site Name with URL', 'fluent-community-pro')
        ]);
    }

    public static function getDefaultCourseNotification()
    {
        return apply_filters('fluent_community/default_course_email_notification', [
            'subject' => __('{{section.title}} is now available for you in {{course.title}}', 'fluent-community-pro'),
            'message' => __("Hi {{user.display_name}},\n\n{{section.title}} is now available to you in {{course.title}}.\nTo complete this section, please follow this link:\n{{section.url}},\n\nThanks,\n{{community.name_with_url}}", 'fluent-community-pro')
        ]);
    }

    public static function getStoredCourseWelcomeBannerSettings($course)
    {
        return (array) $course->getCustomMeta('course_welcome_banner_settings', []);
    }

    public static function saveCourseWelcomeBannerSettings($course, $settings)
    {
        return $course->updateCustomMeta('course_welcome_banner_settings', $settings);
    }

    public static function getCourseWelcomeBannerSettings($course)
    {
        $stored = self::getStoredCourseWelcomeBannerSettings($course);

        foreach (['enrolled', 'not_enrolled'] as $view) {
            $stored[$view] = wp_parse_args(
                $stored[$view] ?? [],
                self::defaultCourseWelcomeBannerView()
            );
        }

        return $stored;
    }

    public static function getCourseWelcomeBannerForView($course, $view = 'enrolled')
    {
        $banner = Arr::get(self::getStoredCourseWelcomeBannerSettings($course), $view, []);

        if (!is_array($banner) || Arr::get($banner, 'enabled') != 'yes') {
            return null;
        }

        unset($banner['description']);

        if ($view == 'not_enrolled') {
            unset($banner['allowClose']);
        }

        return apply_filters('fluent_community/course_welcome_banner', $banner, $view, $course);
    }

    private static function defaultCourseWelcomeBannerView()
    {
        return [
            'enabled'     => 'no',
            'description' => '',
            'mediaType'   => 'image',
            'allowClose'  => 'no',
            'title'       => '',
            'bannerImage' => '',
            'bannerVideo' => [
                'type'         => 'oembed',
                'url'          => '',
                'content_type' => '',
                'provider'     => '',
                'title'        => '',
                'author_name'  => '',
                'html'         => ''
            ],
            'ctaButtons'  => []
        ];
    }

    public static function sendThrottledEmails($users, $subject, $bodyTemplate, $permalink, $onTimeout, $skipUserId = 0, $maxRunTime = 50)
    {
        $recipientEmails = [];
        foreach ($users as $user) {
            $recipientEmails[] = $user->user_email;
        }
        $undeliverableEmails = Helper::getUndeliverableEmails($recipientEmails);

        $startTime = microtime(true);
        $maxSendPerSecond = 10;
        $lastUserId = 0;

        foreach ($users as $index => $user) {
            $lastUserId = $user->ID;

            if ($skipUserId && $user->ID == $skipUserId) {
                continue;
            }

            if ($undeliverableEmails && in_array(strtolower($user->user_email), $undeliverableEmails)) {
                continue;
            }

            $newEmailBody = str_replace([
                '##feed_permalink##',
                '##email_notification_url##'
            ], [
                ProfileHelper::signUserUrlWithAuthHash($permalink, $user->ID),
                ProfileHelper::getSignedNotificationPrefUrl($user->ID)
            ], $bodyTemplate);

            $mailer = new Mailer('', $subject, $newEmailBody);
            $mailer->to($user->user_email, $user->display_name);
            $mailer->send();

            if (microtime(true) - FLUENT_COMMUNITY_START_TIME > $maxRunTime) {
                call_user_func($onTimeout, $lastUserId);
                return ['completed' => false, 'last_user_id' => $lastUserId];
            }

            if (($index + 1) % $maxSendPerSecond == 0) {
                $timeTaken = microtime(true) - $startTime;
                if ($timeTaken < 1) {
                    usleep((int)(1000000 - ($timeTaken * 1000000)));
                }
                $startTime = microtime(true);
            }
        }

        return ['completed' => true, 'last_user_id' => $lastUserId];
    }
}
