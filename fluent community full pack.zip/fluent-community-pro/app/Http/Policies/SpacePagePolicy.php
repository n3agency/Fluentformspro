<?php

namespace FluentCommunityPro\App\Http\Policies;

use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Foundation\Policy;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunityPro\App\Modules\SpacePages\Services\SpacePageHelper;

class SpacePagePolicy extends Policy
{
    /**
     * Fallback for any method without an explicit handler below. Deliberately strict:
     * every write route also declares its own method so this is never the thing that
     * authorizes a mutation.
     *
     * @param \FluentCommunity\Framework\Http\Request\Request $request
     * @return bool
     */
    public function verifyRequest(Request $request)
    {
        return false;
    }

    /**
     * Reading a single page is open to anyone who can reach the portal. The controller
     * applies the per-page draft / privacy / membership gate.
     */
    public function show(Request $request, $spaceSlug, $pageSlug)
    {
        return !!Helper::canAccessPortal(get_current_user_id());
    }

    public function index(Request $request, $spaceSlug)
    {
        return $this->canManage($spaceSlug);
    }

    public function store(Request $request, $spaceSlug)
    {
        return $this->canManage($spaceSlug);
    }

    public function update(Request $request, $spaceSlug, $pageId)
    {
        return $this->canManage($spaceSlug);
    }

    public function duplicate(Request $request, $spaceSlug, $pageId)
    {
        return $this->canManage($spaceSlug);
    }

    public function destroy(Request $request, $spaceSlug, $pageId)
    {
        return $this->canManage($spaceSlug);
    }

    public function reIndex(Request $request, $spaceSlug)
    {
        return $this->canManage($spaceSlug);
    }

    protected function canManage($spaceSlug)
    {
        $xProfile = Helper::getCurrentProfile(true);

        if ($xProfile && $xProfile->status != 'active') {
            return false;
        }

        $space = SpacePageHelper::getSpaceBySlug($spaceSlug);

        return SpacePageHelper::canManagePages($space);
    }
}
