<?php

namespace FluentCommunityPro\App\Http\Policies;

use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunity\Framework\Foundation\Policy;
use FluentCommunity\App\Models\User;
use FluentCommunity\App\Models\Space;
use FluentCommunity\App\Services\Helper;

class TopicPolicy extends Policy
{
    /**
     * Fallback for any topic route without a dedicated method.
     * Topics are global records, so deny unless the user is a community admin.
     *
     * @param \FluentCommunity\Framework\Http\Request\Request $request
     * @return Boolean
     */
    public function verifyRequest(Request $request)
    {
        return Helper::isSiteAdmin();
    }

    /**
     * Community admins get the full topic list. Everyone else may only read the
     * lightweight topic options for a space or course they can manage.
     *
     * @param \FluentCommunity\Framework\Http\Request\Request $request
     * @return Boolean
     */
    public function getTopics(Request $request)
    {
        if (Helper::isSiteAdmin()) {
            return true;
        }

        if (!$request->get('optionsOnly')) {
            return false;
        }

        $userId = get_current_user_id();

        if (!$userId) {
            return false;
        }

        $user = User::find($userId);

        if (!$user) {
            return false;
        }

        if ($user->hasSpaceManageAccess() || $user->hasCourseCreatorAccess()) {
            return true;
        }

        $space = Space::find($request->get('space_id'));

        return $space && $user->getSpaceRole($space) === 'admin';
    }
}
