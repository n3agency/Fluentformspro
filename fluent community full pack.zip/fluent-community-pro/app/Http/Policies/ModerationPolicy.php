<?php

namespace FluentCommunityPro\App\Http\Policies;

use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunity\Framework\Foundation\Policy;
use FluentCommunity\App\Models\User;
use FluentCommunity\App\Models\Space;
use FluentCommunityPro\App\Models\Moderation;

class ModerationPolicy extends Policy
{
    /**
     * Check user permission for any method
     * @param \FluentCommunity\Framework\Http\Request\Request $request
     * @return Boolean
     */
    public function verifyRequest(Request $request)
    {
        $userId = get_current_user_id();

        if (!$userId) {
            return false;
        }

        $user = User::find($userId);

        if ($user->hasCommunityModeratorAccess()) {
            return true;
        }

        $space = Space::find($request->get('space_id'));

        return $space && in_array($user->getSpaceRole($space), ['admin', 'moderator']);
    }

    public function update(Request $request, $reportId)
    {
        return $this->canModerateReport($reportId);
    }

    public function delete(Request $request, $reportId)
    {
        return $this->canModerateReport($reportId);
    }

    protected function canModerateReport($reportId)
    {
        $userId = get_current_user_id();

        if (!$userId) {
            return false;
        }

        $user = User::find($userId);

        if (!$user) {
            return false;
        }

        if ($user->hasCommunityModeratorAccess()) {
            return true;
        }

        $report = Moderation::find($reportId);
        $space = $report && $report->post ? $report->post->space : null;

        return $space && in_array($user->getSpaceRole($space), ['admin', 'moderator']);
    }
}

