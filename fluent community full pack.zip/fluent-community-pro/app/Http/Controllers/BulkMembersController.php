<?php

namespace FluentCommunityPro\App\Http\Controllers;

use FluentCommunity\App\Models\Space;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunity\Modules\Course\Model\Course;
use FluentCommunity\Modules\Course\Services\CourseHelper;
use FluentCommunityPro\App\Services\BulkMemberHelper;

class BulkMembersController extends Controller
{
    public function bulkAddStudents(Request $request, $courseId)
    {
        $course = Course::findOrFail($courseId);

        if (!$course->isCourseAdmin()) {
            return $this->sendError(['message' => __('Permission denied', 'fluent-community-pro')], 403);
        }

        $userIds = array_unique(array_filter(array_map('intval', (array) $request->get('user_ids', []))));

        if (count($userIds) > 500) {
            return $this->sendError(['message' => __('Too many user_ids in one request. Maximum 500 per chunk.', 'fluent-community-pro')], 413);
        }

        if ($userIds) {
            $result = BulkMemberHelper::processCourseEnrollments($course, $userIds);
            return apply_filters('fluent_community/bulk_members/add_students_response', $result, $request->all(), $courseId);
        }

        $response = BulkMemberHelper::processSourceCopyBatch($request, function ($userId, $user) use ($course) {
            if (!$user) {
                return 'failed';
            }

            $xprofile = $user->syncXProfile();
            if ($xprofile && $xprofile->status !== 'active') {
                return 'failed';
            }

            $enroll = CourseHelper::enrollCourse($course, $userId, 'by_admin', true);
            return $enroll ? 'added' : 'skipped';
        });

        return apply_filters('fluent_community/bulk_members/add_students_response', $response, $request->all(), $courseId);
    }

    public function bulkAddMembers(Request $request, $spaceSlug)
    {
        $space = Space::where('slug', $spaceSlug)->firstOrFail();

        $currentUser = $this->getUser(true);

        if (!$space->verifyUserPermisson($currentUser, 'can_add_member', false)) {
            return $this->sendError(['message' => __('Permission denied', 'fluent-community-pro')], 403);
        }

        $allowedRoles = ['member', 'moderator', 'admin'];
        $requestedRole = $request->getSafe('role');
        $role = in_array($requestedRole, $allowedRoles) ? $requestedRole : 'member';

        $userIds = array_unique(array_filter(array_map('intval', (array) $request->get('user_ids', []))));

        if (count($userIds) > 500) {
            return $this->sendError(['message' => __('Too many user_ids in one request. Maximum 500 per chunk.', 'fluent-community-pro')], 413);
        }

        if ($userIds) {
            $result = BulkMemberHelper::processSpaceAdditions($space, $userIds, $role);
            return apply_filters('fluent_community/bulk_members/add_members_response', $result, $request->all(), $spaceSlug);
        }

        $response = BulkMemberHelper::processSourceCopyBatch($request, function ($userId, $user) use ($space) {
            if (!$user) {
                return 'failed';
            }

            $xprofile = $user->syncXProfile();
            if ($xprofile && $xprofile->status !== 'active') {
                return 'failed';
            }

            $added = Helper::addToSpace($space, $userId, 'member', 'by_admin', true);
            return $added ? 'added' : 'skipped';
        });

        return apply_filters('fluent_community/bulk_members/add_members_response', $response, $request->all(), $spaceSlug);
    }

    public function bulkImportStudents(Request $request, $courseId)
    {
        $course = Course::findOrFail($courseId);

        if (!$course->isCourseAdmin()) {
            return $this->sendError(['message' => __('Permission denied', 'fluent-community-pro')], 403);
        }

        $result = BulkMemberHelper::runBulkImport($request, 'course', $course);

        return apply_filters('fluent_community/bulk_members/import_students_response', $result, $request->all(), $courseId);
    }

    public function bulkImportMembers(Request $request, $spaceSlug)
    {
        $space = Space::where('slug', $spaceSlug)->firstOrFail();
        $currentUser = $this->getUser(true);

        if (!$space->verifyUserPermisson($currentUser, 'can_add_member', false)) {
            return $this->sendError(['message' => __('Permission denied', 'fluent-community-pro')], 403);
        }

        $result = BulkMemberHelper::runBulkImport($request, 'space', $space);

        return apply_filters('fluent_community/bulk_members/import_members_response', $result, $request->all(), $spaceSlug);
    }

    public function resolveCrmTagCourse(Request $request, $courseId)
    {
        $course = Course::findOrFail($courseId);

        if (!$course->isCourseAdmin()) {
            return $this->sendError(['message' => __('Permission denied', 'fluent-community-pro')], 403);
        }

        if (!defined('FLUENTCRM')) {
            return $this->sendError(['message' => __('FluentCRM is not active', 'fluent-community-pro')], 400);
        }

        return $this->runCrmTagResolve($request, $courseId, 'crm_tag_students_resolve_response');
    }

    public function resolveCrmTagSpace(Request $request, $spaceSlug)
    {
        $space       = Space::where('slug', $spaceSlug)->firstOrFail();
        $currentUser = $this->getUser(true);

        if (!$space->verifyUserPermisson($currentUser, 'can_add_member', false)) {
            return $this->sendError(['message' => __('Permission denied', 'fluent-community-pro')], 403);
        }

        if (!defined('FLUENTCRM')) {
            return $this->sendError(['message' => __('FluentCRM is not active', 'fluent-community-pro')], 400);
        }

        return $this->runCrmTagResolve($request, $spaceSlug, 'crm_tag_members_resolve_response');
    }

    private function runCrmTagResolve(Request $request, $contextId, $filterTag)
    {
        $tagId         = (int) $request->get('tag_id');
        $createMissing = (bool) $request->get('create_missing', false);
        $notifyNew     = (bool) $request->get('notify_new_users', false);
        $offset        = max(0, (int) $request->get('offset', 0));
        $perPage       = min(500, max(50, (int) $request->get('per_page', 200)));

        if (!\FluentCrm\App\Models\Tag::where('id', $tagId)->exists()) {
            return $this->sendError(['message' => __('Invalid CRM tag', 'fluent-community-pro')], 404);
        }

        $response = BulkMemberHelper::resolveCrmTagPaged($tagId, $createMissing, $offset, $perPage, $notifyNew);

        return apply_filters('fluent_community/bulk_members/' . $filterTag, $response, $request->all(), $contextId);
    }
}
