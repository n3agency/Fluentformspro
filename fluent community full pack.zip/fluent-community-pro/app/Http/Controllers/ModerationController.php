<?php

namespace FluentCommunityPro\App\Http\Controllers;

use FluentCommunity\App\Models\Feed;
use FluentCommunity\App\Models\Comment;
use FluentCommunity\App\Models\SpaceUserPivot;
use FluentCommunity\App\Services\FeedsHelper;
use FluentCommunity\App\Functions\Utility;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Models\Moderation;
use FluentCommunity\Framework\Http\Request\Request;

class ModerationController extends Controller
{
    public function get(Request $request)
    {
        $postId = $request->getSafe('post_id', 'intval');

        $parentId = $request->getSafe('parent_id', 'intval');

        $status = $request->getSafe('status', 'sanitize_text_field');

        $contentType = $request->getSafe('content_type', 'sanitize_text_field');

        $user = $this->getUser(true);

        $reports = Moderation::orderBy('created_at', 'desc')
            ->when(!$user->hasCommunityModeratorAccess(), function ($query) use ($user) {
                $query->whereHas('post', function ($postQuery) use ($user) {
                    $postQuery->whereIn('space_id', SpaceUserPivot::query()
                        ->select('space_id')
                        ->where('user_id', $user->ID)
                        ->where('status', 'active')
                        ->whereIn('role', ['admin', 'moderator'])
                    );
                });
            })
            ->when($status, function ($query) use ($status) {
                $query->where('status', $status);
            })
            ->when($postId, function ($query) use ($postId) {
                $query->where('post_id', $postId);
            })
            ->when($parentId, function ($query) use ($parentId) {
                $query->where('parent_id', $parentId);
            })
            ->when($contentType, function ($query) use ($contentType) {
                $query->where('content_type', $contentType);
            })
            ->with(['post.space', 'post.xprofile', 'comment', 'comment.xprofile', 'reporter'])
            ->paginate();

        $reports->getCollection()->transform(function ($report) {
            if ($report->post) {
                $report->post->title = $report->post->getHumanExcerpt(160);
            }
            if ($report->content_type == 'comment' && $report->comment) {
                $report->comment->title = $report->comment ? $report->comment->getHumanExcerpt(160) : '';
            }
            return $report;
        });

        return [
            'reports' => $reports
        ];
    }

    public function create(Request $request)
    {
        $data['reason'] = $request->getSafe('reason', 'sanitize_text_field');
        $data['explanation'] = $request->getSafe('explanation', 'sanitize_textarea_field');
        $data['content_type'] = $request->getSafe('content_type', 'sanitize_text_field');
        $data['post_id'] = $request->getSafe('post_id', 'intval');
        $data['parent_id'] = $request->getSafe('parent_id', 'intval');
        $data['user_id'] = get_current_user_id();

        $this->validate($data, [
            'content_type' => 'required|in:post,comment',
            'reason'       => 'required|string|max:255',
            'explanation'  => 'nullable|string|max:1000',
            'user_id'      => 'required',
            'parent_id'    => 'nullable',
            'post_id'      => 'required'
        ]);

        $feed = Feed::byUserAccess($data['user_id'])->withoutGlobalScopes()->findOrFail($data['post_id']);

        // byUserAccess() filters on space membership but not on status, and this
        // method reads the resolved content back to the caller. Without a status
        // gate, any member could walk post ids and read scheduled, draft, pending
        // or unpublished content by reporting it. Mirror the check core applies
        // when the same post is fetched directly (FeedsController::getFeed).
        if (
            !in_array($feed->status, FeedsHelper::getViewableByLinkStatuses(), true) &&
            !$feed->hasEditAccess($data['user_id'])
        ) {
            return $this->sendError([
                'message' => __('The content you are trying to report could not be found.', 'fluent-community-pro')
            ], 404);
        }

        $comment = null;

        if ($data['content_type'] == 'comment') {
            // Same rule for comments: only ones this user is allowed to see. The
            // scope resolves to published, plus pending for its own author and
            // for moderators of the feed's space.
            $comment = Comment::where('id', $data['parent_id'])
                ->byContentModerationAccessStatus($this->getUser(true), $feed->space)
                ->firstOrFail();

            if ($comment->post_id != $feed->id) {
                return $this->sendError([
                    'message' => __('This comment does not belong to the reported post.', 'fluent-community-pro')
                ]);
            }
        } else {
            $feedUser = $feed->user;
            if ($feedUser && $feed->space) {
                if ($feedUser->hasSpacePermission('community_moderator', $feed->space)) {
                    return $this->sendError([
                        'message' => __('You cannot report this content posted by a moderator.', 'fluent-community-pro')
                    ]);
                }
            }
        }

        // Check if the user already reported this content
        $existingReport = Moderation::where('post_id', $data['post_id'])
            ->where('content_type', $data['content_type'])
            ->when($comment, function ($query) use ($comment) {
                $query->where('parent_id', $comment->id);
            })
            ->where('user_id', $data['user_id'])
            ->first();

        if ($existingReport) {
            return $this->sendError([
                'message' => __('You have already reported this content.', 'fluent-community-pro')
            ]);
        }

        $existingReports = Moderation::where('post_id', $data['post_id'])
            ->where('content_type', $data['content_type'])
            ->when($comment, function ($query) use ($comment) {
                $query->where('parent_id', $comment->id);
            });

        $data['reports_count'] = $existingReports->count() + 1;

        if ($data['reports_count'] > 1) {
            $existingReports->update(['reactions_count' => $data['reports_count']]);
        }

        $report = Moderation::create($data);

        $content = $comment ? $comment : $feed;
        $meta = $content->meta ?: [];
        $meta['reports_count'] = $data['reports_count'];
        $content->meta = $meta;

        if (!$comment) {
            // Being reported is not activity - otherwise any member could bump any post at will.
            $content->timestamps = false;
        }

        $content->save();

        do_action('fluent_community/content_moderation/created', $report, $content, $data['content_type']);

        return [
            'message' => __('Your report has been successfully submitted. A moderator will review as soon as possible.', 'fluent-community-pro'),
            'report'  => Moderation::find($report->id),
            // Only what the reporting UI reads back. The full model carries the
            // body, the author and the space, none of which belongs in a
            // response to whoever pressed report.
            'content' => [
                'id'     => $content->id,
                'status' => $content->status,
                'meta'   => $content->meta
            ]
        ];
    }

    public function update(Request $request, $reportId)
    {
        $report = Moderation::findOrFail($reportId);

        $status = $request->getSafe('status');
        $allowedStatuses = ['published', 'unpublished', 'pending', 'rejected', 'flagged', 'ignored'];

        if (!in_array($status, $allowedStatuses, true)) {
            return $this->sendError(__('Invalid status value.', 'fluent-community-pro'), 422);
        }

        Moderation::where('post_id', $report->post_id)
            ->where('content_type', $report->content_type)
            ->where('parent_id', $report->parent_id)
            ->update(['status' => $status]);

        $reportMeta = $report->meta ?: [];
        $reportMeta['updated_by'] = get_current_user_id();
        $report->meta = $reportMeta;
        $report->save();

        $contentStatus = $status == 'unpublished' ? 'unpublished' : 'published';

        $oldContentStatus = $contentStatus;

        $isCommentContent = $report->content_type == 'comment';

        $contentPublished = false;

        $content = $isCommentContent
            ? Comment::find($report->parent_id)
            : Feed::withoutGlobalScopes()->find($report->post_id);

        if ($content) {
            $oldContentStatus = $content->status;
            $content->status = $contentStatus;

            $meta = $content->meta ?: [];
            $meta['reports_count'] = 0;

            $isPreventPublished = Arr::get($meta, 'prevent_published', 'no') === 'yes';
            if ($isPreventPublished && $contentStatus == 'published' && $oldContentStatus == 'pending') {
                $contentPublished = true;
                unset($meta['prevent_published']);
                unset($meta['auto_flagged']);
                unset($meta['flagged_reason']);
            }

            // Resolving a report is housekeeping; a held post going live for the first time is not.
            $isFirstPublish = $oldContentStatus === 'pending' && $contentStatus === 'published';

            if (!$isCommentContent && !$isFirstPublish) {
                $content->timestamps = false;
            }

            $content->meta = $meta;
            $content->save();
        }

        $feed = null;
        if ($isCommentContent) {
            $feed = Feed::withoutGlobalScopes()->find($report->post_id);
        }

        if ($feed && $contentStatus != $oldContentStatus) {
            if ($contentStatus == 'published') {
                // Approving a held comment is that comment arriving, so it bumps like any other.
                $feed->comments_count = $feed->comments_count + 1;
            }

            if ($contentStatus == 'unpublished') {
                $feed->comments_count = $feed->comments_count - 1;
                // Removing a comment is housekeeping, not activity.
                $feed->timestamps = false;
            }

            $feed->save();
        }

        if ($contentPublished) {
            if ($isCommentContent) {
                do_action('fluent_community/comment_added_' . $feed->type, $content, $feed);
                do_action('fluent_community/comment_added', $content, $feed);
            } else {
                do_action('fluent_community/feed/created', $content);
                if ($content->space_id) {
                    do_action('fluent_community/space_feed/created', $content);
                }
            }
        }

        do_action('fluent_community/report/' . $status, $report, $content);

        if ($status == 'unpublished') {
            $message = $isCommentContent
                ? __('The comment has been unpublished and is no longer visible to others.', 'fluent-community-pro')
                : __('The post has been unpublished and is no longer visible to others.', 'fluent-community-pro');
        } else {
            $message = $isCommentContent
                ? __('The report was dismissed. The comment is published and visible to the community.', 'fluent-community-pro')
                : __('The report was dismissed. The post is published and visible to the community.', 'fluent-community-pro');
        }

        return [
            'report'  => $report,
            'content' => $content,
            'message' => $message
        ];
    }

    public function delete(Request $request, $reportId)
    {
        $report = Moderation::findOrFail($reportId);
        do_action('fluent_community/report/before_delete', $report);
        $report->delete();

        do_action('fluent_community/report/after_delete', $report);

        return [
            'message' => __('Report deleted successfully', 'fluent-community-pro')
        ];
    }

    public function saveConfig(Request $request)
    {
        $config = $request->get('config', []);
        $config['is_enabled'] = Arr::get($config, 'is_enabled', 'no') === 'yes' ? 'yes' : 'no';
        $config['profanity_filter'] = sanitize_text_field(Arr::get($config, 'profanity_filter', ''));
        $config['flag_after_threshold'] = (int)Arr::get($config, 'flag_after_threshold', 0);
        $config['first_comment_approval'] = Arr::get($config, 'first_comment_approval', 'no') === 'yes' ? 'yes' : 'no';
        $config['auto_flag_user_reject_threshold'] = (int)Arr::get($config, 'auto_flag_user_reject_threshold', 0);
        $config['auto_flag_user_report_threshold'] = (int)Arr::get($config, 'auto_flag_user_report_threshold', 0);

        Utility::updateOption('moderation_config', $config);

        $globalFeatures = Utility::getOption('fluent_community_features', []);
        $globalFeatures['content_moderation'] = $config['is_enabled'];
        Utility::updateOption('fluent_community_features', $globalFeatures);

        return [
            'config'  => $config,
            'message' => __('Moderation config saved successfully', 'fluent-community-pro')
        ];
    }

}
