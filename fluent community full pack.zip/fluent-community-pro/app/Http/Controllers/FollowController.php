<?php

namespace FluentCommunityPro\App\Http\Controllers;

use FluentCommunity\App\Models\XProfile;
use FluentCommunity\App\Services\Helper;
use FluentCommunityPro\App\Models\Follow;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunityPro\App\Modules\Followers\FollowerHelper;

class FollowController extends Controller
{
    public function follow(Request $request, $username)
    {
        $xProfile = XProfile::where('username', $username)->first();

        if (!$xProfile) {
            return $this->sendError([
                'message' => __('Profile not found', 'fluent-community-pro')
            ]);
        }

        $followerId = get_current_user_id();
        $followedId = $xProfile->user_id;

        if ($followerId === $followedId) {
            return $this->sendError([
                'message' => __('You cannot follow yourself.', 'fluent-community-pro')
            ]);
        }

        $follow = Follow::where('follower_id', $followerId)
            ->where('followed_id', $followedId)
            ->first();

        if ($follow) {
            return $this->sendError([
                'message' => __('You are already following or blocked this user.', 'fluent-community-pro')
            ]);
        }

        $follow = Follow::create([
            'follower_id' => $followerId,
            'followed_id' => $followedId
        ]);

        do_action('fluent_community/followed_user', $follow, $xProfile);

        return [
            'follow'   => $follow,
            'xprofile' => $xProfile,
            'message'  => __('You followed this user successfully', 'fluent-community-pro')
        ];
    }

    public function unfollow(Request $request, $username)
    {
        $xProfile = XProfile::where('username', $username)->first();

        if (!$xProfile) {
            return $this->sendError([
                'message' => __('Profile not found', 'fluent-community-pro')
            ]);
        }

        $follow = Follow::where('follower_id', get_current_user_id())
            ->where('followed_id', $xProfile->user_id)
            ->first();

        if (!$follow || $follow->level == 0) {
            return $this->sendError([
                'message' => __('You are not currently following this user.', 'fluent-community-pro')
            ]);
        }

        do_action('fluent_community/before_unfollowing_user', $follow, $xProfile);

        $follow->delete();

        return [
            'follow'   => $follow,
            'xprofile' => $xProfile,
            'message'  => __('You unfollowed this user successfully', 'fluent-community-pro')
        ];
    }

    public function toggleFollow(Request $request, $userId)
    {
        $xProfile = XProfile::where('user_id', $userId)->firstOrFail();

        $followerId = get_current_user_id();
        $followedId = $xProfile->user_id;

        if ($followerId === $followedId) {
            return $this->sendError([
                'message' => __('You cannot follow/unfollow yourself.', 'fluent-community-pro')
            ]);
        }

        $follow = Follow::where('follower_id', $followerId)
            ->where('followed_id', $followedId)
            ->first();
            
        if ($follow && $follow->level == 0) {
            return $this->sendError([
                'message' => __('You cannot follow/unfollow a blocked user', 'fluent-community-pro')
            ]);
        }

        $message = __('You followed this user successfully', 'fluent-community-pro');
        if ($follow) {
            $message = __('You unfollowed this user successfully', 'fluent-community-pro');
            do_action('fluent_community/before_unfollowing_user', $follow, $xProfile);
            $follow->delete();
        } else {
            $follow = Follow::create([
                'follower_id' => $followerId,
                'followed_id' => $followedId
            ]);
            do_action('fluent_community/followed_user', $follow, $xProfile);
        }

        return [
            'follow'   => $follow,
            'xprofile' => $xProfile,
            'message'  => $message
        ];
    }
    public function block(Request $request, $username)
    {
        $xProfile = XProfile::where('username', $username)->first();

        if (!$xProfile) {
            return $this->sendError([
                'message' => __('Profile not found', 'fluent-community-pro')
            ]);
        }

        if ($xProfile->user_id == get_current_user_id()) {
            return $this->sendError([
                'message' => __('You cannot block yourself.', 'fluent-community-pro')
            ]);
        }

        if ($xProfile->user->hasCommunityModeratorAccess()) {
            return $this->sendError([
                'message' => __('Sorry, You cannot block a moderator.', 'fluent-community-pro')
            ]);
        }

        if (Helper::isModerator()) {
            return $this->sendError([
                'message' => __('Sorry, You cannot block a user as you are a moderator.', 'fluent-community-pro')
            ]);
        }

        $followerId = get_current_user_id();

        $follow = Follow::where('follower_id', $followerId)
            ->where('followed_id', $xProfile->user_id)
            ->first();

        if ($follow) {
            if ($follow->level != 0) {
                $follow->level = 0;
                $follow->save();
            }
        } else {
            $follow = Follow::create([
                'follower_id' => $followerId,
                'followed_id' => $xProfile->user_id,
                'level'       => 0
            ]);
        }

        do_action('fluent_community/blocked_user', $follow, $xProfile);

        return [
            'follow'   => $follow,
            'xprofile' => $xProfile,
            'message'  => __('You blocked this user successfully', 'fluent-community-pro')
        ];
    }

    public function unblock(Request $request, $username)
    {
        $xProfile = XProfile::where('username', $username)->first();

        if (!$xProfile) {
            return $this->sendError([
                'message' => __('Profile not found', 'fluent-community-pro')
            ]);
        }

        $follow = Follow::where('follower_id', get_current_user_id())
            ->where('followed_id', $xProfile->user_id)
            ->first();

        if (!$follow || $follow->level != 0) {
            return $this->sendError([
                'message' => __('You are not currently blocking this user.', 'fluent-community-pro')
            ]);
        }

        do_action('fluent_community/before_unblocking_user', $follow, $xProfile);

        $follow->delete();

        return [
            'follow'   => $follow,
            'xprofile' => $xProfile,
            'message'  => __('You unblocked this user successfully', 'fluent-community-pro')
        ];
    }

    public function getFollowers(Request $request, $username)
    {
        $xProfile = XProfile::where('username', $username)->first();

        if (!$xProfile || ($xProfile->status != 'active' && !Helper::isModerator())) {
            return $this->sendError([
                'message' => __('This profile is not active', 'fluent-community-pro')
            ]);
        }

        $canViewFollowers = FollowerHelper::canViewFollowers($xProfile->user_id);
        if (!$canViewFollowers) {
            return $this->sendError([
                'message' => __('You don\'t have permission to view the followers of this profile', 'fluent-community-pro')
            ]);
        }

        $search = $request->getSafe('search', 'sanitize_text_field');
        $sortBy = $request->getSafe('sort_by', 'sanitize_text_field', 'id');

        $query = Follow::where('followed_id', $xProfile->user_id)
            ->where('level', '>', 0)
            ->whereHas('follower', function ($q) use ($search) {
                if ($search) {
                    $q->where(function ($sq) use ($search) {
                        $sq->where('display_name', 'LIKE', "%{$search}%")
                            ->orWhere('username', 'LIKE', "%{$search}%");
                    });
                }
            })
            ->with('follower');

        if ($sortBy === 'alphabetical') {
            $query->select('fcom_followers.*')
                ->join('fcom_xprofile', 'fcom_xprofile.user_id', '=', 'fcom_followers.follower_id')
                ->orderBy('fcom_xprofile.display_name', 'asc');
        } else {
            $query->orderBy('id', 'DESC');
        }

        $followers = $query->paginate();

        $followerIds = $followers->getCollection()->pluck('follower_id')->toArray();

        $currentUserFollows = Follow::where('follower_id', get_current_user_id())
            ->whereIn('followed_id', $followerIds)
            ->pluck('level', 'followed_id');

        $followersBack = Follow::where('followed_id', get_current_user_id())
            ->whereIn('follower_id', $followerIds)
            ->where('level', '>', 0)
            ->pluck('follower_id')
            ->toArray();

        $followers->getCollection()->each(function ($follow) use ($currentUserFollows, $followersBack) {
            if (empty($follow->follower)) {
                return;
            }
            $follow->follower->follow = $currentUserFollows[$follow->follower_id] ?? null;
            $follow->follower->is_follower = in_array($follow->follower_id, $followersBack);
        });

        return [
            'followers' => $followers
        ];
    }

    public function getFollowings(Request $request, $username)
    {
        $xProfile = XProfile::where('username', $username)->first();

        if (!$xProfile || ($xProfile->status != 'active' && !Helper::isModerator())) {
            return $this->sendError([
                'message' => __('This profile is not active', 'fluent-community-pro')
            ]);
        }

        $canViewFollowings = FollowerHelper::canViewFollowings($xProfile->user_id);
        if (!$canViewFollowings) {
            return $this->sendError([
                'message' => __('You don\'t have permission to view the followings of this profile', 'fluent-community-pro')
            ]);
        }

        $search = $request->getSafe('search', 'sanitize_text_field');
        $sortBy = $request->getSafe('sort_by', 'sanitize_text_field', 'id');

        $query = Follow::where('follower_id', $xProfile->user_id)
            ->where('level', '>', 0)
            ->whereHas('followed', function ($q) use ($search) {
                if ($search) {
                    $q->where(function ($sq) use ($search) {
                        $sq->where('display_name', 'LIKE', "%{$search}%")
                            ->orWhere('username', 'LIKE', "%{$search}%");
                    });
                }
            })
            ->with('followed');

        if ($sortBy === 'alphabetical') {
            $query->select('fcom_followers.*')
                ->join('fcom_xprofile', 'fcom_xprofile.user_id', '=', 'fcom_followers.followed_id')
                ->orderBy('fcom_xprofile.display_name', 'asc');
        } else {
            $query->orderBy('id', 'DESC');
        }

        $followings = $query->paginate();

        $followingIds = $followings->getCollection()->pluck('followed_id')->toArray();

        $currentUserFollows = Follow::where('follower_id', get_current_user_id())
            ->whereIn('followed_id', $followingIds)
            ->pluck('level', 'followed_id');

        $followersBack = Follow::where('followed_id', get_current_user_id())
            ->whereIn('follower_id', $followingIds)
            ->where('level', '>', 0)
            ->pluck('follower_id')
            ->toArray();

        $followings->getCollection()->each(function ($follow) use ($currentUserFollows, $followersBack) {
            if (empty($follow->followed)) {
                return;
            }
            $follow->followed->follow = $currentUserFollows[$follow->followed_id] ?? null;
            $follow->followed->is_follower = in_array($follow->followed_id, $followersBack); 
        });

        return [
            'followings' => $followings
        ];
    }

    public function getBlockedUsers(Request $request, $username)
    {
        $xProfile = XProfile::where('username', $username)->first();

        if (!$xProfile || ($xProfile->status != 'active' && !Helper::isModerator())) {
            return $this->sendError([
                'message' => __('This profile is not active', 'fluent-community-pro')
            ]);
        }

        if ($xProfile->user_id != get_current_user_id() && !Helper::isModerator()) {
            return $this->sendError([
                'message' => __('You do not have permission to view this list.', 'fluent-community-pro')
            ], 403);
        }

        $blockedUsers = Follow::where('follower_id', $xProfile->user_id)
            ->where('level', 0)
            ->whereHas('followed')
            ->with('followed')
            ->paginate();

        return [
            'blockedUsers' => $blockedUsers
        ];
    }

    public function toggleNotification(Request $request, $username)
    {
        $xProfile = XProfile::where('username', $username)->first();

        if (!$xProfile || $xProfile->status != 'active') {
            return $this->sendError([
                'message' => __('Profile not found', 'fluent-community-pro'),
            ]);
        }

        $follow = Follow::where('follower_id', get_current_user_id())
            ->where('followed_id', $xProfile->user_id)
            ->first();

        if (!$follow || $follow->level == 0) {
            return $this->sendError([
                'message' => __('You are not currently following this user.', 'fluent-community-pro'),
            ]);
        }

        $follow->level = $follow->level == 2 ? 1 : 2;
        $follow->save();

        return [
            'follow'  => $follow,
            'message' => __('Notification has been updated successfully', 'fluent-community-pro')
        ];
    }
}
