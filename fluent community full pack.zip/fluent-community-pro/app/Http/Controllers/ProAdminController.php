<?php

namespace FluentCommunityPro\App\Http\Controllers;

use FluentCommunity\App\Models\SpaceGroup;
use FluentCommunity\App\Services\CustomSanitizer;
use FluentCommunity\App\Models\SidebarLink;
use FluentCommunityPro\App\Modules\Followers\FollowerHelper;
use FluentCommunityPro\App\Modules\Webhooks\WebhookModel;
use FluentCommunity\Modules\Course\Services\CourseHelper;
use FluentCommunity\App\Functions\Utility;
use FluentCommunity\App\Models\BaseSpace;
use FluentCommunity\App\Models\Meta;
use FluentCommunity\App\Models\Term;
use FluentCommunity\App\Models\User;
use FluentCommunity\App\Models\XProfile;
use FluentCommunity\App\Models\Space;
use FluentCommunity\App\Services\Helper;
use FluentCommunity\Modules\Auth\AuthHelper;
use FluentCommunity\App\Services\LockscreenService;
use FluentCommunity\App\Services\AuthenticationService;
use FluentCommunity\Modules\Course\Model\Course;
use FluentCommunity\Framework\Http\Request\Request;
use FluentCommunity\Framework\Support\Arr;
use FluentCommunityPro\App\Services\ProHelper;
use FluentCommunity\App\Services\ProfileHelper;
use FluentMessaging\App\Services\ChatHelper;
use FluentMessaging\App\Services\PusherHelper;
use FluentCommunityPro\App\Services\ProfileFieldsService;
use FluentCommunity\App\Services\FeedsHelper;

class ProAdminController extends Controller
{
    public function getManagers(Request $request)
    {
        $query = User::whereHas('community_role')
            ->whereHas('xprofile', function ($q) {
                $q->where('status', 'active');
            })
            ->with(['community_role', 'xprofile']);

        if ($search = $request->get('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('display_name', 'LIKE', "%{$search}%")
                    ->orWhere('user_email', 'LIKE', "%{$search}%")
                    ->orWhere('user_login', 'LIKE', "%{$search}%");
            });
        }

        $managers = $query->paginate();

        return [
            'managers' => $managers,
            'total'    => $managers->total()
        ];
    }

    public function addOrUpdateManager(Request $request)
    {
        $userId = $request->getSafe('user_id', 'intval');
        $roles = $request->get('roles', []);

        $this->validate($request->all(), [
            'user_id' => 'required',
            'roles'   => 'required|array'
        ]);

        if (in_array('admin', $roles)) {
            $roles = ['admin'];
        } elseif (in_array('course_admin', $roles) && in_array('course_creatror', $roles)) {
            unset($roles[array_search('course_creatror', $roles)]);
        }

        $roles = array_values($roles);

        $user = User::find($userId);

        if (!$user) {
            return $this->sendError([
                'message' => __('The selected user could not be found.', 'fluent-community-pro')
            ], 404);
        }

        $user->syncXProfile();

        if ($user->community_role) {
            if ($user->community_role->value != $roles) {
                $user->community_role()->update([
                    'value' => \maybe_serialize($roles)
                ]);
                do_action('fluent_community/manager/updated', $user, $roles);
            }

            return [
                'message' => __('Manager has been updated successfully', 'fluent-community-pro'),
                'manager' => $user
            ];
        }

        $user->community_role()->create([
            'value'       => $roles,
            'meta_key'    => '_user_community_roles',
            'object_type' => 'user',
            'object_id'   => $user->ID
        ]);

        $user->load('community_role');
        do_action('fluent_community/manager/added', $user, $roles);

        return [
            'message' => __('Manager has been added successfully', 'fluent-community-pro'),
            'manager' => $user
        ];
    }

    public function deleteManager(Request $request, $user_id)
    {
        $user = User::with('community_role')->find($user_id);

        if (!$user) {
            return $this->sendError(__('User not found', 'fluent-community-pro'));
        }

        if (!$user->community_role) {
            return $this->sendError(__('User is not a manager', 'fluent-community-pro'));
        }

        do_action('fluent_community/manager/before_remove', $user);

        $user->community_role->delete();

        do_action('fluent_community/manager/after_remove', $user);
        do_action_deprecated('fluent_community/managed/after_remove', [$user], '2.8.1', 'fluent_community/manager/after_remove');

        return [
            'message' => __('Manager has been removed successfully', 'fluent-community-pro')
        ];
    }

    public function getUsers(Request $request)
    {
        $userQuery = User::searchBy($request->getSafe('search'));

        if ($request->get('context') == 'add_manager') {
            $userQuery->whereDoesntHave('community_role');
        }

        if (is_multisite()) {
            global $wpdb;
            $blogId = get_current_blog_id();
            $blogPrefix = $wpdb->get_blog_prefix($blogId);
            $userQuery->whereHas('usermeta', function ($q) use ($blogPrefix) {
                $q->where('meta_key', $blogPrefix . 'capabilities');
            });
        }

        $users = $userQuery->paginate();

        return [
            'users' => $users
        ];
    }

    public function getTopics(Request $request)
    {
        if ($request->has('optionsOnly')) {
            $topis = Utility::getTopics();
            $formattedTopics = [];
            foreach ($topis as $topic) {

                $formattedTopics[] = [
                    'id'          => $topic['id'],
                    'title'       => $topic['title'],
                    'description' => $topic['description'] ?? '',
                ];
            }

            return [
                'topics' => $formattedTopics
            ];
        }

        $search = $request->getSafe('search', 'sanitize_text_field');
        $topics = Utility::getTopics();

        if ($search) {
            $topics = array_filter($topics, function ($topic) use ($search) {
                return strpos(strtolower($topic['title']), strtolower($search)) !== false;
            });
        }

        return [
            'all_spaces' => BaseSpace::query()->withoutGlobalScopes()->orderBy('serial', 'ASC')->get(),
            'topics'     => array_values($topics)
        ];
    }

    public function saveTopics(Request $request)
    {
        $updateData = $request->all();
        $this->validate($updateData, [
            'title' => 'required',
        ]);

        $id = $request->getSafe('id', 'intval');

        if ($id) {
            $topic = Term::where('taxonomy_name', 'post_topic')->find($id);
            if (!$topic) {
                return $this->sendError(__('Topic not found', 'fluent-community-pro'));
            }
            $topic->title = sanitize_text_field($updateData['title']);
            $topic->description = sanitize_text_field($updateData['description'] ?? '');

            $settings = $topic->settings;
            $settings['admin_only'] = Arr::get($updateData, 'admin_only', 'no');
            $topic->settings = $settings;
            $topic->save();
        } else {
            // Validate the slug
            $slug = Utility::slugify(Arr::get($updateData, 'slug'));
            if (!$slug) {
                $slug = Utility::slugify($updateData['title']);
            }

            $exist = Term::where('taxonomy_name', 'post_topic')->where('slug', $slug)->first();

            if ($exist) {
                return $this->sendError([
                    'message' => __('Slug already exist. Please use a different slug.', 'fluent-community-pro')
                ]);
            }

            $topic = Term::create([
                'taxonomy_name' => 'post_topic',
                'title'         => sanitize_text_field($updateData['title']),
                'description'   => sanitize_text_field($updateData['description'] ?? ''),
                'slug'          => $slug,
                'settings'      => [
                    'admin_only' => Arr::get($updateData, 'admin_only', 'no') == 'yes' ? 'yes' : 'no'
                ]
            ]);
        }

        $spaceIds = array_map('intval', (array) $request->get('space_ids', []));

        $topicSpaceRelations = Meta::select(['id', 'object_id', 'meta_key'])
            ->where('object_id', $topic->id)
            ->where('object_type', 'term_space_relation')
            ->get();

        foreach ($topicSpaceRelations as $relation) {
            // meta_key stores the Space ID for term_space_relation rows
            $relatedSpaceId = (int) $relation->meta_key;
            if (in_array($relatedSpaceId, $spaceIds, true)) {
                $spaceIds = array_diff($spaceIds, [$relatedSpaceId]);
            } else {
                $relation->delete();
            }
        }

        if ($spaceIds) {
            foreach ($spaceIds as $spaceId) {
                if (!BaseSpace::withoutGlobalScopes()->find($spaceId)) {
                    continue;
                }
                Meta::create([
                    'object_id'   => $topic->id,
                    'meta_key'    => $spaceId,
                    'object_type' => 'term_space_relation'
                ]);
            }
        }

        Utility::forgetCache('fluent_community_post_topics');

        return [
            'message' => __('Topic has been saved successfully', 'fluent-community-pro'),
            'topic'   => $topic
        ];
    }

    public function reorderTopics(Request $request)
    {
        $topicIds = array_map('intval', (array) $request->get('topic_ids', []));

        if (!$topicIds) {
            return $this->sendError([
                'message' => __('No topics to reorder', 'fluent-community-pro')
            ]);
        }

        // A valid payload can never exceed the number of topics that exist.
        $totalTopics = Term::where('taxonomy_name', 'post_topic')->count();

        if (count($topicIds) > $totalTopics) {
            return $this->sendError([
                'message' => __('Invalid reorder request. Please refresh and try again.', 'fluent-community-pro')
            ]);
        }

        $topics = Term::where('taxonomy_name', 'post_topic')
            ->whereIn('id', $topicIds)
            ->get()
            ->keyBy('id');

        // Commit all serial updates in one transaction, not one per topic.
        Helper::dbTransaction(function () use ($topicIds, $topics) {
            foreach ($topicIds as $index => $topicId) {
                $topic = $topics->get($topicId);
                if (!$topic) {
                    continue;
                }
                $settings = $topic->settings ?: [];
                $settings['serial'] = $index + 1;
                $topic->settings = $settings;
                $topic->save();
            }
        });

        Utility::forgetCache('fluent_community_post_topics');

        return [
            'message' => __('Topics reordered successfully', 'fluent-community-pro')
        ];
    }

    public function getSnippetsSettings(Request $request)
    {
        return [
            'snippets' => ProHelper::getSnippetsSettings()
        ];
    }

    public function updateSnippetsSettings(Request $request)
    {
        $settings = $request->get('snippets', []);

        $formattedSettings = [
            'custom_css' => ProHelper::sanitizeCSS(Arr::get($settings, 'custom_css', '')),
        ];

        if (current_user_can('unfiltered_html')) {
            $formattedSettings['custom_js'] = Arr::get($settings, 'custom_js', '');
        } else {
            $existingSettings = ProHelper::getSnippetsSettings();
            $formattedSettings['custom_js'] = Arr::get($existingSettings, 'custom_js', '');
        }

        ProHelper::updateSnippetsSettings($formattedSettings);

        return [
            'message' => __('Snippets settings have been saved successfully.', 'fluent-community-pro')
        ];
    }

    public function deleteTopic(Request $request, $topicId)
    {
        $topic = Term::where('taxonomy_name', 'post_topic')->findOrFail($topicId);
        $topic->delete();

        // remove the relations
        Meta::where('object_id', $topicId)
            ->where('object_type', 'term_space_relation')
            ->delete();

        Utility::forgetCache('fluent_community_post_topics');

        return [
            'message' => __('Topic has been deleted successfully', 'fluent-community-pro')
        ];
    }

    public function updateTopicConfig(Request $request)
    {
        $config = $request->get('config', []);
        $prev = Helper::getTopicsConfig();
        $config = Arr::only($config, array_keys($prev));

        $config['max_topics_per_post'] = (int)Arr::get($config, 'max_topics_per_post', 1);
        $config['max_topics_per_space'] = (int)Arr::get($config, 'max_topics_per_space', 10);
        $config['show_on_post_card'] = Arr::get($config, 'show_on_post_card') == 'yes' ? 'yes' : 'no';

        Utility::updateOption('topics_config', $config);
        Utility::forgetCache('topics_config');

        return [
            'message' => __('Topics configuration has been updated successfully', 'fluent-community-pro'),
            'config'  => $config
        ];
    }

    public function saveColorConfig(Request $request)
    {
        $darkSchema = $request->get('dark_schema', 'default');
        $lightSchema = $request->get('light_schema', 'default');

        $allSchemas = Utility::getColorSchemas();

        if (!isset($allSchemas['darkSkins'][$darkSchema]) || !isset($allSchemas['lightSkins'][$lightSchema])) {
            return $this->sendError([
                'message' => __('Invalid color schema selected', 'fluent-community-pro')
            ]);
        }

        $updateData = [
            'dark_schema'  => $darkSchema,
            'light_schema' => $lightSchema,
            'version'      => FLUENT_COMMUNITY_PLUGIN_VERSION
        ];

        if ($darkSchema === 'custom') {
            $updateData['dark_config'] = ProHelper::sanitizeColorConfig($request->get('dark_config', []));
            $allSchemas['darkSkins']['custom']['selectors'] = $updateData['dark_config'];
        } else {
            $updateData['dark_config'] = [];
        }

        if ($lightSchema === 'custom') {
            $updateData['light_config'] = ProHelper::sanitizeColorConfig($request->get('light_config', []));
            $allSchemas['lightSkins']['custom']['selectors'] = $updateData['light_config'];
        } else {
            $updateData['light_config'] = [];
        }

        $lightCss = Utility::generateCss(Arr::get($allSchemas, "lightSkins.$lightSchema.selectors"));
        $darkCss = Utility::generateCss(Arr::get($allSchemas, "darkSkins.$darkSchema.selectors"), 'html.dark');

        $updateData['cached_css'] = $lightCss . ' ' . $darkCss;

        Utility::updateOption('portal_color_config', $updateData);

        return [
            'message' => __('Color configuration has been updated successfully', 'fluent-community-pro'),
        ];

    }

    public function saveAuthSettings(Request $request)
    {
        $settings = $request->get('settings', []);

        $formattedSettings = AuthenticationService::formatAuthSettings($settings);

        $formattedSettings = apply_filters('fluent_community/update_auth_settings', $formattedSettings);

        Utility::updateOption('auth_settings', $formattedSettings);

        Utility::setCache('auth_settings', $formattedSettings, WEEK_IN_SECONDS);

        $formattedSettings['login']['form']['fields'] = AuthHelper::getLoginFormFields();
        $formattedSettings['signup']['form']['fields'] = AuthHelper::getFormFields();

        return [
            'message'  => __('Auth settings have been updated successfully', 'fluent-community-pro'),
            'settings' => $formattedSettings
        ];
    }

    public function updateCourseLockscreenSettings(Request $request, $courseId)
    {
        $course = Course::findOrFail($courseId);

        $settingFields = $request->get('lockscreen', []);

        $formattedFields = LockscreenService::formatLockscreenFields($settingFields, $course);

        $formattedFields = apply_filters('fluent_community/update_lockscreen_settings', $formattedFields, $course);

        $course->setLockscreen($formattedFields);

        return [
            'message' => __('Lockscreen settings have been updated successfully.', 'fluent-community-pro'),
            'course'  => $course
        ];
    }

    public function updateSpaceLockscreenSettings(Request $request, $spaceSlug)
    {
        $space = Space::where('slug', $spaceSlug)->firstOrFail();

        $user = $this->getUser(true);
        if (!$user->hasSpaceManageAccess() && $user->getSpaceRole($space) !== 'admin') {
            return $this->sendError([
                'message' => __('You do not have permission to manage this space.', 'fluent-community-pro')
            ], 403);
        }

        $settingFields = $request->get('lockscreen', []);

        $formattedFields = LockscreenService::formatLockscreenFields($settingFields, $space);

        $formattedFields = apply_filters('fluent_community/update_lockscreen_settings', $formattedFields, $space);

        $space->setLockscreen($formattedFields);

        return [
            'message'   => __('Lockscreen settings have been updated successfully.', 'fluent-community-pro'),
            'community' => $space
        ];
    }

    public function getCourseWelcomeBannerSettings(Request $request, $courseId)
    {
        $course = Course::findOrFail($courseId);

        $settings = ProHelper::getCourseWelcomeBannerSettings($course);

        $settings = apply_filters('fluent_community/get_course_welcome_banner_settings', $settings, $course, $request->all());

        return [
            'settings' => $settings
        ];
    }

    public function updateCourseWelcomeBannerSettings(Request $request, $courseId)
    {
        $course = Course::findOrFail($courseId);

        $settings = $request->get('settings', []);

        $settings = CustomSanitizer::sanitizeWelcomeBannerSettings($settings, ['enrolled', 'not_enrolled']);

        foreach (['enrolled', 'not_enrolled'] as $view) {
            $description = Arr::get($settings, $view . '.description');
            if (!empty($description)) {
                $settings[$view]['description_rendered'] = wp_kses_post(FeedsHelper::mdToHtml($description));
            }
        }

        $settings = apply_filters('fluent_community/update_course_welcome_banner_settings', $settings, $course);

        ProHelper::saveCourseWelcomeBannerSettings($course, $settings);

        do_action('fluent_community/course/welcome_banner_updated', $course, $settings);

        return [
            'message'  => __('Welcome banner settings have been updated successfully.', 'fluent-community-pro'),
            'settings' => $settings
        ];
    }

    public function saveCrmTaggingConfig(Request $request)
    {
        $rawSettings = $request->get('settings', []);
        $taggingMaps = array_filter(Arr::get($rawSettings, 'tagging_maps', []), function ($value) {
            return $value && is_numeric($value);
        });

        $linedMaps = array_filter(Arr::get($rawSettings, 'linked_maps', []));
        $linkedMaps = Arr::only($linedMaps, array_keys($taggingMaps));

        $settings = [
            'is_enabled'         => Arr::get($rawSettings, 'is_enabled') == 'yes' ? 'yes' : 'no',
            'tagging_maps'       => $taggingMaps,
            'linked_maps'        => $linkedMaps,
            'create_crm_contact' => Arr::get($rawSettings, 'create_crm_contact') == 'yes' ? 'yes' : 'no',
            'create_user'        => Arr::get($rawSettings, 'create_user') == 'yes' ? 'yes' : 'no',
            'send_welcome_email' => Arr::get($rawSettings, 'send_welcome_email') == 'yes' ? 'yes' : 'no',
        ];

        if (Arr::get($settings, 'is_enabled') != 'yes') {
            update_option('_fcom_crm_tagging', $settings, 'yes');
            $featureSettings = Utility::getFeaturesConfig();
            $featureSettings['has_crm_sync'] = 'no';
            Utility::updateOption('fluent_community_features', $featureSettings);
            return [
                'message'  => __('CRM Tagging settings have been updated successfully', 'fluent-community-pro'),
                'settings' => $settings
            ];
        }

        if ($taggingMaps) {
            $spaceCourseIds = array_keys($taggingMaps);
            $hasSpaceTagging = BaseSpace::whereIn('id', $spaceCourseIds)->withoutGlobalScopes()->exists();
            if (!$hasSpaceTagging) {
                $taggingMaps = [];
            }
        }
        if ($linkedMaps) {
            $spaceCourseIds = array_keys($linkedMaps);
            $hasSpaceSyncTagging = BaseSpace::whereIn('id', $spaceCourseIds)->withoutGlobalScopes()->exists();
            if (!$hasSpaceSyncTagging) {
                $linkedMaps = [];
            }
        }

        $settings['is_enabled'] = 'yes';
        $settings['tagging_maps'] = $taggingMaps;
        $settings['linked_maps'] = $linkedMaps;

        update_option('_fcom_crm_tagging', $settings, 'yes');

        $featureSettings = Utility::getFeaturesConfig();
        $featureSettings['has_crm_sync'] = (!empty($taggingMaps) || !empty($linkedMaps)) ? 'yes' : 'no';
        Utility::updateOption('fluent_community_features', $featureSettings);

        return [
            'message'  => __('CRM Tagging settings have been updated successfully', 'fluent-community-pro'),
            'settings' => $settings
        ];
    }

    public function getWebhooks(Request $request)
    {
        $webhooks = WebhookModel::query()->searchBy($request->getSafe('search', 'sanitize_text_field'))
            ->paginate();

        $data = [
            'webhooks' => $webhooks
        ];

        if ($request->get('page') == 1) {

            if (Helper::isFeatureEnabled('course_module')) {
                $courses = Course::query()->select(['id', 'title', 'slug', 'logo', 'settings'])->orderBy('title', 'ASC')->get();
                $data['courses'] = $courses;
            }

            $spaces = Space::query()->select(['id', 'title', 'slug', 'logo', 'settings'])->orderBy('title', 'ASC')->get();
            $data['spaces'] = $spaces;
        }

        return $data;
    }

    public function saveWebhook(Request $request)
    {
        $this->validate($request->all(), [
            'title' => 'required'
        ]);

        $data = [
            'title'                 => sanitize_text_field($request->get('title')),
            'course_ids'            => (array)$request->get('course_ids', []),
            'space_ids'             => (array)$request->get('space_ids', []),
            'remove_course_ids'     => (array)$request->get('remove_course_ids', []),
            'remove_space_ids'      => (array)$request->get('remove_space_ids', []),
            'send_wp_welcome_email' => $request->get('send_wp_welcome_email') == 'yes' ? 'yes' : 'no',
        ];

        if (Helper::isFeatureEnabled('course_module')) {
            if ($data['course_ids']) {
                $data['course_ids'] = Course::whereIn('id', $data['course_ids'])->get()->pluck('id')->toArray();
            }

            if ($data['remove_course_ids']) {
                $data['remove_course_ids'] = Course::whereIn('id', $data['remove_course_ids'])->get()->pluck('id')->toArray();
            }

        } else {
            $data['course_ids'] = [];
            $data['remove_course_ids'] = [];
        }

        if ($data['space_ids']) {
            $data['space_ids'] = Space::whereIn('id', $data['space_ids'])->get()->pluck('id')->toArray();
        }

        if ($data['remove_space_ids']) {
            $data['remove_space_ids'] = Space::whereIn('id', $data['remove_space_ids'])->get()->pluck('id')->toArray();
        }

        $id = $request->getSafe('id', 'intval');

        if ($id) {
            $webhook = WebhookModel::find($id);

            if (!$webhook) {
                return $this->sendError(__('Webhook not found.', 'fluent-community-pro'), 404);
            }

            $runningCount = Arr::get($webhook->value, 'running_count', 0);
            $data['running_count'] = $runningCount;

            $webhook->value = $data;
            $webhook->save();
        } else {
            $webhook = WebhookModel::create([
                'value' => $data
            ]);
        }

        return [
            'message' => __('Webhook has been saved successfully', 'fluent-community-pro'),
            'webhook' => $webhook
        ];
    }

    public function deleteWebhook(Request $request)
    {
        $id = $request->getSafe('id', 'intval');

        if (!$id) {
            return $this->sendError(__('Webhook not found', 'fluent-community-pro'));
        }

        $webhook = WebhookModel::findOrFail($id);

        $webhook->delete();

        return [
            'message' => __('Webhook has been deleted successfully', 'fluent-community-pro')
        ];
    }

    public function getMessagingSettings(Request $request)
    {
        if (!method_exists(ChatHelper::class, 'getMessagingConfig')) {
            return $this->sendError([
                'message' => __('Please update Fluent Messaging plugin to latest version', 'fluent-community-pro')
            ]);
        }

        return [
            'settings'      => ChatHelper::getMessagingConfig(),
            'socket_config' => PusherHelper::getSocketConfig(false)
        ];
    }

    public function updateMessagingSettings(Request $request)
    {
        $prevSettings = ChatHelper::getMessagingConfig();
        $settings = $request->get('settings', []);
        $settings = Arr::only($settings, array_keys($prevSettings));
        $settings = wp_parse_args($settings, $prevSettings);

        ChatHelper::updateMessagingConfig($settings);

        if (Arr::get($settings, 'realtime_enabled', 'no') === 'yes') {
            $socketConfig = $request->get('socket_config', []);
            if (!empty($socketConfig)) {
                PusherHelper::updateSocketConfig($socketConfig);
            }
        }

        return [
            'message'  => __('Messaging settings have been updated successfully', 'fluent-community-pro'),
            'settings' => $settings
        ];
    }

    public function saveSidebarLink(Request $request)
    {
        $link = $request->get('link', []);

        $existingLink = null;
        if (!empty($link['id'])) {
            $existingLink = SidebarLink::query()->withoutGlobalScopes()
                ->where('type', 'sidebar_link')
                ->findOrFail($link['id']);
        }

        $this->validate($link, [
            'title'                   => 'required',
            'parent_id'               => 'required',
            'privacy'                 => 'required|in:public,logged_in,members_only,logged_out_only',
            'settings.permalink'      => 'required|url',
            'settings.membership_ids' => 'required_if:privacy,members_only|array',
        ], [
            'title.required'                      => __('Title is required', 'fluent-community-pro'),
            'parent_id.required'                  => __('Please select Space Group', 'fluent-community-pro'),
            'privacy.required'                    => __('Please select privacy', 'fluent-community-pro'),
            'settings.permalink.required'         => __('Permalink is required', 'fluent-community-pro'),
            'settings.permalink.url'              => __('Please provide a valid URL', 'fluent-community-pro'),
            'settings.membership_ids.required_if' => __('Please select at least one membership for members only link', 'fluent-community-pro'),
        ]);

        $fromattedData = [
            'title'     => sanitize_text_field($link['title']),
            'status'    => 'published',
            'parent_id' => (int)$link['parent_id'],
            'slug'      => $existingLink->slug ?? 'custom_' . (Utility::slugify($link['title'], 'custom_link') . '_' . time()),
            'privacy'   => $link['privacy'],
            'settings'  => Arr::only($link['settings'], [
                'permalink',
                'new_tab',
                'emoji',
                'shape_svg',
                'membership_ids',
            ]),
        ];

        $settings = $fromattedData['settings'];

        $spaceGroup = SpaceGroup::findOrFail($fromattedData['parent_id']);
        $serial = BaseSpace::query()->withoutGlobalScopes()->where('parent_id', $spaceGroup->id)->max('serial') + 1;

        if ($fromattedData['privacy'] == 'members_only') {
            $membershipIds = (array)Arr::get($fromattedData, 'settings.membership_ids', []);
            $spaces = BaseSpace::query()->withoutGlobalScopes()
                ->whereIn('id', $membershipIds)
                ->get();

            $settings['membership_ids'] = array_map('sanitize_text_field', $spaces->pluck('id')->toArray());

            if (empty($settings['membership_ids'])) {
                return $this->sendError([
                    'message' => __('Please select at least one membership for members only link', 'fluent-community-pro')
                ]);
            }
        } else {
            $settings['membership_ids'] = [];
        }

        $fromattedData['serial'] = $serial;

        $settings['shape_svg'] = CustomSanitizer::sanitizeSvg(Arr::get($settings, 'shape_svg', ''));
        if (empty($settings['shape_svg'])) {
            $settings['emoji'] = CustomSanitizer::sanitizeEmoji(Arr::get($settings, 'emoji', ''));
        } else {
            $settings['emoji'] = '';
        }

        $settings['permalink'] = sanitize_url($settings['permalink']);

        $settings['new_tab'] = Arr::get($settings, 'new_tab') === 'yes' ? 'yes' : 'no';

        $fromattedData['settings'] = $settings;

        if ($existingLink) {
            $existingLink->update($fromattedData);
        } else {
            $existingLink = SidebarLink::create($fromattedData);
        }

        $imageTypes = ['cover_photo', 'logo'];
        $metaData = [];
        foreach ($imageTypes as $type) {
            if (!empty($link[$type])) {
                $media = Helper::getMediaFromUrl($link[$type]);
                if (!$media || $media->is_active) {
                    continue;
                }
                $metaData[$type] = $media->public_url;
                $media->update([
                    'is_active'     => true,
                    'user_id'       => get_current_user_id(),
                    'sub_object_id' => $existingLink->id,
                    'object_source' => 'space_' . $type
                ]);
            }
        }

        if ($metaData) {
            $existingLink->updateCustomData($metaData, false);
        }

        return [
            'link'    => $existingLink,
            'message' => __('The link has been saved successfully', 'fluent-community-pro')
        ];
    }

    public function deleteSidebarLink(Request $request, $id)
    {
        $link = SidebarLink::query()->findOrFail($id);

        do_action('fluent_community/sidebar_link/before_delete', $link);

        $link->delete();

        do_action('fluent_community/sidebar_link/after_delete', $link);

        return [
            'message' => __('The link has been deleted successfully', 'fluent-community-pro')
        ];
    }


    public function getFollowersSettings(Request $request)
    {
        return [
            'settings' => FollowerHelper::getSettings()
        ];
    }

    public function saveFollowersSettings(Request $request)
    {
        $settings = $request->get('settings', []);

        return [
            'message'  => __('Followers settings have been updated successfully', 'fluent-community-pro'),
            'settings' => FollowerHelper::updateSettings($settings)
        ];
    }

    public function getCustomProfileFields(Request $request)
    {
        $config = ProfileFieldsService::getConfig(true);

        return [
            'config' => $config
        ];
    }

    public function saveCustomProfileFields(Request $request)
    {
        $groups    = $request->get('groups', []);
        $fields    = $request->get('fields', []);
        $isEnabled = $request->get('is_enabled', 'no');

        $formattedGroups = ProfileFieldsService::sanitizeProfileFieldGroups($groups);
        $validGroupSlugs = array_column($formattedGroups, 'slug');
        $formattedFields = ProfileFieldsService::sanitizeProfileFields($fields, $validGroupSlugs);

        $config = [
            'is_enabled' => $isEnabled === 'yes' ? 'yes' : 'no',
            'groups'     => $formattedGroups,
            'fields'     => $formattedFields
        ];

        Utility::updateOption('custom_profile_fields', $config);

        $featureConfig = Utility::getFeaturesConfig();
        $isPrevDisabled = Arr::get($featureConfig, 'custom_profile_fields', 'no') !== 'yes';

        if ($isPrevDisabled && $config['is_enabled'] === 'yes') {
            ProfileFieldsService::migrateCustomFieldsToXProfile();
        }

        $featureConfig['custom_profile_fields'] = $config['is_enabled'];
        Utility::updateOption('fluent_community_features', $featureConfig);

        return [
            'message' => __('Custom profile fields have been saved successfully', 'fluent-community-pro'),
            'config'  => $config
        ];
    }

    public function getExportableStudents(Request $request, $courseId)
    {
        Course::findOrFail($courseId);

        $search = $request->getSafe('search');

        $students = XProfile::whereHas('space_pivot', function ($q) use ($courseId) {
            return $q->where('space_id', $courseId)
                ->where('role', 'student');
        })
            ->searchBy($search)
            ->whereHas('user')
            ->with([
                'user:ID,user_email',
                'space_pivot' => function ($q) use ($courseId) {
                    return $q->where('space_id', $courseId);
                },
            ])
            ->select(ProfileHelper::getXProfilePublicFields())
            ->limit(5000)
            ->get();

        $studentUserIds = $students->pluck('user_id')->toArray();

        $progressMap = CourseHelper::getBulkCourseProgress($courseId, $studentUserIds);

        $rows = [];
        foreach ($students as $student) {
            $progress = $progressMap[$student->user_id] ?? 0;
            $rows[] = apply_filters('fluent_community/course/exportable_student_row', [
                'Name'            => $student->display_name,
                'Email'           => $student->user->user_email,
                'Username'        => $student->username,
                'Progress'        => $progress . '%',
                'Enrollment Date' => $student->space_pivot->created_at->format('Y-m-d H:i:s'),
                'Last Activity'   => $student->last_activity ?: '',
            ], $student, $progress, $courseId);
        }

        return apply_filters('fluent_community/admin_course_exportable_students_api_response', [
            'students' => $rows
        ], $request->all(), $courseId);
    }
}
